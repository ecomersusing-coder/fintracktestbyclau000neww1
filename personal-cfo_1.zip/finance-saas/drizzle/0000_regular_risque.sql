CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`password_hash` text NOT NULL,
	`name` text,
	`email_verified_at` integer,
	`image` text,
	`is_active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `verification_tokens` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`purpose` text NOT NULL,
	`token` text NOT NULL,
	`expires_at` integer NOT NULL,
	`used_at` integer,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `workspace_members` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`user_id` text NOT NULL,
	`role` text DEFAULT 'OWNER' NOT NULL,
	`status` text DEFAULT 'ACTIVE' NOT NULL,
	`invited_email` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `workspaces` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`owner_id` text NOT NULL,
	`currency` text DEFAULT 'INR' NOT NULL,
	`country` text,
	`monthly_income_range` text,
	`is_demo` integer DEFAULT false NOT NULL,
	`onboarding_completed_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `plan_features` (
	`id` text PRIMARY KEY NOT NULL,
	`plan_id` text NOT NULL,
	`key` text NOT NULL,
	`limit_value` integer,
	`bool_value` integer
);
--> statement-breakpoint
CREATE TABLE `plans` (
	`id` text PRIMARY KEY NOT NULL,
	`key` text NOT NULL,
	`name` text NOT NULL,
	`description` text,
	`price_monthly_minor` integer DEFAULT 0 NOT NULL,
	`price_yearly_minor` integer DEFAULT 0 NOT NULL,
	`trial_days` integer DEFAULT 0 NOT NULL,
	`is_active` integer DEFAULT true NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`plan_id` text NOT NULL,
	`status` text DEFAULT 'TRIALING' NOT NULL,
	`billing_interval` text DEFAULT 'MONTHLY' NOT NULL,
	`current_period_start` integer NOT NULL,
	`current_period_end` integer NOT NULL,
	`trial_ends_at` integer,
	`cancel_at_period_end` integer DEFAULT false NOT NULL,
	`canceled_at` integer,
	`provider` text,
	`provider_customer_id` text,
	`provider_subscription_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `usage_records` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`metric` text NOT NULL,
	`period_start` integer NOT NULL,
	`period_end` integer NOT NULL,
	`value` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `categories` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text,
	`parent_id` text,
	`name` text NOT NULL,
	`icon` text,
	`color` text,
	`kind` text DEFAULT 'EXPENSE' NOT NULL,
	`is_system` integer DEFAULT false NOT NULL,
	`is_archived` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `credit_cards` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`bank_name` text,
	`last4` text,
	`credit_limit_minor` integer DEFAULT 0 NOT NULL,
	`outstanding_minor` integer DEFAULT 0 NOT NULL,
	`statement_day` integer,
	`due_day` integer,
	`min_due_percent` integer,
	`annual_fee_minor` integer,
	`rewards_note` text,
	`is_active` integer DEFAULT true NOT NULL,
	`is_demo` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `financial_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`bank_name` text,
	`type` text DEFAULT 'SAVINGS' NOT NULL,
	`last4` text,
	`currency` text DEFAULT 'INR' NOT NULL,
	`opening_balance_minor` integer DEFAULT 0 NOT NULL,
	`current_balance_minor` integer DEFAULT 0 NOT NULL,
	`is_active` integer DEFAULT true NOT NULL,
	`is_demo` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `attachments` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`transaction_id` text,
	`url` text NOT NULL,
	`file_name` text NOT NULL,
	`mime_type` text NOT NULL,
	`size_bytes` integer NOT NULL,
	`extracted_data` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `tags` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`color` text
);
--> statement-breakpoint
CREATE TABLE `transaction_tags` (
	`transaction_id` text NOT NULL,
	`tag_id` text NOT NULL,
	PRIMARY KEY(`transaction_id`, `tag_id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`type` text NOT NULL,
	`amount_minor` integer DEFAULT 0 NOT NULL,
	`direction` integer DEFAULT 1 NOT NULL,
	`currency` text DEFAULT 'INR' NOT NULL,
	`occurred_at` integer NOT NULL,
	`account_id` text,
	`credit_card_id` text,
	`transfer_to_account_id` text,
	`investment_id` text,
	`loan_id` text,
	`related_transaction_id` text,
	`category_id` text,
	`merchant` text,
	`description` text,
	`notes` text,
	`payment_method` text,
	`is_essential` integer,
	`is_business` integer,
	`is_tax_related` integer,
	`is_recurring` integer DEFAULT false NOT NULL,
	`recurring_transaction_id` text,
	`source` text DEFAULT 'MANUAL' NOT NULL,
	`ai_conversation_id` text,
	`is_demo` integer DEFAULT false NOT NULL,
	`deleted_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `budget_categories` (
	`id` text PRIMARY KEY NOT NULL,
	`budget_id` text NOT NULL,
	`category_id` text NOT NULL,
	`limit_minor` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `budgets` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`period` text DEFAULT 'MONTHLY' NOT NULL,
	`start_date` integer NOT NULL,
	`end_date` integer,
	`total_limit_minor` integer,
	`alert_threshold_percent` integer DEFAULT 80 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `savings_goals` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`icon` text,
	`target_minor` integer DEFAULT 0 NOT NULL,
	`current_minor` integer DEFAULT 0 NOT NULL,
	`target_date` integer,
	`monthly_contribution_minor` integer,
	`is_archived` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `investment_transactions` (
	`id` text PRIMARY KEY NOT NULL,
	`investment_id` text NOT NULL,
	`transaction_id` text,
	`type` text NOT NULL,
	`quantity_milli` integer,
	`price_minor` integer,
	`amount_minor` integer DEFAULT 0 NOT NULL,
	`occurred_at` integer NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `investments` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`type` text NOT NULL,
	`quantity_milli` integer,
	`current_value_minor` integer DEFAULT 0 NOT NULL,
	`invested_amount_minor` integer DEFAULT 0 NOT NULL,
	`currency` text DEFAULT 'INR' NOT NULL,
	`account_id` text,
	`notes` text,
	`is_archived` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `loan_payments` (
	`id` text PRIMARY KEY NOT NULL,
	`loan_id` text NOT NULL,
	`transaction_id` text,
	`amount_minor` integer DEFAULT 0 NOT NULL,
	`principal_minor` integer DEFAULT 0 NOT NULL,
	`interest_minor` integer DEFAULT 0 NOT NULL,
	`paid_at` integer NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `loans` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`type` text DEFAULT 'PERSONAL' NOT NULL,
	`principal_minor` integer DEFAULT 0 NOT NULL,
	`outstanding_minor` integer DEFAULT 0 NOT NULL,
	`interest_rate_bps` integer DEFAULT 0 NOT NULL,
	`emi_minor` integer,
	`start_date` integer NOT NULL,
	`end_date` integer,
	`due_day` integer,
	`account_id` text,
	`is_active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `bills` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`amount_minor` integer DEFAULT 0 NOT NULL,
	`due_date` integer NOT NULL,
	`category` text NOT NULL,
	`status` text DEFAULT 'UPCOMING' NOT NULL,
	`related_type` text,
	`related_id` text,
	`paid_transaction_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `fixed_expenses` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`amount_minor` integer DEFAULT 0 NOT NULL,
	`due_day` integer NOT NULL,
	`frequency` text DEFAULT 'MONTHLY' NOT NULL,
	`account_id` text,
	`category_id` text,
	`reminder_days_before` integer,
	`is_active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `recurring_transactions` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`name` text NOT NULL,
	`template_json` text NOT NULL,
	`frequency` text NOT NULL,
	`interval_count` integer DEFAULT 1 NOT NULL,
	`next_run_at` integer NOT NULL,
	`end_date` integer,
	`last_generated_at` integer,
	`is_active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `subscriptions_tracked` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`service_name` text NOT NULL,
	`amount_minor` integer DEFAULT 0 NOT NULL,
	`billing_cycle` text DEFAULT 'MONTHLY' NOT NULL,
	`next_renewal_at` integer NOT NULL,
	`account_id` text,
	`category_id` text,
	`is_active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `admin_users` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`password_hash` text NOT NULL,
	`name` text,
	`role` text DEFAULT 'SUPPORT' NOT NULL,
	`is_active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text,
	`user_id` text,
	`actor_type` text DEFAULT 'USER' NOT NULL,
	`action` text NOT NULL,
	`entity_type` text NOT NULL,
	`entity_id` text,
	`before` text,
	`after` text,
	`request_text` text,
	`ip_address` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `financial_snapshots` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`snapshot_date` integer NOT NULL,
	`net_worth_minor` integer DEFAULT 0 NOT NULL,
	`assets_minor` integer DEFAULT 0 NOT NULL,
	`liabilities_minor` integer DEFAULT 0 NOT NULL,
	`cash_minor` integer DEFAULT 0 NOT NULL,
	`investments_minor` integer DEFAULT 0 NOT NULL,
	`debt_minor` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `notification_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`user_id` text NOT NULL,
	`type` text NOT NULL,
	`channel` text DEFAULT 'IN_APP' NOT NULL,
	`enabled` integer DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`user_id` text,
	`type` text NOT NULL,
	`title` text NOT NULL,
	`body` text NOT NULL,
	`is_read` integer DEFAULT false NOT NULL,
	`metadata` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `ai_category_rules` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`match_type` text DEFAULT 'MERCHANT_CONTAINS' NOT NULL,
	`match_value` text NOT NULL,
	`category_id` text NOT NULL,
	`confidence_bps` integer DEFAULT 10000 NOT NULL,
	`times_applied` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `ai_conversations` (
	`id` text PRIMARY KEY NOT NULL,
	`workspace_id` text NOT NULL,
	`user_id` text NOT NULL,
	`title` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `ai_messages` (
	`id` text PRIMARY KEY NOT NULL,
	`conversation_id` text NOT NULL,
	`role` text NOT NULL,
	`content` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `ai_tool_calls` (
	`id` text PRIMARY KEY NOT NULL,
	`message_id` text NOT NULL,
	`tool_name` text NOT NULL,
	`input` text NOT NULL,
	`output` text,
	`status` text DEFAULT 'PENDING_CONFIRMATION' NOT NULL,
	`requires_confirmation` integer DEFAULT true NOT NULL,
	`original_state` text,
	`new_state` text,
	`executed_at` integer,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_email_unique` ON `users` (`email`);--> statement-breakpoint
CREATE UNIQUE INDEX `verification_tokens_token_unique` ON `verification_tokens` (`token`);--> statement-breakpoint
CREATE INDEX `vt_user_purpose_idx` ON `verification_tokens` (`user_id`,`purpose`);--> statement-breakpoint
CREATE UNIQUE INDEX `wm_workspace_user_uniq` ON `workspace_members` (`workspace_id`,`user_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pf_plan_key_uniq` ON `plan_features` (`plan_id`,`key`);--> statement-breakpoint
CREATE UNIQUE INDEX `plans_key_unique` ON `plans` (`key`);--> statement-breakpoint
CREATE UNIQUE INDEX `subscriptions_workspace_id_unique` ON `subscriptions` (`workspace_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `ur_workspace_metric_period_uniq` ON `usage_records` (`workspace_id`,`metric`,`period_start`);--> statement-breakpoint
CREATE INDEX `cat_workspace_idx` ON `categories` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `cc_workspace_idx` ON `credit_cards` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `acct_workspace_idx` ON `financial_accounts` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `att_workspace_idx` ON `attachments` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `tag_workspace_idx` ON `tags` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `txn_workspace_date_idx` ON `transactions` (`workspace_id`,`occurred_at`);--> statement-breakpoint
CREATE INDEX `txn_workspace_type_idx` ON `transactions` (`workspace_id`,`type`);--> statement-breakpoint
CREATE INDEX `txn_workspace_category_idx` ON `transactions` (`workspace_id`,`category_id`);--> statement-breakpoint
CREATE INDEX `txn_workspace_merchant_idx` ON `transactions` (`workspace_id`,`merchant`);--> statement-breakpoint
CREATE INDEX `txn_workspace_deleted_idx` ON `transactions` (`workspace_id`,`deleted_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `bc_budget_category_uniq` ON `budget_categories` (`budget_id`,`category_id`);--> statement-breakpoint
CREATE INDEX `budget_workspace_idx` ON `budgets` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `goal_workspace_idx` ON `savings_goals` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `inv_workspace_idx` ON `investments` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `loan_workspace_idx` ON `loans` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `bill_workspace_due_idx` ON `bills` (`workspace_id`,`due_date`);--> statement-breakpoint
CREATE INDEX `fixed_workspace_idx` ON `fixed_expenses` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `recur_workspace_idx` ON `recurring_transactions` (`workspace_id`);--> statement-breakpoint
CREATE INDEX `subtrack_workspace_idx` ON `subscriptions_tracked` (`workspace_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `admin_users_email_unique` ON `admin_users` (`email`);--> statement-breakpoint
CREATE INDEX `audit_workspace_date_idx` ON `audit_logs` (`workspace_id`,`created_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `snap_workspace_date_uniq` ON `financial_snapshots` (`workspace_id`,`snapshot_date`);--> statement-breakpoint
CREATE UNIQUE INDEX `ns_uniq` ON `notification_settings` (`workspace_id`,`user_id`,`type`,`channel`);--> statement-breakpoint
CREATE INDEX `notif_workspace_read_idx` ON `notifications` (`workspace_id`,`is_read`);--> statement-breakpoint
CREATE UNIQUE INDEX `acr_workspace_match_uniq` ON `ai_category_rules` (`workspace_id`,`match_value`);--> statement-breakpoint
CREATE INDEX `aiconv_workspace_user_idx` ON `ai_conversations` (`workspace_id`,`user_id`);--> statement-breakpoint
CREATE INDEX `aimsg_conversation_idx` ON `ai_messages` (`conversation_id`);