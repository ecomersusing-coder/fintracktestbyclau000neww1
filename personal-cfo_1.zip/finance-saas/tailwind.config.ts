import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          50: '#f5f7f7',
          100: '#e8ecec',
          200: '#c9d2d3',
          300: '#a3b1b3',
          400: '#71858a',
          500: '#526468',
          600: '#3d4c50',
          700: '#2d3a3e',
          800: '#1c2528',
          900: '#10171a',
          950: '#080c0e',
        },
        paper: {
          50: '#fbfaf7',
          100: '#f6f3ec',
          200: '#ede7d8',
        },
        moss: {
          50: '#f0f7f3',
          100: '#dbeee2',
          200: '#b6ddc4',
          300: '#87c4a2',
          400: '#58a67e',
          500: '#398a63',
          600: '#2a6f4f',
          700: '#235942',
          800: '#1e4736',
          900: '#193b2e',
          950: '#0c2118',
        },
        clay: {
          400: '#e0a86f',
          500: '#cc8a4a',
          600: '#b06f36',
        },
        rose: {
          400: '#e08585',
          500: '#cc5c5c',
          600: '#a83f3f',
        },
      },
      fontFamily: {
        display: ['var(--font-display)', 'serif'],
        sans: ['var(--font-sans)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(16, 23, 26, 0.04), 0 1px 12px rgba(16, 23, 26, 0.03)',
        popover: '0 8px 30px rgba(16, 23, 26, 0.12)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
    },
  },
  plugins: [],
};

export default config;
