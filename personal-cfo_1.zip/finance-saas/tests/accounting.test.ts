import { describe, it, expect } from 'vitest';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { makeTenant, makeAccount, makeCreditCard, makeCategory } from './fixtures';
import {
  createExpense,
  createIncome,
  createTransfer,
  createCreditCardPayment,
  createInvestmentPurchase,
  updateTransaction,
  deleteTransaction,
} from '@/lib/accounting';
import { undoLastChange } from '@/lib/accounting/delete';
import { findTransactionForChatReference } from '@/lib/accounting/search';
import { AmbiguousMatchError, NotFoundError } from '@/lib/api-error';

async function getAccount(id: string) {
  return db.query.financialAccounts.findFirst({ where: eq(schema.financialAccounts.id, id) });
}
async function getCard(id: string) {
  return db.query.creditCards.findFirst({ where: eq(schema.creditCards.id, id) });
}

describe('spec §15 — accounting rules', () => {
  it('Example 1: credit card purchase increases CC liability, leaves bank untouched', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId, { currentBalanceMinor: 50_000_00 });
    const card = await makeCreditCard(tenant.workspaceId, { outstandingMinor: 0 });

    await createExpense(tenant, {
      creditCardId: card.id,
      amountMajor: 5000,
      currency: 'INR',
      occurredAt: new Date(),
      merchant: 'Amazon',
      source: 'MANUAL',
    });

    const [bankAfter, cardAfter] = await Promise.all([getAccount(bank.id), getCard(card.id)]);
    expect(bankAfter?.currentBalanceMinor).toBe(50_000_00); // unchanged
    expect(cardAfter?.outstandingMinor).toBe(5_000_00); // +5000
  });

  it('Example 2: credit card payment reduces bank AND card liability, no expense created', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId, { currentBalanceMinor: 100_000_00 });
    const card = await makeCreditCard(tenant.workspaceId, { outstandingMinor: 25_000_00 });

    const before = await db.select().from(schema.transactions).where(eq(schema.transactions.workspaceId, tenant.workspaceId));

    await createCreditCardPayment(tenant, {
      accountId: bank.id,
      creditCardId: card.id,
      amountMajor: 20000,
      currency: 'INR',
      occurredAt: new Date(),
      source: 'MANUAL',
    });

    const [bankAfter, cardAfter] = await Promise.all([getAccount(bank.id), getCard(card.id)]);
    expect(bankAfter?.currentBalanceMinor).toBe(80_000_00); // -20000
    expect(cardAfter?.outstandingMinor).toBe(5_000_00); // -20000

    const after = await db.select().from(schema.transactions).where(eq(schema.transactions.workspaceId, tenant.workspaceId));
    const expenseRows = after.filter((t) => t.type === 'EXPENSE' || t.type === 'CC_PURCHASE');
    expect(expenseRows.length).toBe(before.filter((t) => t.type === 'EXPENSE' || t.type === 'CC_PURCHASE').length);
  });

  it('Example 3: bank transfer moves money between accounts, no income/expense created', async () => {
    const tenant = await makeTenant();
    const bankA = await makeAccount(tenant.workspaceId, { name: 'Bank A', currentBalanceMinor: 50_000_00 });
    const bankB = await makeAccount(tenant.workspaceId, { name: 'Bank B', currentBalanceMinor: 10_000_00 });

    await createTransfer(tenant, {
      fromAccountId: bankA.id,
      toAccountId: bankB.id,
      amountMajor: 10000,
      currency: 'INR',
      occurredAt: new Date(),
      source: 'MANUAL',
    });

    const [a, b] = await Promise.all([getAccount(bankA.id), getAccount(bankB.id)]);
    expect(a?.currentBalanceMinor).toBe(40_000_00);
    expect(b?.currentBalanceMinor).toBe(20_000_00);
  });

  it('Example 4: investment purchase moves bank cash into invested amount, not an expense', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId, { currentBalanceMinor: 100_000_00 });
    const [inv] = await db
      .insert(schema.investments)
      .values({ workspaceId: tenant.workspaceId, name: 'Test Fund', type: 'MUTUAL_FUND', investedAmountMinor: 0, currentValueMinor: 0 })
      .returning();

    await createInvestmentPurchase(tenant, {
      accountId: bank.id,
      investmentId: inv.id,
      amountMajor: 20000,
      currency: 'INR',
      occurredAt: new Date(),
      source: 'MANUAL',
    });

    const bankAfter = await getAccount(bank.id);
    const invAfter = await db.query.investments.findFirst({ where: eq(schema.investments.id, inv.id) });
    expect(bankAfter?.currentBalanceMinor).toBe(80_000_00);
    expect(invAfter?.investedAmountMinor).toBe(20_000_00);
  });

  it('plain expense from a bank account debits that account', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId, { currentBalanceMinor: 10_000_00 });
    await createExpense(tenant, { accountId: bank.id, amountMajor: 850, currency: 'INR', occurredAt: new Date(), merchant: 'Lulu', source: 'MANUAL' });
    const after = await getAccount(bank.id);
    expect(after?.currentBalanceMinor).toBe(9_150_00);
  });

  it('income credits the account', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId, { currentBalanceMinor: 0 });
    await createIncome(tenant, { accountId: bank.id, amountMajor: 150000, currency: 'INR', occurredAt: new Date(), merchant: 'Employer', source: 'MANUAL' });
    const after = await getAccount(bank.id);
    expect(after?.currentBalanceMinor).toBe(150_000_00);
  });
});

describe('tenant isolation', () => {
  it('cannot create a transaction against another workspace\u2019s account', async () => {
    const tenantA = await makeTenant();
    const tenantB = await makeTenant();
    const accountB = await makeAccount(tenantB.workspaceId);

    await expect(
      createExpense(tenantA, { accountId: accountB.id, amountMajor: 100, currency: 'INR', occurredAt: new Date(), source: 'MANUAL' })
    ).rejects.toBeInstanceOf(NotFoundError);
  });

  it('search only ever returns rows from the caller\u2019s workspace', async () => {
    const tenantA = await makeTenant();
    const tenantB = await makeTenant();
    const accountA = await makeAccount(tenantA.workspaceId);
    const accountB = await makeAccount(tenantB.workspaceId);

    await createExpense(tenantA, { accountId: accountA.id, amountMajor: 500, currency: 'INR', occurredAt: new Date(), merchant: 'Shared Merchant', source: 'MANUAL' });
    await createExpense(tenantB, { accountId: accountB.id, amountMajor: 500, currency: 'INR', occurredAt: new Date(), merchant: 'Shared Merchant', source: 'MANUAL' });

    const { searchTransactions } = await import('@/lib/accounting/search');
    const resultsA = await searchTransactions(tenantA, { merchant: 'Shared Merchant' });
    expect(resultsA.items.every((t) => t.workspaceId === tenantA.workspaceId)).toBe(true);
    expect(resultsA.total).toBe(1);
  });
});

describe('edit / delete / undo (spec §35-43)', () => {
  it('editing amount reverses the old ledger effect and applies the new one', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId, { currentBalanceMinor: 100_000_00 });
    const { transaction } = await createExpense(tenant, {
      accountId: bank.id, amountMajor: 850, currency: 'INR', occurredAt: new Date(), merchant: 'Lulu', source: 'MANUAL',
    });

    await updateTransaction(tenant, { transactionId: transaction.id, amountMajor: 750 });

    const after = await getAccount(bank.id);
    // 100000 - 8.50 (never charged) + adjust to -7.50 => 100000 - 750
    expect(after?.currentBalanceMinor).toBe(100_000_00 - 750_00);
  });

  it('deleting a transaction reverses its ledger effect', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId, { currentBalanceMinor: 100_000_00 });
    const { transaction } = await createExpense(tenant, {
      accountId: bank.id, amountMajor: 1000, currency: 'INR', occurredAt: new Date(), merchant: 'Test', source: 'MANUAL',
    });
    expect((await getAccount(bank.id))?.currentBalanceMinor).toBe(99_000_00);

    await deleteTransaction(tenant, transaction.id);
    expect((await getAccount(bank.id))?.currentBalanceMinor).toBe(100_000_00);

    const row = await db.query.transactions.findFirst({ where: eq(schema.transactions.id, transaction.id) });
    expect(row?.deletedAt).not.toBeNull();
  });

  it('undo reverses the most recent change to a transaction', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId, { currentBalanceMinor: 100_000_00 });
    const { transaction } = await createExpense(tenant, {
      accountId: bank.id, amountMajor: 850, currency: 'INR', occurredAt: new Date(), merchant: 'Lulu', source: 'MANUAL',
    });
    await updateTransaction(tenant, { transactionId: transaction.id, amountMajor: 750 });
    expect((await getAccount(bank.id))?.currentBalanceMinor).toBe(100_000_00 - 750_00);

    await undoLastChange(tenant, transaction.id);
    expect((await getAccount(bank.id))?.currentBalanceMinor).toBe(100_000_00 - 850_00);
  });
});

describe('ambiguous matching (spec §41 — never guess)', () => {
  it('throws with candidates when multiple transactions match a chat reference', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId);
    await createExpense(tenant, { accountId: bank.id, amountMajor: 5000, currency: 'INR', occurredAt: new Date(), merchant: 'Amazon', source: 'MANUAL' });
    await createExpense(tenant, { accountId: bank.id, amountMajor: 2500, currency: 'INR', occurredAt: new Date(), merchant: 'Amazon', source: 'MANUAL' });

    try {
      await findTransactionForChatReference(tenant, { merchant: 'Amazon' });
      expect.unreachable('should have thrown AmbiguousMatchError');
    } catch (err) {
      expect(err).toBeInstanceOf(AmbiguousMatchError);
      expect((err as AmbiguousMatchError).candidates.length).toBe(2);
    }
  });

  it('resolves to exactly one match when amount narrows it down', async () => {
    const tenant = await makeTenant();
    const bank = await makeAccount(tenant.workspaceId);
    await createExpense(tenant, { accountId: bank.id, amountMajor: 5000, currency: 'INR', occurredAt: new Date(), merchant: 'Amazon', source: 'MANUAL' });
    await createExpense(tenant, { accountId: bank.id, amountMajor: 2500, currency: 'INR', occurredAt: new Date(), merchant: 'Amazon', source: 'MANUAL' });

    const match = await findTransactionForChatReference(tenant, { merchant: 'Amazon', amountMajor: 5000 });
    expect(match?.amountMinor).toBe(500_000);
  });
});
