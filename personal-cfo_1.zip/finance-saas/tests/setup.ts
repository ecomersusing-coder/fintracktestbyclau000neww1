import fs from 'fs';
import path from 'path';
import { beforeAll } from 'vitest';

const TEST_DB_PATH = path.resolve(__dirname, '../test.db');

// Point the app's DB client at an isolated test database BEFORE anything
// imports it, then apply migrations fresh so tests never touch dev.db or
// depend on seed data ordering.
for (const ext of ['', '-wal', '-shm']) {
  const p = TEST_DB_PATH + ext;
  if (fs.existsSync(p)) fs.rmSync(p);
}
process.env.DATABASE_URL = `file:${TEST_DB_PATH}`;

beforeAll(async () => {
  const Database = (await import('better-sqlite3')).default;
  const { drizzle } = await import('drizzle-orm/better-sqlite3');
  const { migrate } = await import('drizzle-orm/better-sqlite3/migrator');

  const sqlite = new Database(TEST_DB_PATH);
  const db = drizzle(sqlite);
  migrate(db, { migrationsFolder: path.resolve(__dirname, '../drizzle') });
  sqlite.close();
});
