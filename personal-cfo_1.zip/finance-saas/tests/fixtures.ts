import { db, schema } from '@/db/client';
import type { TenantContext } from '@/lib/tenant';

let seq = 0;

export async function makeTenant(): Promise<TenantContext> {
  seq += 1;
  const [user] = await db
    .insert(schema.users)
    .values({ email: `test-${seq}-${Date.now()}@example.com`, passwordHash: 'x' })
    .returning();
  const [workspace] = await db
    .insert(schema.workspaces)
    .values({ name: `Test Workspace ${seq}`, ownerId: user.id, currency: 'INR' })
    .returning();
  await db.insert(schema.workspaceMembers).values({ workspaceId: workspace.id, userId: user.id, role: 'OWNER' });

  return { userId: user.id, workspaceId: workspace.id, email: user.email };
}

export async function makeAccount(workspaceId: string, overrides: Partial<typeof schema.financialAccounts.$inferInsert> = {}) {
  const [row] = await db
    .insert(schema.financialAccounts)
    .values({ workspaceId, name: 'Test Account', type: 'SAVINGS', currentBalanceMinor: 100_000_00, ...overrides })
    .returning();
  return row;
}

export async function makeCreditCard(workspaceId: string, overrides: Partial<typeof schema.creditCards.$inferInsert> = {}) {
  const [row] = await db
    .insert(schema.creditCards)
    .values({ workspaceId, name: 'Test Card', creditLimitMinor: 200_000_00, outstandingMinor: 0, ...overrides })
    .returning();
  return row;
}

export async function makeCategory(workspaceId: string | null, name: string, kind: 'EXPENSE' | 'INCOME' = 'EXPENSE') {
  const [row] = await db.insert(schema.categories).values({ workspaceId, name, kind }).returning();
  return row;
}
