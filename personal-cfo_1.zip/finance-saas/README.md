# Personal CFO — AI Finance Copilot

A multi-tenant personal finance SaaS: traditional finance screens + an AI copilot that reads,
searches, creates, edits, deletes, and bulk-updates real transactions through controlled backend
tools. Built against the 89-section product spec; this README says plainly what's real and what's
scaffolded for the next phase.

## Quick start

```bash
npm install
npx drizzle-kit generate   # already committed under /drizzle, only needed if you change the schema
npm run db:migrate         # creates dev.db and applies migrations
npm run db:seed            # plans, system categories, admin user, demo workspace
npm run dev                # http://localhost:3000
```

**Demo login:** `demo@personalcfo.local` / `Demo1234!` — a seeded workspace with real accounts,
a credit card, ~15 transactions, goals, a loan, investments, a budget, and bills, all flagged
`isDemo: true` (spec §80) and never mixed with real signups.

**Admin seed:** `ADMIN_SEED_EMAIL` / `ADMIN_SEED_PASSWORD` in `.env` (defaults in `.env.example`).
The admin panel UI itself is Phase 10 — not built yet — but the `admin_users` table and its
separate identity space (never sharing session machinery with customer `users`) already exist.

Run the accounting-engine test suite:
```bash
npm test
```

## Two decisions this sandbox forced, and why they're safe to keep or revert

**Drizzle instead of Prisma.** The spec said "Prisma or equivalent." This sandbox's network
allowlist doesn't include `binaries.prisma.sh`, so the Prisma CLI can't fetch its own query engine
here — `prisma generate` hard-fails with a 403. Rather than hand you a schema I could never
actually run or test, I used Drizzle ORM with `better-sqlite3` (its prebuilds install fine from
GitHub release assets). Every design decision — money as integer minor units, "enum" columns as
validated strings, tenant-scoped tables, indexes — carries over 1:1. `src/db/schema/` mirrors
what a Prisma schema would look like table-for-table; switching back is a mechanical rewrite, not
a redesign, if your team prefers Prisma.

**SQLite for this session, Postgres for production.** `src/db/schema/_helpers.ts` documents the
exact swap (`sqliteTable` → `pgTable`, `integer(mode:'timestamp_ms')` → `timestamp()`,
`integer(mode:'boolean')` → `boolean()`). Nothing in the application code touches the database
driver directly — it all goes through `src/db/client.ts`.

Two smaller, cosmetic adaptations: fonts are a system-font stack instead of `next/font/google`
(this sandbox also blocks `fonts.googleapis.com` — swap back once deployed), and Next's edge
middleware needed an auth-config split (`src/auth.config.ts` vs `src/auth.ts`) so bcrypt/SQLite
never leak into the Edge bundle — this is actually the standard Auth.js pattern regardless of
sandbox constraints, not a workaround.

## What's real right now (verified, not just written)

- **Multi-tenancy**: every table is `workspaceId`-scoped; `requireTenant()` in
  `src/lib/tenant.ts` is the single chokepoint that turns a session into a `workspaceId` — nothing
  ever trusts an id from the client. Tested directly (`tests/accounting.test.ts` → "tenant
  isolation").
- **Auth**: signup, login, logout, email verification, forgot/reset password, protected routes,
  session management — all working end-to-end against the running server (see verification below).
- **The accounting engine** (`src/lib/accounting/`): every rule from spec §15 implemented and
  tested against your exact worked examples — credit card purchase, credit card payment, bank
  transfer, investment purchase — plus income, plain expenses, edit (reverse-then-reapply), soft
  delete, one-step undo, and ambiguous-match detection (§41, "never guess"). All money is integer
  minor units; nothing is computed as a float.
- **Auto-categorization** (§29-31): merchant keyword rules + per-workspace learned rules
  (`ai_category_rules`), with a confidence threshold that asks for confirmation below 0.8 instead
  of guessing. Verified live: an API call for "₹850 at Lulu" correctly suggested Groceries at 0.6
  confidence and flagged `needsConfirmation: true`.
- **SaaS billing skeleton**: `plans` / `plan_features` / `subscriptions` / `usage_records` are
  fully database-driven — no limit is hardcoded in app code (§6). Both monthly-counter limits
  (transactions, AI messages) and standing-count limits (accounts, cards) are enforced.
- **Dashboard**: every number on it (`src/lib/analytics/summary.ts`) is a real SQL aggregation —
  net worth, cash, credit utilization, monthly income/expense/savings rate, upcoming payments —
  with income-vs-expense and category-breakdown charts.
- **Onboarding**: the 7-step skippable wizard from §5, writing to the real workspace/account
  tables.
- **Audit log**: every accounting-engine mutation writes a before/after row in the same DB
  transaction as the mutation, so data and audit trail can never drift apart (§62).

I ran this, not just wrote it: `npm run build` produces a clean production build (27 pages, 21 API
routes), `npm test` passes 13 tests including your four exact §15 examples, and I drove the whole
stack with real HTTP requests — signup → login → session → dashboard aggregation → creating a
transaction through the API → balance updating correctly → the new transaction appearing in the
server-rendered transactions page.

## What's scaffolded, not built (and exactly where it stands)

Everything below has its database tables, its tenant-scoped access pattern, and (where relevant)
accounting-engine hooks already in place — see each placeholder page in the app for the specific
pointer. None of it has UI yet:

| Area | Phase | What exists today |
|---|---|---|
| Budgets, Bills, Subscriptions, Goals | 4 | Full schema; budget/goal progress math not written |
| Net Worth history, Investments, Loans & Debt | 5 | Schema + `recordDailySnapshot()`; no cron wiring, no UI |
| Reports & exports (PDF/CSV/Excel) | 5 | `getCategoryBreakdown()` powers the data; no export renderer |
| **AI Finance Copilot** | 6-8 | **Not started.** This is the single biggest remaining piece |
| Receipt/invoice AI extraction | 7 | `attachments.extractedData` column reserved; no OCR/vision call |
| Super admin panel UI | 10 | `admin_users` table + separate identity space only |
| Notifications, CSV import, 2FA/OAuth | 9-11 | Schema only or not started |

**On the AI Copilot specifically** (spec §27-58, described as "the differentiator"): the reason
it's not built is that a real implementation needs an actual model + tool-calling loop wired to a
provider, and you chose "provider-agnostic, pick later" — so the honest next step is a short
follow-up to pick Anthropic/OpenAI and build `src/lib/ai/` (provider abstraction, the READ/WRITE
tool set from §53 sitting directly on top of `src/lib/accounting/` and `src/lib/analytics/`, the
confirm-before-write flow, conversation memory). The accounting engine was built with this in mind
— `source: 'AI_CHAT'`, `aiConversationId`, and the ambiguous-match/confirmation patterns already
exist specifically so the copilot has something correct to call into rather than needing its own
parallel write path.

## Repo layout

```
src/db/schema/        Drizzle schema, one file per domain area (35 tables)
src/lib/accounting/    The ledger engine — create/update/delete/bulk/search, all tenant-scoped
src/lib/analytics/     Deterministic dashboard + net-worth math (no LLM arithmetic anywhere)
src/lib/billing/       Plan-driven usage-limit enforcement
src/lib/tenant.ts       requireTenant() — the one chokepoint for authorization
src/app/api/            Route handlers (thin — validate, call lib/, return)
src/app/(app)/           Authenticated pages behind the sidebar shell
tests/                  Vitest suite against a real, freshly-migrated SQLite db
```
