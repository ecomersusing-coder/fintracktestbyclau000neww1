import type { NextAuthConfig } from 'next-auth';

/**
 * Kept deliberately free of any Node-only imports (no better-sqlite3, no
 * bcryptjs) so middleware.ts — which Next.js always runs on the Edge
 * runtime — can import it directly. The Credentials provider itself (which
 * needs DB + bcrypt) is added only in src/auth.ts, which is used by route
 * handlers and server components running in the Node.js runtime.
 */
export const authConfig = {
  trustHost: true,
  pages: {
    signIn: '/login',
    error: '/login',
  },
  session: { strategy: 'jwt', maxAge: 30 * 24 * 60 * 60 },
  providers: [],
  callbacks: {
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.userId as string;
        session.workspaceId = token.workspaceId as string | undefined;
      }
      return session;
    },
  },
} satisfies NextAuthConfig;
