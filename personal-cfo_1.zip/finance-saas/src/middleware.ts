import NextAuth from 'next-auth';
import { NextResponse } from 'next/server';
import { authConfig } from '@/auth.config';

// Deliberately built from the edge-safe authConfig (no DB/bcrypt imports) —
// Next.js always runs middleware on the Edge runtime.
const { auth } = NextAuth(authConfig);

const PUBLIC_PATHS = ['/login', '/signup', '/forgot-password', '/reset-password', '/api/auth', '/api/health'];

export default auth((req) => {
  const { pathname } = req.nextUrl;
  const isPublic = PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(p + '/')) || pathname === '/';

  if (!req.auth && !isPublic) {
    const loginUrl = new URL('/login', req.nextUrl.origin);
    loginUrl.searchParams.set('from', pathname);
    return NextResponse.redirect(loginUrl);
  }
});

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
