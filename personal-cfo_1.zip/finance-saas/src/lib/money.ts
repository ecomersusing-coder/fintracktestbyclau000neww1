// All money in this app is stored and computed as an INTEGER in "minor units"
// (paise for INR, cents for USD, etc.). Never store or compute money as a
// JS float — that's how fintech apps end up with ₹0.01 drift bugs.

const MINOR_UNITS_PER_MAJOR: Record<string, number> = {
  INR: 100,
  USD: 100,
  EUR: 100,
  GBP: 100,
  JPY: 1, // no minor unit
};

export function minorUnitsFor(currency: string): number {
  return MINOR_UNITS_PER_MAJOR[currency] ?? 100;
}

/** Parse a user-facing amount (e.g. "850", "850.50") into integer minor units. */
export function toMinor(amountMajor: number | string, currency = 'INR'): number {
  const units = minorUnitsFor(currency);
  const n = typeof amountMajor === 'string' ? Number(amountMajor) : amountMajor;
  if (!Number.isFinite(n)) throw new Error(`Invalid amount: ${amountMajor}`);
  return Math.round(n * units);
}

/** Format integer minor units into a display string like "₹850.00". */
export function formatMoney(amountMinor: number, currency = 'INR', locale = 'en-IN'): string {
  const units = minorUnitsFor(currency);
  const major = amountMinor / units;
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
    minimumFractionDigits: units === 1 ? 0 : 2,
    maximumFractionDigits: units === 1 ? 0 : 2,
  }).format(major);
}

/** Format integer minor units into a bare number string, e.g. "850.00". */
export function toMajorString(amountMinor: number, currency = 'INR'): string {
  const units = minorUnitsFor(currency);
  return (amountMinor / units).toFixed(units === 1 ? 0 : 2);
}
