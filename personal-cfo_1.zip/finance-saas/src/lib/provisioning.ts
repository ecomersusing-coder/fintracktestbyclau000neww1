import { eq } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { hashPassword } from '@/lib/password';
import { createId } from '@/lib/id';
import { AppError } from '@/lib/api-error';

export interface SignupInput {
  email: string;
  password: string;
  name?: string;
}

/**
 * Creates a new user + their first workspace + a trialing subscription on
 * the Free plan, all in one DB transaction. This is the ONLY path that
 * should ever create a `users` row outside of the seed script.
 */
export async function provisionNewAccount(input: SignupInput) {
  const email = input.email.toLowerCase().trim();

  const existing = await db.query.users.findFirst({ where: eq(schema.users.email, email) });
  if (existing) {
    throw new AppError('An account with this email already exists.', 409, 'EMAIL_TAKEN');
  }

  const freePlan = await db.query.plans.findFirst({ where: eq(schema.plans.key, 'free') });
  if (!freePlan) {
    throw new AppError('Signup is temporarily unavailable. Please try again shortly.', 503, 'PLANS_NOT_SEEDED');
  }

  const passwordHash = await hashPassword(input.password);
  const now = new Date();
  const periodEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);

  return db.transaction((tx) => {
    const user = tx
      .insert(schema.users)
      .values({ email, passwordHash, name: input.name })
      .returning()
      .get();

    const workspace = tx
      .insert(schema.workspaces)
      .values({ name: input.name ? `${input.name}'s Workspace` : 'My Workspace', ownerId: user.id, currency: 'INR' })
      .returning()
      .get();

    tx.insert(schema.workspaceMembers).values({ workspaceId: workspace.id, userId: user.id, role: 'OWNER' }).run();

    tx.insert(schema.subscriptions)
      .values({
        workspaceId: workspace.id,
        planId: freePlan.id,
        status: 'TRIALING',
        billingInterval: 'MONTHLY',
        currentPeriodStart: now,
        currentPeriodEnd: periodEnd,
        trialEndsAt: periodEnd,
      })
      .run();

    const verifyToken = tx
      .insert(schema.verificationTokens)
      .values({
        userId: user.id,
        purpose: 'EMAIL_VERIFY',
        token: createId('vt'),
        expiresAt: new Date(Date.now() + 24 * 3600 * 1000),
      })
      .returning()
      .get();

    return { user, workspace, verifyToken };
  });
}
