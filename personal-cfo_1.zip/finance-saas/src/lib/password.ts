import bcrypt from 'bcryptjs';

const SALT_ROUNDS = 12;

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// Minimum bar for a "production-grade" signup form. Real deployments should
// also check against a breached-password list (e.g. HaveIBeenPwned k-anonymity API).
export function isPasswordStrongEnough(plain: string): boolean {
  return plain.length >= 10 && /[a-z]/.test(plain) && /[A-Z]/.test(plain) && /[0-9]/.test(plain);
}
