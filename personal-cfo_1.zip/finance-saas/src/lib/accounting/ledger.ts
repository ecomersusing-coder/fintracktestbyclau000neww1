import { eq, sql } from 'drizzle-orm';
import { schema } from '@/db/client';
import type { Tx } from './tx-type';

function getLoanPrincipalForTransaction(tx: Tx, transactionId: string): number {
  const row = tx
    .select({ principalMinor: schema.loanPayments.principalMinor })
    .from(schema.loanPayments)
    .where(eq(schema.loanPayments.transactionId, transactionId))
    .get();
  return row?.principalMinor ?? 0;
}

/** Adjusts a bank/cash/wallet account balance by a signed delta (minor units). */
export function adjustAccountBalance(tx: Tx, accountId: string, deltaMinor: number) {
  tx.update(schema.financialAccounts)
    .set({ currentBalanceMinor: sql`${schema.financialAccounts.currentBalanceMinor} + ${deltaMinor}` })
    .where(eq(schema.financialAccounts.id, accountId))
    .run();
}

/** Adjusts a credit card's outstanding balance by a signed delta (minor units). */
export function adjustCreditCardOutstanding(tx: Tx, creditCardId: string, deltaMinor: number) {
  tx.update(schema.creditCards)
    .set({ outstandingMinor: sql`${schema.creditCards.outstandingMinor} + ${deltaMinor}` })
    .where(eq(schema.creditCards.id, creditCardId))
    .run();
}

/** Adjusts an investment's invested-amount and (optionally) current-value totals. */
export function adjustInvestment(
  tx: Tx,
  investmentId: string,
  deltaInvestedMinor: number,
  deltaCurrentValueMinor: number,
  deltaQuantityMilli = 0
) {
  tx.update(schema.investments)
    .set({
      investedAmountMinor: sql`${schema.investments.investedAmountMinor} + ${deltaInvestedMinor}`,
      currentValueMinor: sql`${schema.investments.currentValueMinor} + ${deltaCurrentValueMinor}`,
      quantity: sql`coalesce(${schema.investments.quantity}, 0) + ${deltaQuantityMilli}`,
    })
    .where(eq(schema.investments.id, investmentId))
    .run();
}

/** Reduces a loan's outstanding principal by a delta (minor units). */
export function adjustLoanOutstanding(tx: Tx, loanId: string, deltaMinor: number) {
  tx.update(schema.loans)
    .set({ outstandingMinor: sql`${schema.loans.outstandingMinor} + ${deltaMinor}` })
    .where(eq(schema.loans.id, loanId))
    .run();
}

/**
 * Reverses whatever ledger effect a given transaction row originally had.
 * This is the key to safe edits/deletes/undo: rather than special-casing
 * "how do I undo an EXPENSE vs a TRANSFER", we replay the same type-dispatch
 * logic with every delta negated.
 */
export function reverseTransactionEffect(tx: Tx, txn: typeof schema.transactions.$inferSelect) {
  applyTransactionEffect(tx, txn, -1);
}

export function applyTransactionEffect(
  tx: Tx,
  txn: typeof schema.transactions.$inferSelect,
  sign: 1 | -1 = 1
) {
  const amt = txn.amountMinor * sign;
  switch (txn.type) {
    case 'EXPENSE':
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, -amt);
      break;
    case 'INCOME':
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, amt);
      break;
    case 'TRANSFER':
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, -amt);
      if (txn.transferToAccountId) adjustAccountBalance(tx, txn.transferToAccountId, amt);
      break;
    case 'CC_PURCHASE':
      if (txn.creditCardId) adjustCreditCardOutstanding(tx, txn.creditCardId, amt);
      break;
    case 'CC_PAYMENT':
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, -amt);
      if (txn.creditCardId) adjustCreditCardOutstanding(tx, txn.creditCardId, -amt);
      break;
    case 'INVESTMENT_PURCHASE':
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, -amt);
      if (txn.investmentId) adjustInvestment(tx, txn.investmentId, amt, amt);
      break;
    case 'INVESTMENT_SALE':
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, amt);
      if (txn.investmentId) adjustInvestment(tx, txn.investmentId, -amt, -amt);
      break;
    case 'LOAN_PAYMENT': {
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, -amt);
      // Only the principal portion reduces the loan's outstanding balance;
      // interest is expense-only and never touches the loan liability.
      const principalMinor = getLoanPrincipalForTransaction(tx, txn.id);
      if (txn.loanId && principalMinor) {
        adjustLoanOutstanding(tx, txn.loanId, -principalMinor * sign);
      }
      break;
    }
    case 'REFUND':
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, amt);
      break;
    case 'ADJUSTMENT': {
      const signedAmt = amt * txn.direction;
      if (txn.accountId) adjustAccountBalance(tx, txn.accountId, signedAmt);
      if (txn.creditCardId) adjustCreditCardOutstanding(tx, txn.creditCardId, signedAmt);
      break;
    }
  }
}
