import { and, eq, gte, lte, like, desc, asc, sql, inArray, isNull } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { toMinor } from '@/lib/money';
import type { TenantContext } from '@/lib/tenant';
import { AmbiguousMatchError } from '@/lib/api-error';
import type { TransactionType } from '@/lib/enums';

export interface TransactionFilter {
  merchant?: string;
  categoryId?: string;
  accountId?: string;
  creditCardId?: string;
  type?: TransactionType;
  types?: TransactionType[];
  amountMinMajor?: number;
  amountMaxMajor?: number;
  dateFrom?: Date;
  dateTo?: Date;
  isBusiness?: boolean;
  isTaxRelated?: boolean;
  currency?: string;
  freeText?: string;
}

export interface SearchOptions {
  page?: number;
  pageSize?: number;
  sortBy?: 'occurredAt' | 'amountMinor';
  sortDir?: 'asc' | 'desc';
}

function buildWhere(workspaceId: string, filter: TransactionFilter) {
  const conditions = [eq(schema.transactions.workspaceId, workspaceId), isNull(schema.transactions.deletedAt)];

  if (filter.merchant) conditions.push(like(schema.transactions.merchant, `%${filter.merchant}%`));
  if (filter.categoryId) conditions.push(eq(schema.transactions.categoryId, filter.categoryId));
  if (filter.accountId) conditions.push(eq(schema.transactions.accountId, filter.accountId));
  if (filter.creditCardId) conditions.push(eq(schema.transactions.creditCardId, filter.creditCardId));
  if (filter.type) conditions.push(eq(schema.transactions.type, filter.type));
  if (filter.types && filter.types.length > 0) conditions.push(inArray(schema.transactions.type, filter.types));
  if (filter.amountMinMajor !== undefined)
    conditions.push(gte(schema.transactions.amountMinor, toMinor(filter.amountMinMajor, filter.currency ?? 'INR')));
  if (filter.amountMaxMajor !== undefined)
    conditions.push(lte(schema.transactions.amountMinor, toMinor(filter.amountMaxMajor, filter.currency ?? 'INR')));
  if (filter.dateFrom) conditions.push(gte(schema.transactions.occurredAt, filter.dateFrom));
  if (filter.dateTo) conditions.push(lte(schema.transactions.occurredAt, filter.dateTo));
  if (filter.isBusiness !== undefined) conditions.push(eq(schema.transactions.isBusiness, filter.isBusiness));
  if (filter.isTaxRelated !== undefined) conditions.push(eq(schema.transactions.isTaxRelated, filter.isTaxRelated));
  if (filter.freeText) {
    conditions.push(
      sql`(${schema.transactions.merchant} LIKE ${'%' + filter.freeText + '%'} OR ${schema.transactions.description} LIKE ${'%' + filter.freeText + '%'} OR ${schema.transactions.notes} LIKE ${'%' + filter.freeText + '%'})`
    );
  }

  return and(...conditions);
}

/** Server-side paginated search — never returns the whole table to the
 * client or the LLM (spec §76). */
export async function searchTransactions(
  tenant: TenantContext,
  filter: TransactionFilter,
  options: SearchOptions = {}
) {
  const page = options.page ?? 1;
  const pageSize = Math.min(options.pageSize ?? 50, 200);
  const sortCol = options.sortBy === 'amountMinor' ? schema.transactions.amountMinor : schema.transactions.occurredAt;
  const sortFn = options.sortDir === 'asc' ? asc : desc;

  const where = buildWhere(tenant.workspaceId, filter);

  const [items, totalRow] = await Promise.all([
    db
      .select()
      .from(schema.transactions)
      .where(where)
      .orderBy(sortFn(sortCol))
      .limit(pageSize)
      .offset((page - 1) * pageSize),
    db.select({ count: sql<number>`count(*)` }).from(schema.transactions).where(where),
  ]);

  return { items, total: totalRow[0]?.count ?? 0, page, pageSize };
}

/** Powers the AI "show my expenses by category" report (spec §49) and the
 * analytics category-breakdown chart. All math happens in SQL, never in the LLM. */
export async function getCategoryBreakdown(tenant: TenantContext, filter: TransactionFilter) {
  const where = buildWhere(tenant.workspaceId, filter);

  const rows = await db
    .select({
      categoryId: schema.transactions.categoryId,
      categoryName: schema.categories.name,
      count: sql<number>`count(*)`,
      totalMinor: sql<number>`sum(${schema.transactions.amountMinor})`,
    })
    .from(schema.transactions)
    .leftJoin(schema.categories, eq(schema.transactions.categoryId, schema.categories.id))
    .where(where)
    .groupBy(schema.transactions.categoryId, schema.categories.name)
    .orderBy(desc(sql`sum(${schema.transactions.amountMinor})`));

  const grandTotalMinor = rows.reduce((sum, r) => sum + (r.totalMinor ?? 0), 0);
  return { rows, grandTotalMinor };
}

export interface AmbiguousCandidate {
  id: string;
  merchant: string | null;
  amountMinor: number;
  occurredAt: Date;
  categoryName: string | null;
}

/**
 * Resolves a chat reference like "my Amazon transaction" to exactly one row,
 * or throws AmbiguousMatchError with the candidate list (spec §41 — "never
 * guess"). Narrows by merchant + optional amount/date hints; if more than
 * one candidate remains, the caller must ask the user to disambiguate.
 */
export async function findTransactionForChatReference(
  tenant: TenantContext,
  hints: { merchant?: string; amountMajor?: number; dateFrom?: Date; dateTo?: Date; type?: TransactionType }
) {
  const filter: TransactionFilter = {
    merchant: hints.merchant,
    amountMinMajor: hints.amountMajor,
    amountMaxMajor: hints.amountMajor,
    dateFrom: hints.dateFrom,
    dateTo: hints.dateTo,
    type: hints.type,
  };
  const { items } = await searchTransactions(tenant, filter, { pageSize: 10 });

  if (items.length === 0) return null;
  if (items.length === 1) return items[0];

  const categoryIds = [...new Set(items.map((i) => i.categoryId).filter(Boolean))] as string[];
  const categories = categoryIds.length
    ? await db.select().from(schema.categories).where(inArray(schema.categories.id, categoryIds))
    : [];
  const categoryMap = new Map(categories.map((c) => [c.id, c.name]));

  const candidates: AmbiguousCandidate[] = items.map((i) => ({
    id: i.id,
    merchant: i.merchant,
    amountMinor: i.amountMinor,
    occurredAt: i.occurredAt,
    categoryName: i.categoryId ? categoryMap.get(i.categoryId) ?? null : null,
  }));

  throw new AmbiguousMatchError(
    `${items.length} matching transactions found — which one did you mean?`,
    candidates
  );
}
