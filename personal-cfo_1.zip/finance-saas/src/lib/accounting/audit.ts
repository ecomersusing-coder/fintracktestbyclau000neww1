import { schema } from '@/db/client';
import type { Tx } from './tx-type';

export interface AuditEntry {
  workspaceId: string;
  userId?: string;
  actorType: 'USER' | 'AI' | 'SYSTEM' | 'ADMIN';
  action: string;
  entityType: string;
  entityId?: string;
  before?: unknown;
  after?: unknown;
  requestText?: string;
}

/** Every mutation in the accounting engine writes one of these, in the same
 * DB transaction as the mutation itself, so audit and data can never drift
 * apart (spec §62 — "AI actions must be traceable"). */
export function writeAuditLog(tx: Tx, entry: AuditEntry) {
  tx.insert(schema.auditLogs)
    .values({
      workspaceId: entry.workspaceId,
      userId: entry.userId,
      actorType: entry.actorType,
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId,
      before: entry.before !== undefined ? JSON.stringify(entry.before) : null,
      after: entry.after !== undefined ? JSON.stringify(entry.after) : null,
      requestText: entry.requestText,
    })
    .run();
}
