import { eq, and, like } from 'drizzle-orm';
import { schema } from '@/db/client';
import type { Tx } from './tx-type';

export interface CategorySuggestion {
  categoryId: string;
  confidence: number; // 0..1
  ruleId?: string;
}

const HIGH_CONFIDENCE = 0.8;

/**
 * Looks up the workspace's learned ai_category_rules first (spec §30 —
 * "if user repeatedly changes Amazon -> Business, learn this behavior"),
 * then falls back to a small built-in merchant keyword map. Returns null
 * if nothing matches — callers must never silently guess (spec §31).
 */
export function suggestCategory(tx: Tx, workspaceId: string, merchant: string | undefined): CategorySuggestion | null {
  if (!merchant) return null;
  const m = merchant.trim().toLowerCase();
  if (!m) return null;

  const rules = tx
    .select()
    .from(schema.aiCategoryRules)
    .where(eq(schema.aiCategoryRules.workspaceId, workspaceId))
    .all();

  for (const rule of rules) {
    const value = rule.matchValue.toLowerCase();
    const isMatch =
      rule.matchType === 'MERCHANT_EXACT' ? m === value : m.includes(value) || value.includes(m);
    if (isMatch) {
      return { categoryId: rule.categoryId, confidence: rule.confidenceBps / 10000, ruleId: rule.id };
    }
  }

  const builtIn = BUILT_IN_MERCHANT_KEYWORDS.find(([keyword]) => m.includes(keyword));
  if (!builtIn) return null;

  const category = tx
    .select()
    .from(schema.categories)
    .where(and(eq(schema.categories.name, builtIn[1]), eq(schema.categories.isSystem, true)))
    .get();
  if (!category) return null;

  return { categoryId: category.id, confidence: 0.6 };
}

export function isHighConfidence(suggestion: CategorySuggestion): boolean {
  return suggestion.confidence >= HIGH_CONFIDENCE;
}

/** Records that a user corrected merchant -> category, strengthening future
 *  suggestions (spec §30). Called from updateTransaction when categoryId changes. */
export function learnCategoryCorrection(
  tx: Tx,
  workspaceId: string,
  merchant: string | undefined,
  categoryId: string
) {
  if (!merchant) return;
  const value = merchant.trim().toLowerCase();
  if (!value) return;

  const existing = tx
    .select()
    .from(schema.aiCategoryRules)
    .where(and(eq(schema.aiCategoryRules.workspaceId, workspaceId), eq(schema.aiCategoryRules.matchValue, value)))
    .get();

  if (existing) {
    tx.update(schema.aiCategoryRules)
      .set({
        categoryId,
        timesApplied: existing.timesApplied + 1,
        confidenceBps: Math.min(10000, existing.confidenceBps + 500),
      })
      .where(eq(schema.aiCategoryRules.id, existing.id))
      .run();
  } else {
    tx.insert(schema.aiCategoryRules)
      .values({
        workspaceId,
        matchType: 'MERCHANT_CONTAINS',
        matchValue: value,
        categoryId,
        confidenceBps: 7000,
        timesApplied: 1,
      })
      .run();
  }
}

const BUILT_IN_MERCHANT_KEYWORDS: [string, string][] = [
  ['netflix', 'Subscriptions'],
  ['spotify', 'Subscriptions'],
  ['prime video', 'Subscriptions'],
  ['hotstar', 'Subscriptions'],
  ['swiggy', 'Restaurants'],
  ['zomato', 'Restaurants'],
  ['petrol', 'Fuel'],
  ['fuel', 'Fuel'],
  ['hp petrol', 'Fuel'],
  ['indian oil', 'Fuel'],
  ['amazon', 'Shopping'],
  ['flipkart', 'Shopping'],
  ['myntra', 'Shopping'],
  ['adobe', 'Subscriptions'],
  ['uber', 'Transport'],
  ['ola', 'Transport'],
  ['lulu', 'Groceries'],
  ['big bazaar', 'Groceries'],
  ['dmart', 'Groceries'],
  ['reliance fresh', 'Groceries'],
  ['airtel', 'Phone'],
  ['jio', 'Phone'],
  ['electricity', 'Utilities'],
  ['bescom', 'Utilities'],
];
