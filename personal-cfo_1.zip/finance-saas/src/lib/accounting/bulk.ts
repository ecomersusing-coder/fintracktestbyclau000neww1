import { eq, inArray } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import type { TenantContext } from '@/lib/tenant';
import { assertCategoryOwnership } from './ownership';
import { attachTags } from './tags';
import { writeAuditLog } from './audit';
import { buildBulkWhere } from './bulk-where';
import type { BulkUpdateTransactionsInput } from './types';

export interface BulkPreview {
  matchCount: number;
  totalAffectedMinor: number;
  currency: string;
  sampleIds: string[];
}

/** Step 1 of the required preview -> confirm -> execute flow (spec §40). Never
 * mutates anything — just tells the caller what a bulk update WOULD do. */
export async function previewBulkUpdate(tenant: TenantContext, filter: BulkUpdateTransactionsInput['filter']): Promise<BulkPreview> {
  const where = buildBulkWhere(tenant.workspaceId, filter);
  const rows = await db.select().from(schema.transactions).where(where);
  const totalAffectedMinor = rows.reduce((sum, r) => sum + r.amountMinor, 0);
  return {
    matchCount: rows.length,
    totalAffectedMinor,
    currency: rows[0]?.currency ?? 'INR',
    sampleIds: rows.slice(0, 5).map((r) => r.id),
  };
}

/** Step 2 — only called after the user has confirmed the preview shown by
 * previewBulkUpdate. Applies the patch to every matching row atomically and
 * writes one audit log per affected row so it stays traceable and undoable
 * per-row (spec §40 "record audit log"). */
export async function executeBulkUpdate(tenant: TenantContext, input: BulkUpdateTransactionsInput) {
  return db.transaction((tx) => {
    if (input.patch.categoryId) assertCategoryOwnership(tx, tenant.workspaceId, input.patch.categoryId);

    const where = buildBulkWhere(tenant.workspaceId, input.filter);
    const rows = tx.select().from(schema.transactions).where(where).all();

    if (rows.length === 0) {
      return { updatedCount: 0, totalAffectedMinor: 0 };
    }

    const ids = rows.map((r) => r.id);
    tx.update(schema.transactions)
      .set({
        categoryId: input.patch.categoryId ?? undefined,
        isBusiness: input.patch.isBusiness ?? undefined,
        isTaxRelated: input.patch.isTaxRelated ?? undefined,
      })
      .where(inArray(schema.transactions.id, ids))
      .run();

    for (const row of rows) {
      if (input.patch.addTagNames) attachTags(tx, tenant.workspaceId, row.id, input.patch.addTagNames);
      writeAuditLog(tx, {
        workspaceId: tenant.workspaceId,
        userId: tenant.userId,
        actorType: 'USER',
        action: 'transaction.bulk_update',
        entityType: 'transaction',
        entityId: row.id,
        before: row,
        after: { ...row, ...input.patch },
      });
    }

    const totalAffectedMinor = rows.reduce((sum, r) => sum + r.amountMinor, 0);
    return { updatedCount: rows.length, totalAffectedMinor };
  });
}
