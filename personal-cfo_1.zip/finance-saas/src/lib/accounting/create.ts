import { db, schema } from '@/db/client';
import { toMinor } from '@/lib/money';
import type { TenantContext } from '@/lib/tenant';
import {
  adjustAccountBalance,
  adjustCreditCardOutstanding,
  adjustInvestment,
  adjustLoanOutstanding,
} from './ledger';
import {
  assertAccountOwnership,
  assertCategoryOwnership,
  assertCreditCardOwnership,
  assertInvestmentOwnership,
  assertLoanOwnership,
} from './ownership';
import { attachTags } from './tags';
import { writeAuditLog } from './audit';
import { suggestCategory, isHighConfidence } from './categorize';
import { checkAndIncrementUsage } from '@/lib/billing/usage';
import type {
  CreateExpenseInput,
  CreateIncomeInput,
  CreateTransferInput,
  CreateCreditCardPaymentInput,
  CreateInvestmentPurchaseInput,
  CreateInvestmentSaleInput,
  CreateLoanPaymentInput,
  CreateRefundInput,
  CreateAdjustmentInput,
} from './types';

export interface CreateResult {
  transaction: typeof schema.transactions.$inferSelect;
  categorySuggestion?: { categoryId: string; confidence: number; needsConfirmation: boolean };
}

export async function createExpense(tenant: TenantContext, input: CreateExpenseInput): Promise<CreateResult> {
  await checkAndIncrementUsage(tenant.workspaceId, 'transactions');
  const amountMinor = toMinor(input.amountMajor, input.currency);

  return db.transaction((tx) => {
    if (input.accountId) assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    if (input.creditCardId) assertCreditCardOwnership(tx, tenant.workspaceId, input.creditCardId);

    let categoryId = input.categoryId;
    let suggestion = null as ReturnType<typeof suggestCategory>;
    if (!categoryId) {
      suggestion = suggestCategory(tx, tenant.workspaceId, input.merchant);
      if (suggestion && isHighConfidence(suggestion)) categoryId = suggestion.categoryId;
    }
    if (categoryId) assertCategoryOwnership(tx, tenant.workspaceId, categoryId);

    const type = input.accountId ? 'EXPENSE' : 'CC_PURCHASE';

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type,
        amountMinor,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.accountId,
        creditCardId: input.creditCardId,
        categoryId,
        merchant: input.merchant,
        description: input.description,
        notes: input.notes,
        paymentMethod: input.paymentMethod,
        isEssential: input.isEssential,
        isBusiness: input.isBusiness,
        isTaxRelated: input.isTaxRelated,
        source: input.source,
        aiConversationId: input.aiConversationId,
      })
      .returning()
      .get();

    if (input.accountId) adjustAccountBalance(tx, input.accountId, -amountMinor);
    if (input.creditCardId) adjustCreditCardOutstanding(tx, input.creditCardId, amountMinor);

    attachTags(tx, tenant.workspaceId, txn.id, input.tagNames);
    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: input.source === 'AI_CHAT' ? 'AI' : 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
    });

    return {
      transaction: txn,
      categorySuggestion:
        suggestion && !isHighConfidence(suggestion)
          ? { categoryId: suggestion.categoryId, confidence: suggestion.confidence, needsConfirmation: true }
          : undefined,
    };
  });
}

export async function createIncome(tenant: TenantContext, input: CreateIncomeInput): Promise<CreateResult> {
  await checkAndIncrementUsage(tenant.workspaceId, 'transactions');
  const amountMinor = toMinor(input.amountMajor, input.currency);

  return db.transaction((tx) => {
    assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    if (input.categoryId) assertCategoryOwnership(tx, tenant.workspaceId, input.categoryId);

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type: 'INCOME',
        amountMinor,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.accountId,
        categoryId: input.categoryId,
        merchant: input.merchant,
        description: input.description,
        notes: input.notes,
        source: input.source,
        aiConversationId: input.aiConversationId,
      })
      .returning()
      .get();

    adjustAccountBalance(tx, input.accountId, amountMinor);
    attachTags(tx, tenant.workspaceId, txn.id, input.tagNames);
    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: input.source === 'AI_CHAT' ? 'AI' : 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
    });

    return { transaction: txn };
  });
}

export async function createTransfer(tenant: TenantContext, input: CreateTransferInput): Promise<CreateResult> {
  await checkAndIncrementUsage(tenant.workspaceId, 'transactions');
  const amountMinor = toMinor(input.amountMajor, input.currency);

  return db.transaction((tx) => {
    assertAccountOwnership(tx, tenant.workspaceId, input.fromAccountId);
    assertAccountOwnership(tx, tenant.workspaceId, input.toAccountId);

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type: 'TRANSFER',
        amountMinor,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.fromAccountId,
        transferToAccountId: input.toAccountId,
        description: input.description,
        notes: input.notes,
        source: input.source,
        aiConversationId: input.aiConversationId,
      })
      .returning()
      .get();

    adjustAccountBalance(tx, input.fromAccountId, -amountMinor);
    adjustAccountBalance(tx, input.toAccountId, amountMinor);

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: input.source === 'AI_CHAT' ? 'AI' : 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
    });

    return { transaction: txn };
  });
}

export async function createCreditCardPayment(
  tenant: TenantContext,
  input: CreateCreditCardPaymentInput
): Promise<CreateResult> {
  await checkAndIncrementUsage(tenant.workspaceId, 'transactions');
  const amountMinor = toMinor(input.amountMajor, input.currency);

  return db.transaction((tx) => {
    assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    assertCreditCardOwnership(tx, tenant.workspaceId, input.creditCardId);

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type: 'CC_PAYMENT',
        amountMinor,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.accountId,
        creditCardId: input.creditCardId,
        description: input.description ?? 'Credit card payment',
        notes: input.notes,
        source: input.source,
        aiConversationId: input.aiConversationId,
      })
      .returning()
      .get();

    // Bank -= amount, Card liability -= amount. Expense is unchanged (spec §15 ex.2).
    adjustAccountBalance(tx, input.accountId, -amountMinor);
    adjustCreditCardOutstanding(tx, input.creditCardId, -amountMinor);

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: input.source === 'AI_CHAT' ? 'AI' : 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
    });

    return { transaction: txn };
  });
}

export async function createInvestmentPurchase(
  tenant: TenantContext,
  input: CreateInvestmentPurchaseInput
): Promise<CreateResult> {
  await checkAndIncrementUsage(tenant.workspaceId, 'transactions');
  const amountMinor = toMinor(input.amountMajor, input.currency);
  const qtyMilli = input.quantity ? Math.round(input.quantity * 1000) : 0;

  return db.transaction((tx) => {
    assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    assertInvestmentOwnership(tx, tenant.workspaceId, input.investmentId);

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type: 'INVESTMENT_PURCHASE',
        amountMinor,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.accountId,
        investmentId: input.investmentId,
        description: input.description,
        notes: input.notes,
        source: input.source,
        aiConversationId: input.aiConversationId,
      })
      .returning()
      .get();

    adjustAccountBalance(tx, input.accountId, -amountMinor);
    adjustInvestment(tx, input.investmentId, amountMinor, amountMinor, qtyMilli);

    tx.insert(schema.investmentTransactions)
      .values({
        investmentId: input.investmentId,
        transactionId: txn.id,
        type: 'BUY',
        quantityMilli: qtyMilli || null,
        amountMinor,
        occurredAt: input.occurredAt,
      })
      .run();

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: input.source === 'AI_CHAT' ? 'AI' : 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
    });

    return { transaction: txn };
  });
}

export async function createInvestmentSale(
  tenant: TenantContext,
  input: CreateInvestmentSaleInput
): Promise<CreateResult> {
  await checkAndIncrementUsage(tenant.workspaceId, 'transactions');
  const amountMinor = toMinor(input.amountMajor, input.currency);
  const qtyMilli = input.quantity ? Math.round(input.quantity * 1000) : 0;

  return db.transaction((tx) => {
    assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    assertInvestmentOwnership(tx, tenant.workspaceId, input.investmentId);

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type: 'INVESTMENT_SALE',
        amountMinor,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.accountId,
        investmentId: input.investmentId,
        description: input.description,
        notes: input.notes,
        source: input.source,
        aiConversationId: input.aiConversationId,
      })
      .returning()
      .get();

    adjustAccountBalance(tx, input.accountId, amountMinor);
    adjustInvestment(tx, input.investmentId, -amountMinor, -amountMinor, -qtyMilli);

    tx.insert(schema.investmentTransactions)
      .values({
        investmentId: input.investmentId,
        transactionId: txn.id,
        type: 'SELL',
        quantityMilli: qtyMilli || null,
        amountMinor,
        occurredAt: input.occurredAt,
      })
      .run();

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: input.source === 'AI_CHAT' ? 'AI' : 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
    });

    return { transaction: txn };
  });
}

export async function createLoanPayment(tenant: TenantContext, input: CreateLoanPaymentInput): Promise<CreateResult> {
  await checkAndIncrementUsage(tenant.workspaceId, 'transactions');
  const principalMinor = toMinor(input.principalMajor, input.currency);
  const interestMinor = toMinor(input.interestMajor, input.currency);
  const amountMinor = principalMinor + interestMinor;

  return db.transaction((tx) => {
    assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    assertLoanOwnership(tx, tenant.workspaceId, input.loanId);

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type: 'LOAN_PAYMENT',
        amountMinor,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.accountId,
        loanId: input.loanId,
        description: input.description ?? 'Loan payment',
        notes: input.notes,
        source: input.source,
        aiConversationId: input.aiConversationId,
      })
      .returning()
      .get();

    adjustAccountBalance(tx, input.accountId, -amountMinor);
    adjustLoanOutstanding(tx, input.loanId, -principalMinor);

    tx.insert(schema.loanPayments)
      .values({
        loanId: input.loanId,
        transactionId: txn.id,
        amountMinor,
        principalMinor,
        interestMinor,
        paidAt: input.occurredAt,
      })
      .run();

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: input.source === 'AI_CHAT' ? 'AI' : 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
    });

    return { transaction: txn };
  });
}

export async function createRefund(tenant: TenantContext, input: CreateRefundInput): Promise<CreateResult> {
  await checkAndIncrementUsage(tenant.workspaceId, 'transactions');
  const amountMinor = toMinor(input.amountMajor, input.currency);

  return db.transaction((tx) => {
    assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    if (input.categoryId) assertCategoryOwnership(tx, tenant.workspaceId, input.categoryId);

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type: 'REFUND',
        amountMinor,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.accountId,
        categoryId: input.categoryId,
        relatedTransactionId: input.relatedTransactionId,
        merchant: input.merchant,
        description: input.description,
        notes: input.notes,
        source: input.source,
        aiConversationId: input.aiConversationId,
      })
      .returning()
      .get();

    adjustAccountBalance(tx, input.accountId, amountMinor);

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: input.source === 'AI_CHAT' ? 'AI' : 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
    });

    return { transaction: txn };
  });
}

export async function createAdjustment(tenant: TenantContext, input: CreateAdjustmentInput): Promise<CreateResult> {
  const amountMinor = toMinor(input.amountMajor, input.currency);

  return db.transaction((tx) => {
    if (input.accountId) assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    if (input.creditCardId) assertCreditCardOwnership(tx, tenant.workspaceId, input.creditCardId);

    const txn = tx
      .insert(schema.transactions)
      .values({
        workspaceId: tenant.workspaceId,
        type: 'ADJUSTMENT',
        amountMinor,
        direction: input.direction,
        currency: input.currency,
        occurredAt: input.occurredAt,
        accountId: input.accountId,
        creditCardId: input.creditCardId,
        description: input.description ?? `Manual adjustment: ${input.reason}`,
        notes: input.notes,
        source: input.source,
      })
      .returning()
      .get();

    const signedAmt = amountMinor * input.direction;
    if (input.accountId) adjustAccountBalance(tx, input.accountId, signedAmt);
    if (input.creditCardId) adjustCreditCardOutstanding(tx, input.creditCardId, signedAmt);

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: 'USER',
      action: 'transaction.create',
      entityType: 'transaction',
      entityId: txn.id,
      after: txn,
      requestText: input.reason,
    });

    return { transaction: txn };
  });
}
