import { z } from 'zod';
import { transactionSourceSchema } from '@/lib/enums';

// Shared optional metadata every write operation accepts.
const commonFields = {
  categoryId: z.string().optional(),
  merchant: z.string().max(200).optional(),
  description: z.string().max(1000).optional(),
  notes: z.string().max(2000).optional(),
  paymentMethod: z.string().max(100).optional(),
  isEssential: z.boolean().optional(),
  isBusiness: z.boolean().optional(),
  isTaxRelated: z.boolean().optional(),
  tagNames: z.array(z.string().max(50)).max(20).optional(),
  source: transactionSourceSchema.default('MANUAL'),
  aiConversationId: z.string().optional(),
  occurredAt: z.coerce.date(),
  amountMajor: z.number().positive(),
  currency: z.string().length(3).default('INR'),
};

export const createExpenseSchema = z
  .object({
    accountId: z.string().optional(),
    creditCardId: z.string().optional(),
    ...commonFields,
  })
  .refine((v) => Boolean(v.accountId) !== Boolean(v.creditCardId), {
    message: 'Provide exactly one of accountId or creditCardId',
  });
export type CreateExpenseInput = z.infer<typeof createExpenseSchema>;

export const createIncomeSchema = z.object({
  accountId: z.string(),
  ...commonFields,
});
export type CreateIncomeInput = z.infer<typeof createIncomeSchema>;

export const createTransferSchema = z
  .object({
    fromAccountId: z.string(),
    toAccountId: z.string(),
    ...commonFields,
  })
  .refine((v) => v.fromAccountId !== v.toAccountId, {
    message: 'Source and destination accounts must differ',
  });
export type CreateTransferInput = z.infer<typeof createTransferSchema>;

export const createCreditCardPaymentSchema = z.object({
  accountId: z.string(),
  creditCardId: z.string(),
  ...commonFields,
});
export type CreateCreditCardPaymentInput = z.infer<typeof createCreditCardPaymentSchema>;

export const createInvestmentPurchaseSchema = z.object({
  accountId: z.string(),
  investmentId: z.string(),
  quantity: z.number().positive().optional(),
  ...commonFields,
});
export type CreateInvestmentPurchaseInput = z.infer<typeof createInvestmentPurchaseSchema>;

export const createInvestmentSaleSchema = z.object({
  accountId: z.string(),
  investmentId: z.string(),
  quantity: z.number().positive().optional(),
  ...commonFields,
});
export type CreateInvestmentSaleInput = z.infer<typeof createInvestmentSaleSchema>;

export const createLoanPaymentSchema = z.object({
  accountId: z.string(),
  loanId: z.string(),
  principalMajor: z.number().nonnegative(),
  interestMajor: z.number().nonnegative(),
  ...commonFields,
});
export type CreateLoanPaymentInput = z.infer<typeof createLoanPaymentSchema>;

export const createRefundSchema = z.object({
  accountId: z.string(),
  relatedTransactionId: z.string().optional(),
  ...commonFields,
});
export type CreateRefundInput = z.infer<typeof createRefundSchema>;

export const createAdjustmentSchema = z
  .object({
    accountId: z.string().optional(),
    creditCardId: z.string().optional(),
    direction: z.union([z.literal(1), z.literal(-1)]),
    reason: z.string().min(1),
    ...commonFields,
  })
  .refine((v) => Boolean(v.accountId) !== Boolean(v.creditCardId), {
    message: 'Provide exactly one of accountId or creditCardId',
  });
export type CreateAdjustmentInput = z.infer<typeof createAdjustmentSchema>;

export const updateTransactionSchema = z.object({
  transactionId: z.string(),
  amountMajor: z.number().positive().optional(),
  occurredAt: z.coerce.date().optional(),
  accountId: z.string().optional(),
  creditCardId: z.string().optional(),
  categoryId: z.string().optional(),
  merchant: z.string().max(200).optional(),
  description: z.string().max(1000).optional(),
  notes: z.string().max(2000).optional(),
  isBusiness: z.boolean().optional(),
  isTaxRelated: z.boolean().optional(),
  isEssential: z.boolean().optional(),
  addTagNames: z.array(z.string().max(50)).optional(),
});
export type UpdateTransactionInput = z.infer<typeof updateTransactionSchema>;

export const bulkUpdateFilterSchema = z.object({
  merchant: z.string().optional(),
  categoryId: z.string().optional(),
  type: z.string().optional(),
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
});

export const bulkUpdatePatchSchema = z.object({
  categoryId: z.string().optional(),
  isBusiness: z.boolean().optional(),
  isTaxRelated: z.boolean().optional(),
  addTagNames: z.array(z.string().max(50)).optional(),
});

export const bulkUpdateTransactionsSchema = z.object({
  filter: bulkUpdateFilterSchema,
  patch: bulkUpdatePatchSchema,
});
export type BulkUpdateTransactionsInput = z.infer<typeof bulkUpdateTransactionsSchema>;
