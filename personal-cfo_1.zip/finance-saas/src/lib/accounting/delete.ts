import { eq, desc } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import type { TenantContext } from '@/lib/tenant';
import { AppError, NotFoundError } from '@/lib/api-error';
import { reverseTransactionEffect, applyTransactionEffect } from './ledger';
import { assertTransactionOwnership } from './ownership';
import { writeAuditLog } from './audit';

/** Soft-deletes a transaction and reverses its ledger effect. Never a hard
 * delete — spec §61/§62 requires everything to stay auditable/undoable. */
export async function deleteTransaction(tenant: TenantContext, transactionId: string) {
  return db.transaction((tx) => {
    const original = assertTransactionOwnership(tx, tenant.workspaceId, transactionId);

    reverseTransactionEffect(tx, original);

    tx.update(schema.transactions)
      .set({ deletedAt: new Date() })
      .where(eq(schema.transactions.id, transactionId))
      .run();

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: 'USER',
      action: 'transaction.delete',
      entityType: 'transaction',
      entityId: transactionId,
      before: original,
    });

    return { deleted: original };
  });
}

/**
 * Reverses the most recent AI/user change to a single transaction (spec
 * §43). Looks at the latest audit log row for that entity and replays it
 * backwards — create -> delete, delete -> restore, update -> restore prior
 * field values. Only reaches back one step by design: undo is a safety net
 * for "oops, not that one", not a full version history browser.
 */
export async function undoLastChange(tenant: TenantContext, transactionId: string) {
  return db.transaction((tx) => {
    const lastLog = tx
      .select()
      .from(schema.auditLogs)
      .where(eq(schema.auditLogs.entityId, transactionId))
      .orderBy(desc(schema.auditLogs.createdAt))
      .limit(1)
      .get();

    if (!lastLog || lastLog.workspaceId !== tenant.workspaceId) {
      throw new NotFoundError('Recent change');
    }

    if (lastLog.action === 'transaction.create') {
      const current = assertTransactionOwnership(tx, tenant.workspaceId, transactionId);
      reverseTransactionEffect(tx, current);
      tx.update(schema.transactions).set({ deletedAt: new Date() }).where(eq(schema.transactions.id, transactionId)).run();
    } else if (lastLog.action === 'transaction.delete') {
      const before = JSON.parse(lastLog.before ?? '{}') as typeof schema.transactions.$inferSelect;
      tx.update(schema.transactions).set({ deletedAt: null }).where(eq(schema.transactions.id, transactionId)).run();
      applyTransactionEffect(tx, before);
    } else if (lastLog.action === 'transaction.update') {
      const before = JSON.parse(lastLog.before ?? '{}') as typeof schema.transactions.$inferSelect;
      const current = assertTransactionOwnership(tx, tenant.workspaceId, transactionId);
      reverseTransactionEffect(tx, current);
      tx.update(schema.transactions)
        .set({
          amountMinor: before.amountMinor,
          occurredAt: new Date(before.occurredAt),
          accountId: before.accountId,
          creditCardId: before.creditCardId,
          categoryId: before.categoryId,
          merchant: before.merchant,
          description: before.description,
          notes: before.notes,
          isBusiness: before.isBusiness,
          isTaxRelated: before.isTaxRelated,
          isEssential: before.isEssential,
        })
        .where(eq(schema.transactions.id, transactionId))
        .run();
      applyTransactionEffect(tx, before);
    } else {
      throw new AppError('Nothing to undo for this transaction.', 422);
    }

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: 'USER',
      action: 'transaction.undo',
      entityType: 'transaction',
      entityId: transactionId,
      before: lastLog,
    });

    const fresh = tx.select().from(schema.transactions).where(eq(schema.transactions.id, transactionId)).get();
    return fresh;
  });
}
