import { and, eq, gte, lte, like, isNull } from 'drizzle-orm';
import { schema } from '@/db/client';
import type { BulkUpdateTransactionsInput } from './types';

export function buildBulkWhere(workspaceId: string, filter: BulkUpdateTransactionsInput['filter']) {
  const conditions = [eq(schema.transactions.workspaceId, workspaceId), isNull(schema.transactions.deletedAt)];
  if (filter.merchant) conditions.push(like(schema.transactions.merchant, `%${filter.merchant}%`));
  if (filter.categoryId) conditions.push(eq(schema.transactions.categoryId, filter.categoryId));
  if (filter.type) conditions.push(eq(schema.transactions.type, filter.type));
  if (filter.dateFrom) conditions.push(gte(schema.transactions.occurredAt, filter.dateFrom));
  if (filter.dateTo) conditions.push(lte(schema.transactions.occurredAt, filter.dateTo));
  return and(...conditions);
}
