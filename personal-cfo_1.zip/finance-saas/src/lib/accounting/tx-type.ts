import type { db } from '@/db/client';

/** The transaction-scoped db handle type, as given to db.transaction(cb). */
export type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
