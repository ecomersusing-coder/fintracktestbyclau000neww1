import { eq } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { toMinor } from '@/lib/money';
import type { TenantContext } from '@/lib/tenant';
import { AppError, NotFoundError } from '@/lib/api-error';
import { reverseTransactionEffect, applyTransactionEffect } from './ledger';
import { assertTransactionOwnership, assertAccountOwnership, assertCreditCardOwnership, assertCategoryOwnership } from './ownership';
import { writeAuditLog } from './audit';
import { learnCategoryCorrection } from './categorize';
import { attachTags } from './tags';
import type { UpdateTransactionInput } from './types';

/**
 * The safe way to edit any ledger-affecting field: reverse the transaction's
 * current effect on balances, apply the patch, then re-apply the (now
 * updated) effect — all inside one DB transaction. This means every edit
 * path (chat-based or UI-based) goes through the same correctness guarantee
 * as create, instead of hand-computing a delta per field.
 */
export async function updateTransaction(tenant: TenantContext, input: UpdateTransactionInput) {
  return db.transaction((tx) => {
    const original = assertTransactionOwnership(tx, tenant.workspaceId, input.transactionId);

    if (input.accountId && !original.accountId) {
      throw new AppError('This transaction has no bank/cash account leg to move.', 422);
    }
    if (input.creditCardId && !original.creditCardId) {
      throw new AppError('This transaction has no credit card leg to move.', 422);
    }
    if (input.accountId) assertAccountOwnership(tx, tenant.workspaceId, input.accountId);
    if (input.creditCardId) assertCreditCardOwnership(tx, tenant.workspaceId, input.creditCardId);
    if (input.categoryId) assertCategoryOwnership(tx, tenant.workspaceId, input.categoryId);

    // 1. Reverse the original effect on account/card/investment/loan balances.
    reverseTransactionEffect(tx, original);

    const updated = {
      ...original,
      amountMinor: input.amountMajor !== undefined ? toMinor(input.amountMajor, original.currency) : original.amountMinor,
      occurredAt: input.occurredAt ?? original.occurredAt,
      accountId: input.accountId ?? original.accountId,
      creditCardId: input.creditCardId ?? original.creditCardId,
      categoryId: input.categoryId ?? original.categoryId,
      merchant: input.merchant ?? original.merchant,
      description: input.description ?? original.description,
      notes: input.notes ?? original.notes,
      isBusiness: input.isBusiness ?? original.isBusiness,
      isTaxRelated: input.isTaxRelated ?? original.isTaxRelated,
      isEssential: input.isEssential ?? original.isEssential,
      updatedAt: new Date(),
    };

    // 2. Persist the patch.
    tx.update(schema.transactions)
      .set({
        amountMinor: updated.amountMinor,
        occurredAt: updated.occurredAt,
        accountId: updated.accountId,
        creditCardId: updated.creditCardId,
        categoryId: updated.categoryId,
        merchant: updated.merchant,
        description: updated.description,
        notes: updated.notes,
        isBusiness: updated.isBusiness,
        isTaxRelated: updated.isTaxRelated,
        isEssential: updated.isEssential,
      })
      .where(eq(schema.transactions.id, original.id))
      .run();

    // 3. Re-apply the (possibly changed) effect with the new values.
    applyTransactionEffect(tx, updated);

    if (input.categoryId && input.categoryId !== original.categoryId) {
      learnCategoryCorrection(tx, tenant.workspaceId, updated.merchant ?? undefined, input.categoryId);
    }
    attachTags(tx, tenant.workspaceId, original.id, input.addTagNames);

    writeAuditLog(tx, {
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      actorType: 'USER',
      action: 'transaction.update',
      entityType: 'transaction',
      entityId: original.id,
      before: original,
      after: updated,
    });

    const fresh = tx.select().from(schema.transactions).where(eq(schema.transactions.id, original.id)).get();
    if (!fresh) throw new NotFoundError('Transaction');
    return { before: original, after: fresh };
  });
}
