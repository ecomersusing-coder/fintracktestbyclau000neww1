import { eq, and } from 'drizzle-orm';
import { schema } from '@/db/client';
import { NotFoundError } from '@/lib/api-error';
import type { Tx } from './tx-type';

/**
 * Every one of these MUST be called before touching a row, inside the same
 * DB transaction as the write. The #1 rule of this codebase: never trust an
 * id from the client without proving it belongs to the caller's workspace.
 */

export function assertAccountOwnership(tx: Tx, workspaceId: string, accountId: string) {
  const row = tx
    .select()
    .from(schema.financialAccounts)
    .where(and(eq(schema.financialAccounts.id, accountId), eq(schema.financialAccounts.workspaceId, workspaceId)))
    .get();
  if (!row) throw new NotFoundError('Account');
  return row;
}

export function assertCreditCardOwnership(tx: Tx, workspaceId: string, creditCardId: string) {
  const row = tx
    .select()
    .from(schema.creditCards)
    .where(and(eq(schema.creditCards.id, creditCardId), eq(schema.creditCards.workspaceId, workspaceId)))
    .get();
  if (!row) throw new NotFoundError('Credit card');
  return row;
}

export function assertCategoryOwnership(tx: Tx, workspaceId: string, categoryId: string) {
  const row = tx.select().from(schema.categories).where(eq(schema.categories.id, categoryId)).get();
  if (!row) throw new NotFoundError('Category');
  // Category is either global (workspaceId null) or must belong to this tenant.
  if (row.workspaceId && row.workspaceId !== workspaceId) throw new NotFoundError('Category');
  return row;
}

export function assertInvestmentOwnership(tx: Tx, workspaceId: string, investmentId: string) {
  const row = tx
    .select()
    .from(schema.investments)
    .where(and(eq(schema.investments.id, investmentId), eq(schema.investments.workspaceId, workspaceId)))
    .get();
  if (!row) throw new NotFoundError('Investment');
  return row;
}

export function assertLoanOwnership(tx: Tx, workspaceId: string, loanId: string) {
  const row = tx
    .select()
    .from(schema.loans)
    .where(and(eq(schema.loans.id, loanId), eq(schema.loans.workspaceId, workspaceId)))
    .get();
  if (!row) throw new NotFoundError('Loan');
  return row;
}

export function assertTransactionOwnership(tx: Tx, workspaceId: string, transactionId: string) {
  const row = tx
    .select()
    .from(schema.transactions)
    .where(and(eq(schema.transactions.id, transactionId), eq(schema.transactions.workspaceId, workspaceId)))
    .get();
  if (!row || row.deletedAt) throw new NotFoundError('Transaction');
  return row;
}
