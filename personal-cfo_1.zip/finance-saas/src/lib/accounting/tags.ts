import { eq, and } from 'drizzle-orm';
import { schema } from '@/db/client';
import type { Tx } from './tx-type';

export function attachTags(tx: Tx, workspaceId: string, transactionId: string, tagNames: string[] | undefined) {
  if (!tagNames || tagNames.length === 0) return;
  for (const rawName of tagNames) {
    const name = rawName.trim();
    if (!name) continue;
    let tag = tx
      .select()
      .from(schema.tags)
      .where(and(eq(schema.tags.workspaceId, workspaceId), eq(schema.tags.name, name)))
      .get();
    if (!tag) {
      tag = tx.insert(schema.tags).values({ workspaceId, name }).returning().get();
    }
    tx.insert(schema.transactionTags)
      .values({ transactionId, tagId: tag.id })
      .onConflictDoNothing()
      .run();
  }
}
