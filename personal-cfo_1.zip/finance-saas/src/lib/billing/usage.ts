import { eq, and } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { LimitExceededError } from '@/lib/api-error';

/** metric -> the PlanFeature key that caps it. null means "no limit exists for this metric". */
const METRIC_TO_FEATURE_KEY: Record<string, string> = {
  transactions: 'max_transactions_per_month',
  ai_messages: 'max_ai_messages_per_month',
  ai_tool_calls: 'max_ai_tool_calls_per_month',
  accounts: 'max_accounts',
  attachments: 'max_attachments_per_month',
  storage_bytes: 'max_storage_bytes',
  exports: 'max_exports_per_month',
};

function currentPeriod(): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  return { start, end };
}

/**
 * Checks the workspace's plan limit for `metric` and increments usage by
 * `amount` if under the limit. Throws LimitExceededError (HTTP 402) if not.
 * "accounts" is a standing-count metric (checked against current row count
 * elsewhere); everything else here is a monthly counter.
 */
export async function checkAndIncrementUsage(workspaceId: string, metric: string, amount = 1): Promise<void> {
  const featureKey = METRIC_TO_FEATURE_KEY[metric];
  if (!featureKey) return;

  const { start, end } = currentPeriod();

  const sub = await db.query.subscriptions.findFirst({
    where: eq(schema.subscriptions.workspaceId, workspaceId),
  });
  // No subscription row yet (e.g. workspace mid-onboarding) — don't block.
  if (!sub) return;

  const feature = await db.query.planFeatures.findFirst({
    where: and(eq(schema.planFeatures.planId, sub.planId), eq(schema.planFeatures.key, featureKey)),
  });
  const limit = feature?.limitValue ?? null; // null = unlimited

  db.transaction((tx) => {
    const existing = tx
      .select()
      .from(schema.usageRecords)
      .where(
        and(
          eq(schema.usageRecords.workspaceId, workspaceId),
          eq(schema.usageRecords.metric, metric),
          eq(schema.usageRecords.periodStart, start)
        )
      )
      .get();

    const currentValue = existing?.value ?? 0;
    if (limit !== null && currentValue + amount > limit) {
      throw new LimitExceededError(
        `You've reached your plan's monthly limit for ${metric.replace(/_/g, ' ')} (${limit}). Upgrade your plan to continue.`
      );
    }

    if (existing) {
      tx.update(schema.usageRecords)
        .set({ value: currentValue + amount })
        .where(eq(schema.usageRecords.id, existing.id))
        .run();
    } else {
      tx.insert(schema.usageRecords)
        .values({ workspaceId, metric, periodStart: start, periodEnd: end, value: amount })
        .run();
    }
  });
}

/**
 * For limits that are a standing COUNT (e.g. "max_accounts") rather than a
 * monthly counter — pass the current row count and this throws if adding
 * `amount` more would exceed the plan's limit. Unlike checkAndIncrementUsage,
 * this never writes anything; the caller's own insert is the source of truth.
 */
export async function checkStandingLimit(
  workspaceId: string,
  featureKey: string,
  currentCount: number,
  amount = 1
): Promise<void> {
  const sub = await db.query.subscriptions.findFirst({ where: eq(schema.subscriptions.workspaceId, workspaceId) });
  if (!sub) return;

  const feature = await db.query.planFeatures.findFirst({
    where: and(eq(schema.planFeatures.planId, sub.planId), eq(schema.planFeatures.key, featureKey)),
  });
  const limit = feature?.limitValue ?? null;
  if (limit !== null && currentCount + amount > limit) {
    throw new LimitExceededError(
      `Your plan allows up to ${limit} ${featureKey.replace('max_', '').replace(/_/g, ' ')}. Upgrade your plan to add more.`
    );
  }
}

/** Read-only usage snapshot for the usage-meter UI (spec §7). */
export async function getUsageSummary(workspaceId: string) {
  const { start, end } = currentPeriod();
  const sub = await db.query.subscriptions.findFirst({
    where: eq(schema.subscriptions.workspaceId, workspaceId),
  });
  if (!sub) return { plan: null, metrics: [] as ReturnType<typeof buildMetric>[] };

  const plan = await db.query.plans.findFirst({ where: eq(schema.plans.id, sub.planId) });
  const features = await db.query.planFeatures.findMany({ where: eq(schema.planFeatures.planId, sub.planId) });
  const records = await db.query.usageRecords.findMany({
    where: and(eq(schema.usageRecords.workspaceId, workspaceId), eq(schema.usageRecords.periodStart, start)),
  });

  const metrics = Object.entries(METRIC_TO_FEATURE_KEY).map(([metric, key]) =>
    buildMetric(metric, features.find((f) => f.key === key)?.limitValue ?? null, records.find((r) => r.metric === metric)?.value ?? 0)
  );

  return { plan, periodStart: start, periodEnd: end, metrics };
}

function buildMetric(metric: string, limit: number | null, value: number) {
  return { metric, value, limit, percentUsed: limit ? Math.min(100, Math.round((value / limit) * 100)) : null };
}
