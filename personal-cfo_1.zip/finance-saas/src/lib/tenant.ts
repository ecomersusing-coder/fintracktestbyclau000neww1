import { auth } from '@/auth';

export class UnauthorizedError extends Error {
  constructor(message = 'Not authenticated') {
    super(message);
    this.name = 'UnauthorizedError';
  }
}

export class NoWorkspaceError extends Error {
  constructor(message = 'No workspace for this user') {
    super(message);
    this.name = 'NoWorkspaceError';
  }
}

export interface TenantContext {
  userId: string;
  workspaceId: string;
  email: string;
}

/**
 * THE authorization chokepoint for the whole app. Every server action, API
 * route handler, and AI tool MUST call this to get workspaceId — never read
 * workspaceId/tenantId/accountId from the request body or query string.
 *
 * This is intentionally the ONLY place that turns a session into a
 * workspaceId, so there is exactly one code path to audit for tenant-
 * isolation correctness.
 */
export async function requireTenant(): Promise<TenantContext> {
  const session = await auth();
  if (!session?.user?.id) {
    throw new UnauthorizedError();
  }
  if (!session.workspaceId) {
    throw new NoWorkspaceError();
  }
  return {
    userId: session.user.id,
    workspaceId: session.workspaceId,
    email: session.user.email ?? '',
  };
}

/** Use when a route should work whether or not the user is signed in. */
export async function optionalTenant(): Promise<TenantContext | null> {
  try {
    return await requireTenant();
  } catch {
    return null;
  }
}
