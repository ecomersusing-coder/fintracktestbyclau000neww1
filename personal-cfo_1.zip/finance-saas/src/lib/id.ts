import { customAlphabet } from 'nanoid';

// Lowercase alphanumeric, collision-resistant, URL-safe, sorts reasonably by time
// when prefixed. Not sequential/guessable (never expose incrementing DB ids).
const nano = customAlphabet('0123456789abcdefghijklmnopqrstuvwxyz', 20);

export function createId(prefix?: string): string {
  const id = nano();
  return prefix ? `${prefix}_${id}` : id;
}
