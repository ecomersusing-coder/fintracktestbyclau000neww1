interface SendEmailInput {
  to: string;
  subject: string;
  html: string;
}

/**
 * Thin abstraction so no part of the app imports a mail provider SDK
 * directly. Without RESEND_API_KEY set (e.g. in this sandbox), emails are
 * logged instead of sent — the verification/reset LINKS still work, you
 * just have to copy them from the server log instead of an inbox.
 */
export async function sendEmail(input: SendEmailInput): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.log(`\n[email:dev-fallback] To: ${input.to}\nSubject: ${input.subject}\n${stripHtml(input.html)}\n`);
    return;
  }

  const { Resend } = await import('resend');
  const resend = new Resend(apiKey);
  await resend.emails.send({
    from: process.env.EMAIL_FROM ?? 'Personal CFO <onboarding@personalcfo.local>',
    to: input.to,
    subject: input.subject,
    html: input.html,
  });
}

function stripHtml(html: string): string {
  return html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function verificationEmailHtml(link: string): string {
  return `<p>Welcome to Personal CFO. Verify your email to get started:</p><p><a href="${link}">${link}</a></p>`;
}

export function passwordResetEmailHtml(link: string): string {
  return `<p>Reset your Personal CFO password:</p><p><a href="${link}">${link}</a></p><p>This link expires in 1 hour. If you didn't request this, you can ignore it.</p>`;
}
