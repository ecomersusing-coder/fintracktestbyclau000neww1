import { and, eq, gte, lte, inArray, sql, isNull } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import type { TenantContext } from '@/lib/tenant';

function monthRange(offsetMonths = 0) {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() + offsetMonths, 1);
  const end = new Date(now.getFullYear(), now.getMonth() + offsetMonths + 1, 1);
  return { start, end };
}

/**
 * Everything here is plain SQL aggregation — no LLM arithmetic anywhere in
 * this file (spec §55). The AI copilot's `get_financial_summary` tool calls
 * straight into this module and only formats/explains the numbers it gets back.
 */
export async function getDashboardSummary(tenant: TenantContext) {
  const { workspaceId } = tenant;

  const [accounts, cards, investments, loans] = await Promise.all([
    db.select().from(schema.financialAccounts).where(and(eq(schema.financialAccounts.workspaceId, workspaceId), eq(schema.financialAccounts.isActive, true))),
    db.select().from(schema.creditCards).where(and(eq(schema.creditCards.workspaceId, workspaceId), eq(schema.creditCards.isActive, true))),
    db.select().from(schema.investments).where(and(eq(schema.investments.workspaceId, workspaceId), eq(schema.investments.isArchived, false))),
    db.select().from(schema.loans).where(and(eq(schema.loans.workspaceId, workspaceId), eq(schema.loans.isActive, true))),
  ]);

  const bankBalanceMinor = accounts
    .filter((a) => !['CASH', 'WALLET'].includes(a.type))
    .reduce((s, a) => s + a.currentBalanceMinor, 0);
  const cashMinor = accounts
    .filter((a) => ['CASH', 'WALLET'].includes(a.type))
    .reduce((s, a) => s + a.currentBalanceMinor, 0);
  const totalCashMinor = bankBalanceMinor + cashMinor;

  const creditCardOutstandingMinor = cards.reduce((s, c) => s + c.outstandingMinor, 0);
  const totalCreditLimitMinor = cards.reduce((s, c) => s + c.creditLimitMinor, 0);
  const availableCreditMinor = totalCreditLimitMinor - creditCardOutstandingMinor;
  const creditUtilizationBps = totalCreditLimitMinor > 0 ? Math.round((creditCardOutstandingMinor / totalCreditLimitMinor) * 10000) : 0;

  const investmentsMinor = investments.reduce((s, i) => s + i.currentValueMinor, 0);
  const loansOutstandingMinor = loans.reduce((s, l) => s + l.outstandingMinor, 0);
  const totalDebtMinor = loansOutstandingMinor + creditCardOutstandingMinor;

  const netWorthMinor = totalCashMinor + investmentsMinor - totalDebtMinor;

  const { start, end } = monthRange(0);
  const [incomeRow] = await db
    .select({ total: sql<number>`coalesce(sum(${schema.transactions.amountMinor}), 0)` })
    .from(schema.transactions)
    .where(
      and(
        eq(schema.transactions.workspaceId, workspaceId),
        eq(schema.transactions.type, 'INCOME'),
        gte(schema.transactions.occurredAt, start),
        lte(schema.transactions.occurredAt, end),
        isNull(schema.transactions.deletedAt)
      )
    );
  const [expenseRow] = await db
    .select({ total: sql<number>`coalesce(sum(${schema.transactions.amountMinor}), 0)` })
    .from(schema.transactions)
    .where(
      and(
        eq(schema.transactions.workspaceId, workspaceId),
        inArray(schema.transactions.type, ['EXPENSE', 'CC_PURCHASE']),
        gte(schema.transactions.occurredAt, start),
        lte(schema.transactions.occurredAt, end),
        isNull(schema.transactions.deletedAt)
      )
    );

  const monthlyIncomeMinor = incomeRow?.total ?? 0;
  const monthlyExpensesMinor = expenseRow?.total ?? 0;
  const monthlySavingsMinor = monthlyIncomeMinor - monthlyExpensesMinor;
  const savingsRateBps = monthlyIncomeMinor > 0 ? Math.round((monthlySavingsMinor / monthlyIncomeMinor) * 10000) : 0;

  const thirtyDaysOut = new Date();
  thirtyDaysOut.setDate(thirtyDaysOut.getDate() + 30);
  const [upcomingRow] = await db
    .select({ total: sql<number>`coalesce(sum(${schema.bills.amountMinor}), 0)` })
    .from(schema.bills)
    .where(
      and(
        eq(schema.bills.workspaceId, workspaceId),
        inArray(schema.bills.status, ['UPCOMING', 'DUE']),
        lte(schema.bills.dueDate, thirtyDaysOut)
      )
    );

  return {
    netWorthMinor,
    totalCashMinor,
    bankBalanceMinor,
    cashMinor,
    creditCardOutstandingMinor,
    availableCreditMinor,
    creditUtilizationBps,
    monthlyIncomeMinor,
    monthlyExpensesMinor,
    monthlySavingsMinor,
    savingsRateBps,
    totalDebtMinor,
    loansOutstandingMinor,
    investmentsMinor,
    upcomingPaymentsMinor: upcomingRow?.total ?? 0,
  };
}

/** Income vs expense per month, for the cash-flow chart. */
export async function getCashFlowSeries(tenant: TenantContext, months = 6) {
  const { workspaceId } = tenant;
  const series: { month: string; incomeMinor: number; expenseMinor: number }[] = [];

  for (let i = months - 1; i >= 0; i--) {
    const { start, end } = monthRange(-i);
    const [incomeRow] = await db
      .select({ total: sql<number>`coalesce(sum(${schema.transactions.amountMinor}), 0)` })
      .from(schema.transactions)
      .where(
        and(
          eq(schema.transactions.workspaceId, workspaceId),
          eq(schema.transactions.type, 'INCOME'),
          gte(schema.transactions.occurredAt, start),
          lte(schema.transactions.occurredAt, end),
          isNull(schema.transactions.deletedAt)
        )
      );
    const [expenseRow] = await db
      .select({ total: sql<number>`coalesce(sum(${schema.transactions.amountMinor}), 0)` })
      .from(schema.transactions)
      .where(
        and(
          eq(schema.transactions.workspaceId, workspaceId),
          inArray(schema.transactions.type, ['EXPENSE', 'CC_PURCHASE']),
          gte(schema.transactions.occurredAt, start),
          lte(schema.transactions.occurredAt, end),
          isNull(schema.transactions.deletedAt)
        )
      );
    series.push({
      month: start.toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
      incomeMinor: incomeRow?.total ?? 0,
      expenseMinor: expenseRow?.total ?? 0,
    });
  }

  return series;
}
