import { and, eq, gte, desc } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import type { TenantContext } from '@/lib/tenant';
import { getDashboardSummary } from './summary';

/** Call once/day (e.g. from a cron route) to record a net worth data point.
 * Idempotent per calendar day via the unique(workspaceId, snapshotDate) index. */
export async function recordDailySnapshot(tenant: TenantContext) {
  const summary = await getDashboardSummary(tenant);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const existing = await db.query.financialSnapshots.findFirst({
    where: and(eq(schema.financialSnapshots.workspaceId, tenant.workspaceId), eq(schema.financialSnapshots.snapshotDate, today)),
  });

  const values = {
    netWorthMinor: summary.netWorthMinor,
    assetsMinor: summary.totalCashMinor + summary.investmentsMinor,
    liabilitiesMinor: summary.totalDebtMinor,
    cashMinor: summary.totalCashMinor,
    investmentsMinor: summary.investmentsMinor,
    debtMinor: summary.totalDebtMinor,
  };

  if (existing) {
    await db.update(schema.financialSnapshots).set(values).where(eq(schema.financialSnapshots.id, existing.id));
    return existing.id;
  }
  const [row] = await db
    .insert(schema.financialSnapshots)
    .values({ workspaceId: tenant.workspaceId, snapshotDate: today, ...values })
    .returning();
  return row.id;
}

export async function getNetWorthHistory(tenant: TenantContext, sinceDaysAgo = 365) {
  const since = new Date();
  since.setDate(since.getDate() - sinceDaysAgo);

  return db
    .select()
    .from(schema.financialSnapshots)
    .where(and(eq(schema.financialSnapshots.workspaceId, tenant.workspaceId), gte(schema.financialSnapshots.snapshotDate, since)))
    .orderBy(desc(schema.financialSnapshots.snapshotDate));
}
