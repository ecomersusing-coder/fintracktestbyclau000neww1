import { z } from 'zod';

// Central source of truth for every "enum-like" string column in the schema.
// Keep this in sync with the comments above each column in src/db/schema/*.

export const TRANSACTION_TYPES = [
  'EXPENSE',
  'INCOME',
  'TRANSFER',
  'CC_PURCHASE',
  'CC_PAYMENT',
  'INVESTMENT_PURCHASE',
  'INVESTMENT_SALE',
  'LOAN_PAYMENT',
  'REFUND',
  'ADJUSTMENT',
] as const;
export const transactionTypeSchema = z.enum(TRANSACTION_TYPES);
export type TransactionType = z.infer<typeof transactionTypeSchema>;

export const TRANSACTION_SOURCES = ['MANUAL', 'AI_CHAT', 'RECEIPT_AI', 'IMPORT', 'RECURRING'] as const;
export const transactionSourceSchema = z.enum(TRANSACTION_SOURCES);
export type TransactionSource = z.infer<typeof transactionSourceSchema>;

export const ACCOUNT_TYPES = ['SAVINGS', 'CURRENT', 'SALARY', 'BUSINESS', 'CASH', 'WALLET', 'OTHER'] as const;
export const accountTypeSchema = z.enum(ACCOUNT_TYPES);
export type AccountType = z.infer<typeof accountTypeSchema>;

export const CATEGORY_KINDS = ['EXPENSE', 'INCOME', 'BOTH'] as const;
export const categoryKindSchema = z.enum(CATEGORY_KINDS);

export const LOAN_TYPES = ['PERSONAL', 'VEHICLE', 'HOME', 'CREDIT_CARD_DEBT', 'OTHER'] as const;
export const loanTypeSchema = z.enum(LOAN_TYPES);

export const INVESTMENT_TYPES = ['STOCK', 'MUTUAL_FUND', 'ETF', 'FD', 'GOLD', 'CRYPTO', 'OTHER'] as const;
export const investmentTypeSchema = z.enum(INVESTMENT_TYPES);

export const BILLING_CYCLES = ['MONTHLY', 'YEARLY', 'WEEKLY', 'CUSTOM'] as const;
export const billingCycleSchema = z.enum(BILLING_CYCLES);

export const RECURRING_FREQUENCIES = ['DAILY', 'WEEKLY', 'MONTHLY', 'QUARTERLY', 'YEARLY', 'CUSTOM'] as const;
export const recurringFrequencySchema = z.enum(RECURRING_FREQUENCIES);

export const BILL_STATUSES = ['UPCOMING', 'DUE', 'PAID', 'OVERDUE'] as const;
export const billStatusSchema = z.enum(BILL_STATUSES);

export const WORKSPACE_ROLES = ['OWNER', 'ADMIN', 'MEMBER'] as const;
export const workspaceRoleSchema = z.enum(WORKSPACE_ROLES);

export const SUBSCRIPTION_STATUSES = ['TRIALING', 'ACTIVE', 'PAST_DUE', 'CANCELED', 'EXPIRED'] as const;
export const subscriptionStatusSchema = z.enum(SUBSCRIPTION_STATUSES);

export const AI_TOOL_CALL_STATUSES = [
  'PENDING_CONFIRMATION',
  'CONFIRMED',
  'EXECUTED',
  'FAILED',
  'CANCELLED',
] as const;
export const aiToolCallStatusSchema = z.enum(AI_TOOL_CALL_STATUSES);

export const AUDIT_ACTOR_TYPES = ['USER', 'AI', 'SYSTEM', 'ADMIN'] as const;
export const auditActorTypeSchema = z.enum(AUDIT_ACTOR_TYPES);

// Which endpoint fields a transaction type requires — used both for Zod
// validation and by the accounting engine to know what to mutate.
export const TRANSACTION_TYPE_FIELDS: Record<TransactionType, string[]> = {
  EXPENSE: ['accountId'],
  INCOME: ['accountId'],
  TRANSFER: ['accountId', 'transferToAccountId'],
  CC_PURCHASE: ['creditCardId'],
  CC_PAYMENT: ['accountId', 'creditCardId'],
  INVESTMENT_PURCHASE: ['accountId', 'investmentId'],
  INVESTMENT_SALE: ['accountId', 'investmentId'],
  LOAN_PAYMENT: ['accountId', 'loanId'],
  REFUND: ['accountId'],
  ADJUSTMENT: [],
};
