import { NextResponse } from 'next/server';
import { ZodError } from 'zod';
import { UnauthorizedError, NoWorkspaceError } from '@/lib/tenant';

export class AppError extends Error {
  status: number;
  code: string;
  constructor(message: string, status = 400, code = 'BAD_REQUEST') {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export class NotFoundError extends AppError {
  constructor(entity: string) {
    super(`${entity} not found`, 404, 'NOT_FOUND');
  }
}

export class AmbiguousMatchError extends AppError {
  candidates: unknown[];
  constructor(message: string, candidates: unknown[]) {
    super(message, 409, 'AMBIGUOUS_MATCH');
    this.candidates = candidates;
  }
}

export class LimitExceededError extends AppError {
  constructor(message: string) {
    super(message, 402, 'LIMIT_EXCEEDED');
  }
}

/**
 * Wraps a route handler so every failure mode returns a clean, safe JSON
 * error instead of leaking a stack trace (spec §77). Route handlers should
 * throw, not construct error responses inline.
 */
export function toErrorResponse(err: unknown): NextResponse {
  if (err instanceof UnauthorizedError) {
    return NextResponse.json({ error: 'unauthorized', message: err.message }, { status: 401 });
  }
  if (err instanceof NoWorkspaceError) {
    return NextResponse.json({ error: 'no_workspace', message: err.message }, { status: 403 });
  }
  if (err instanceof ZodError) {
    return NextResponse.json(
      { error: 'validation_error', message: 'Invalid input', issues: err.issues },
      { status: 422 }
    );
  }
  if (err instanceof AmbiguousMatchError) {
    return NextResponse.json(
      { error: err.code, message: err.message, candidates: err.candidates },
      { status: err.status }
    );
  }
  if (err instanceof AppError) {
    return NextResponse.json({ error: err.code, message: err.message }, { status: err.status });
  }
  // Unknown/unexpected error — never leak internals.
  console.error('[unhandled_error]', err);
  return NextResponse.json(
    { error: 'internal_error', message: 'Something went wrong. Please try again.' },
    { status: 500 }
  );
}
