import NextAuth from 'next-auth';
import Credentials from 'next-auth/providers/credentials';
import { z } from 'zod';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { verifyPassword } from '@/lib/password';
import { authConfig } from './auth.config';

const credentialsSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const { handlers, auth, signIn, signOut } = NextAuth({
  ...authConfig,
  pages: {
    signIn: '/login',
    error: '/login',
  },
  providers: [
    Credentials({
      name: 'Email and password',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' },
      },
      authorize: async (raw) => {
        const parsed = credentialsSchema.safeParse(raw);
        if (!parsed.success) return null;
        const { email, password } = parsed.data;

        const user = await db.query.users.findFirst({
          where: eq(schema.users.email, email.toLowerCase().trim()),
        });
        if (!user || !user.isActive) return null;

        const valid = await verifyPassword(password, user.passwordHash);
        if (!valid) return null;

        // NOTE: we deliberately do NOT block sign-in on emailVerifiedAt being
        // null — the app nudges verification via a banner instead of locking
        // people out, which is a product choice, not a security one.
        return { id: user.id, email: user.email, name: user.name ?? undefined };
      },
    }),
  ],
  callbacks: {
    ...authConfig.callbacks,
    async jwt({ token, user }) {
      if (user?.id) {
        token.userId = user.id;
        // Resolve the user's primary workspace once, at sign-in, and cache
        // it on the token. (Multi-workspace switching can read fresh from
        // WorkspaceMember when that UI is built — see spec §12.)
        const membership = await db.query.workspaceMembers.findFirst({
          where: eq(schema.workspaceMembers.userId, user.id),
        });
        token.workspaceId = membership?.workspaceId;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.userId as string;
        session.workspaceId = token.workspaceId as string | undefined;
      }
      return session;
    },
  },
});
