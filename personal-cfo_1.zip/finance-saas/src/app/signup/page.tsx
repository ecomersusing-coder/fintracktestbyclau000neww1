'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { signIn } from 'next-auth/react';
import Link from 'next/link';
import { AuthShell } from '@/components/auth-shell';

export default function SignupPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });
    const data = await res.json();

    if (!res.ok) {
      setError(data.message ?? 'Could not create your account.');
      setLoading(false);
      return;
    }

    const result = await signIn('credentials', { email, password, redirect: false });
    setLoading(false);
    if (result?.error) {
      router.push('/login');
      return;
    }
    router.push('/onboarding');
    router.refresh();
  }

  return (
    <AuthShell title="Create your account" subtitle="Start managing your finances with AI">
      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="label-text mb-1 block">Name</label>
          <input className="input-field" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label className="label-text mb-1 block">Email</label>
          <input type="email" required className="input-field" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label className="label-text mb-1 block">Password</label>
          <input
            type="password"
            required
            minLength={10}
            className="input-field"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <p className="mt-1 text-xs text-ink-400">At least 10 characters, with upper, lower case and a number.</p>
        </div>
        {error && <p className="text-sm text-rose-600">{error}</p>}
        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? 'Creating account…' : 'Create account'}
        </button>
      </form>
      <p className="mt-4 text-center text-sm text-ink-500 dark:text-ink-300">
        Already have an account?{' '}
        <Link href="/login" className="font-medium text-moss-600 hover:text-moss-700">
          Sign in
        </Link>
      </p>
    </AuthShell>
  );
}
