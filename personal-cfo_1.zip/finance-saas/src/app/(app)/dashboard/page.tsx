import { eq } from 'drizzle-orm';
import { requireTenant } from '@/lib/tenant';
import { db, schema } from '@/db/client';
import { getDashboardSummary, getCashFlowSeries } from '@/lib/analytics/summary';
import { getCategoryBreakdown } from '@/lib/accounting/search';
import { formatMoney } from '@/lib/money';
import { StatCard } from '@/components/stat-card';
import { CashFlowChart } from '@/components/charts/cashflow-chart';
import { CategoryPieChart } from '@/components/charts/category-pie-chart';

export default async function DashboardPage() {
  const tenant = await requireTenant();
  const workspace = await db.query.workspaces.findFirst({ where: eq(schema.workspaces.id, tenant.workspaceId) });
  const currency = workspace?.currency ?? 'INR';

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const [summary, cashFlow, breakdown] = await Promise.all([
    getDashboardSummary(tenant),
    getCashFlowSeries(tenant, 6),
    getCategoryBreakdown(tenant, { dateFrom: monthStart, dateTo: now, types: ['EXPENSE', 'CC_PURCHASE'] }),
  ]);

  const fmt = (minor: number) => formatMoney(minor, currency);
  const savingsRatePct = (summary.savingsRateBps / 100).toFixed(1);
  const utilPct = (summary.creditUtilizationBps / 100).toFixed(0);

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <div className="mb-6">
        <h1 className="font-display text-2xl text-ink-900 dark:text-paper-100">
          {workspace?.isDemo ? 'Demo workspace' : 'Dashboard'}
        </h1>
        <p className="text-sm text-ink-500 dark:text-ink-300">Your complete financial position, calculated in real time.</p>
        {workspace?.isDemo && (
          <p className="mt-2 inline-block rounded-full bg-clay-400/20 px-3 py-1 text-xs font-medium text-clay-600">
            Demo data — clearly separated from any real account
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        <StatCard label="Net Worth" value={fmt(summary.netWorthMinor)} tone={summary.netWorthMinor >= 0 ? 'positive' : 'negative'} />
        <StatCard label="Total Cash" value={fmt(summary.totalCashMinor)} sub={`Bank ${fmt(summary.bankBalanceMinor)} · Cash ${fmt(summary.cashMinor)}`} />
        <StatCard label="Credit Card Outstanding" value={fmt(summary.creditCardOutstandingMinor)} tone="negative" sub={`${utilPct}% utilized`} />
        <StatCard label="Available Credit" value={fmt(summary.availableCreditMinor)} />
        <StatCard label="Monthly Income" value={fmt(summary.monthlyIncomeMinor)} tone="positive" />
        <StatCard label="Monthly Expenses" value={fmt(summary.monthlyExpensesMinor)} tone="negative" />
        <StatCard label="Monthly Savings" value={fmt(summary.monthlySavingsMinor)} tone={summary.monthlySavingsMinor >= 0 ? 'positive' : 'negative'} />
        <StatCard label="Savings Rate" value={`${savingsRatePct}%`} />
        <StatCard label="Total Debt" value={fmt(summary.totalDebtMinor)} tone="negative" />
        <StatCard label="Investments" value={fmt(summary.investmentsMinor)} tone="positive" />
        <StatCard label="Upcoming Payments (30d)" value={fmt(summary.upcomingPaymentsMinor)} />
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <h2 className="mb-3 text-sm font-medium text-ink-700 dark:text-paper-200">Income vs Expenses</h2>
          <CashFlowChart data={cashFlow} currency={currency} />
        </div>
        <div className="card p-5">
          <h2 className="mb-3 text-sm font-medium text-ink-700 dark:text-paper-200">Spending by Category (this month)</h2>
          <CategoryPieChart data={breakdown.rows} currency={currency} />
        </div>
      </div>
    </div>
  );
}
