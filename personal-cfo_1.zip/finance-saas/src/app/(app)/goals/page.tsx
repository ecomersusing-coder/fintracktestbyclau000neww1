import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Savings Goals" phase="Phase 4" description="Target, progress, and monthly contribution tracking (spec §20)." />;
}
