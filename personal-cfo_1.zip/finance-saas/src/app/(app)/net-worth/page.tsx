import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Net Worth" phase="Phase 5" description="Historical net worth chart from daily snapshots (spec §24) — the recordDailySnapshot() engine already exists." />;
}
