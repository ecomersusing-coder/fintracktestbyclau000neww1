import { eq, inArray } from 'drizzle-orm';
import { requireTenant } from '@/lib/tenant';
import { searchTransactions } from '@/lib/accounting/search';
import { db, schema } from '@/db/client';
import { formatMoney } from '@/lib/money';
import { AddTransactionForm } from '@/components/forms/add-transaction-form';
import { TransactionRowActions } from '@/components/transaction-row-actions';

const TYPE_LABELS: Record<string, string> = {
  EXPENSE: 'Expense',
  INCOME: 'Income',
  TRANSFER: 'Transfer',
  CC_PURCHASE: 'Card purchase',
  CC_PAYMENT: 'Card payment',
  INVESTMENT_PURCHASE: 'Investment buy',
  INVESTMENT_SALE: 'Investment sell',
  LOAN_PAYMENT: 'Loan payment',
  REFUND: 'Refund',
  ADJUSTMENT: 'Adjustment',
};

export default async function TransactionsPage() {
  const tenant = await requireTenant();
  const { items, total } = await searchTransactions(tenant, {}, { pageSize: 50 });

  const categoryIds = [...new Set(items.map((t) => t.categoryId).filter(Boolean))] as string[];
  const categories = categoryIds.length ? await db.select().from(schema.categories).where(inArray(schema.categories.id, categoryIds)) : [];
  const categoryMap = new Map(categories.map((c) => [c.id, c.name]));

  return (
    <div className="mx-auto max-w-5xl px-6 py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl text-ink-900 dark:text-paper-100">Transactions</h1>
          <p className="text-sm text-ink-500 dark:text-ink-300">{total} total. Add manually here, or via the Finance Copilot.</p>
        </div>
        <AddTransactionForm />
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wide text-ink-400 dark:border-ink-800">
              <th className="px-4 py-3 font-medium">Date</th>
              <th className="px-4 py-3 font-medium">Merchant / Description</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Type</th>
              <th className="px-4 py-3 text-right font-medium">Amount</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((t) => (
              <tr key={t.id} className="border-b border-ink-50 last:border-0 dark:border-ink-800">
                <td className="whitespace-nowrap px-4 py-3 text-ink-500 dark:text-ink-300">
                  {new Date(t.occurredAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                </td>
                <td className="px-4 py-3 text-ink-900 dark:text-paper-100">{t.merchant ?? t.description ?? '—'}</td>
                <td className="px-4 py-3 text-ink-500 dark:text-ink-300">{t.categoryId ? categoryMap.get(t.categoryId) ?? '—' : '—'}</td>
                <td className="px-4 py-3 text-ink-500 dark:text-ink-300">{TYPE_LABELS[t.type] ?? t.type}</td>
                <td
                  className={`whitespace-nowrap px-4 py-3 text-right stat-number ${
                    t.type === 'INCOME' || t.type === 'REFUND' ? 'text-moss-600' : 'text-ink-900 dark:text-paper-100'
                  }`}
                >
                  {formatMoney(t.amountMinor, t.currency)}
                </td>
                <td className="px-4 py-3 text-right">
                  <TransactionRowActions id={t.id} />
                </td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-sm text-ink-400">
                  No transactions yet — add your first one above.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
