import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Investments" phase="Phase 5" description="Stocks, mutual funds, FDs, gold, and crypto with gain/loss tracking (spec §23)." />;
}
