import { and, eq } from 'drizzle-orm';
import { requireTenant } from '@/lib/tenant';
import { db, schema } from '@/db/client';
import { formatMoney } from '@/lib/money';
import { AddCardForm } from '@/components/forms/add-card-form';

export default async function CreditCardsPage() {
  const tenant = await requireTenant();
  const cards = await db
    .select()
    .from(schema.creditCards)
    .where(and(eq(schema.creditCards.workspaceId, tenant.workspaceId), eq(schema.creditCards.isActive, true)));

  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl text-ink-900 dark:text-paper-100">Credit Cards</h1>
          <p className="text-sm text-ink-500 dark:text-ink-300">Track limits, outstanding, and due dates.</p>
        </div>
        <AddCardForm />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {cards.map((c) => {
          const utilPct = c.creditLimitMinor > 0 ? Math.min(100, Math.round((c.outstandingMinor / c.creditLimitMinor) * 100)) : 0;
          return (
            <div key={c.id} className="card p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-ink-900 dark:text-paper-100">{c.name}</p>
                  <p className="text-xs text-ink-400">
                    {c.bankName ? `${c.bankName} · ` : ''}
                    {c.last4 ? `•••• ${c.last4}` : ''}
                  </p>
                </div>
                {c.isDemo && <span className="rounded-full bg-clay-400/20 px-2 py-0.5 text-[10px] font-medium text-clay-600">DEMO</span>}
              </div>

              <div className="mt-3 flex items-baseline justify-between">
                <p className="stat-number text-xl text-ink-900 dark:text-paper-100">{formatMoney(c.outstandingMinor, 'INR')}</p>
                <p className="text-xs text-ink-400">of {formatMoney(c.creditLimitMinor, 'INR')}</p>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-ink-100 dark:bg-ink-800">
                <div
                  className={`h-full rounded-full ${utilPct > 70 ? 'bg-rose-500' : utilPct > 40 ? 'bg-clay-500' : 'bg-moss-500'}`}
                  style={{ width: `${utilPct}%` }}
                />
              </div>
              <p className="mt-1 text-xs text-ink-400">{utilPct}% utilized{c.dueDay ? ` · due day ${c.dueDay}` : ''}</p>
            </div>
          );
        })}
        {cards.length === 0 && <p className="text-sm text-ink-400">No credit cards yet — add your first one above.</p>}
      </div>
    </div>
  );
}
