import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Budgets" phase="Phase 4" description="Overall and per-category budgets with usage alerts (spec §19)." />;
}
