import { redirect } from 'next/navigation';
import { eq } from 'drizzle-orm';
import { auth } from '@/auth';
import { db, schema } from '@/db/client';
import { Sidebar } from '@/components/sidebar';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user?.id) redirect('/login');
  if (!session.workspaceId) redirect('/login');

  const workspace = await db.query.workspaces.findFirst({ where: eq(schema.workspaces.id, session.workspaceId) });
  if (!workspace) redirect('/login');
  if (!workspace.onboardingCompletedAt) redirect('/onboarding');

  return (
    <div className="flex">
      <Sidebar userEmail={session.user.email ?? ''} workspaceName={workspace.name} />
      <main className="min-h-screen flex-1 bg-paper-50 dark:bg-ink-950">{children}</main>
    </div>
  );
}
