import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Loans & Debt" phase="Phase 5" description="EMI schedules, payoff estimates, and debt-to-income ratio (spec §22)." />;
}
