import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Settings" phase="Phase 9-11" description="Profile, security, billing/plan management, categories, and notification preferences." />;
}
