import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Bill Calendar" phase="Phase 4" description="Upcoming bills, EMIs, and subscription renewals in one calendar (spec §18)." />;
}
