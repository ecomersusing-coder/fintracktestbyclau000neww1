import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Reports" phase="Phase 5" description="Daily/weekly/monthly/annual PDF, CSV, Excel exports (spec §59-60)." />;
}
