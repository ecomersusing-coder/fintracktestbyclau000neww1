import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return <ComingSoon title="Subscriptions" phase="Phase 4" description="Track recurring personal subscriptions and their monthly/annual cost (spec §25)." />;
}
