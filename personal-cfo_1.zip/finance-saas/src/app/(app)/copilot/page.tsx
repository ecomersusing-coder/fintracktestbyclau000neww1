import { ComingSoon } from '@/components/coming-soon';
export default function Page() {
  return (
    <ComingSoon
      title="Finance Copilot"
      phase="Phase 6-8"
      description="Natural-language chat that reads, searches, creates, edits, deletes, and bulk-updates real transactions through controlled tools (spec §27-58)."
    />
  );
}
