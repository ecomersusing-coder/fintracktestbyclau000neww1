import { and, eq } from 'drizzle-orm';
import { requireTenant } from '@/lib/tenant';
import { db, schema } from '@/db/client';
import { formatMoney } from '@/lib/money';
import { AddAccountForm } from '@/components/forms/add-account-form';

export default async function AccountsPage() {
  const tenant = await requireTenant();
  const workspace = await db.query.workspaces.findFirst({ where: eq(schema.workspaces.id, tenant.workspaceId) });
  const currency = workspace?.currency ?? 'INR';

  const accounts = await db
    .select()
    .from(schema.financialAccounts)
    .where(and(eq(schema.financialAccounts.workspaceId, tenant.workspaceId), eq(schema.financialAccounts.isActive, true)));

  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl text-ink-900 dark:text-paper-100">Accounts</h1>
          <p className="text-sm text-ink-500 dark:text-ink-300">Bank accounts, cash, and wallets.</p>
        </div>
        <AddAccountForm />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {accounts.map((a) => (
          <div key={a.id} className="card p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-medium text-ink-900 dark:text-paper-100">{a.name}</p>
                <p className="text-xs text-ink-400">
                  {a.bankName ? `${a.bankName} · ` : ''}
                  {a.type}
                  {a.last4 ? ` · •••• ${a.last4}` : ''}
                </p>
              </div>
              {a.isDemo && <span className="rounded-full bg-clay-400/20 px-2 py-0.5 text-[10px] font-medium text-clay-600">DEMO</span>}
            </div>
            <p className="stat-number mt-3 text-xl text-ink-900 dark:text-paper-100">{formatMoney(a.currentBalanceMinor, a.currency)}</p>
          </div>
        ))}
        {accounts.length === 0 && (
          <p className="text-sm text-ink-400">No accounts yet — add your first one above.</p>
        )}
      </div>
    </div>
  );
}
