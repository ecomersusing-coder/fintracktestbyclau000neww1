import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { eq, and } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse, NotFoundError } from '@/lib/api-error';
import { toMinor } from '@/lib/money';

export const dynamic = 'force-dynamic';

const updateSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  creditLimitMajor: z.number().nonnegative().optional(),
  statementDay: z.number().int().min(1).max(31).optional(),
  dueDay: z.number().int().min(1).max(31).optional(),
  isActive: z.boolean().optional(),
});

async function ownedCard(workspaceId: string, id: string) {
  const row = await db.query.creditCards.findFirst({
    where: and(eq(schema.creditCards.id, id), eq(schema.creditCards.workspaceId, workspaceId)),
  });
  if (!row) throw new NotFoundError('Credit card');
  return row;
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tenant = await requireTenant();
    await ownedCard(tenant.workspaceId, params.id);
    const body = updateSchema.parse(await req.json());

    const [card] = await db
      .update(schema.creditCards)
      .set({
        ...(body.name !== undefined && { name: body.name }),
        ...(body.creditLimitMajor !== undefined && { creditLimitMinor: toMinor(body.creditLimitMajor) }),
        ...(body.statementDay !== undefined && { statementDay: body.statementDay }),
        ...(body.dueDay !== undefined && { dueDay: body.dueDay }),
        ...(body.isActive !== undefined && { isActive: body.isActive }),
      })
      .where(eq(schema.creditCards.id, params.id))
      .returning();

    return NextResponse.json({ card });
  } catch (err) {
    return toErrorResponse(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tenant = await requireTenant();
    await ownedCard(tenant.workspaceId, params.id);
    await db.update(schema.creditCards).set({ isActive: false }).where(eq(schema.creditCards.id, params.id));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return toErrorResponse(err);
  }
}
