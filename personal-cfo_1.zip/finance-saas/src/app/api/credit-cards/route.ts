import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { eq, and } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { toMinor } from '@/lib/money';
import { checkStandingLimit } from '@/lib/billing/usage';

export const dynamic = 'force-dynamic';

const createCardSchema = z.object({
  name: z.string().min(1).max(100),
  bankName: z.string().max(100).optional(),
  last4: z.string().max(4).optional(),
  creditLimitMajor: z.number().nonnegative(),
  outstandingMajor: z.number().nonnegative().default(0),
  statementDay: z.number().int().min(1).max(31).optional(),
  dueDay: z.number().int().min(1).max(31).optional(),
  annualFeeMajor: z.number().nonnegative().optional(),
});

export async function GET() {
  try {
    const tenant = await requireTenant();
    const cards = await db
      .select()
      .from(schema.creditCards)
      .where(and(eq(schema.creditCards.workspaceId, tenant.workspaceId), eq(schema.creditCards.isActive, true)));
    return NextResponse.json({ cards });
  } catch (err) {
    return toErrorResponse(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const body = createCardSchema.parse(await req.json());

    const existing = await db.select().from(schema.creditCards).where(eq(schema.creditCards.workspaceId, tenant.workspaceId));
    await checkStandingLimit(tenant.workspaceId, 'max_credit_cards', existing.length);

    const [card] = await db
      .insert(schema.creditCards)
      .values({
        workspaceId: tenant.workspaceId,
        name: body.name,
        bankName: body.bankName,
        last4: body.last4,
        creditLimitMinor: toMinor(body.creditLimitMajor),
        outstandingMinor: toMinor(body.outstandingMajor),
        statementDay: body.statementDay,
        dueDay: body.dueDay,
        annualFeeMinor: body.annualFeeMajor ? toMinor(body.annualFeeMajor) : undefined,
      })
      .returning();

    return NextResponse.json({ card }, { status: 201 });
  } catch (err) {
    return toErrorResponse(err);
  }
}
