import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { toMinor } from '@/lib/money';
import { accountTypeSchema } from '@/lib/enums';

export const dynamic = 'force-dynamic';

const onboardingSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  country: z.string().max(56).optional(),
  currency: z.string().length(3).default('INR'),
  monthlyIncomeRange: z.string().optional(),
  goals: z.array(z.string()).optional(),
  initialAccounts: z
    .array(
      z.object({
        name: z.string().min(1).max(100),
        type: accountTypeSchema,
        openingBalanceMajor: z.number().default(0),
      })
    )
    .optional(),
  preferredCategoryNames: z.array(z.string()).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const body = onboardingSchema.parse(await req.json());

    await db.transaction((tx) => {
      tx.update(schema.workspaces)
        .set({
          currency: body.currency,
          country: body.country,
          monthlyIncomeRange: body.monthlyIncomeRange,
          onboardingCompletedAt: new Date(),
        })
        .where(eq(schema.workspaces.id, tenant.workspaceId))
        .run();

      if (body.name) {
        tx.update(schema.users).set({ name: body.name }).where(eq(schema.users.id, tenant.userId)).run();
      }

      for (const acct of body.initialAccounts ?? []) {
        const openingBalanceMinor = toMinor(acct.openingBalanceMajor, body.currency);
        tx.insert(schema.financialAccounts)
          .values({
            workspaceId: tenant.workspaceId,
            name: acct.name,
            type: acct.type,
            currency: body.currency,
            openingBalanceMinor,
            currentBalanceMinor: openingBalanceMinor,
          })
          .run();
      }
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    return toErrorResponse(err);
  }
}

/** "Skippable" per spec §5 — a bare POST with no body just marks it done. */
export async function PATCH() {
  try {
    const tenant = await requireTenant();
    await db.update(schema.workspaces).set({ onboardingCompletedAt: new Date() }).where(eq(schema.workspaces.id, tenant.workspaceId));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return toErrorResponse(err);
  }
}
