import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { eq, and } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { toMinor } from '@/lib/money';
import { accountTypeSchema } from '@/lib/enums';
import { checkStandingLimit } from '@/lib/billing/usage';

export const dynamic = 'force-dynamic';

const createAccountSchema = z.object({
  name: z.string().min(1).max(100),
  bankName: z.string().max(100).optional(),
  type: accountTypeSchema.default('SAVINGS'),
  last4: z.string().max(4).optional(),
  currency: z.string().length(3).default('INR'),
  openingBalanceMajor: z.number().default(0),
});

export async function GET() {
  try {
    const tenant = await requireTenant();
    const accounts = await db
      .select()
      .from(schema.financialAccounts)
      .where(and(eq(schema.financialAccounts.workspaceId, tenant.workspaceId), eq(schema.financialAccounts.isActive, true)));
    return NextResponse.json({ accounts });
  } catch (err) {
    return toErrorResponse(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const body = createAccountSchema.parse(await req.json());

    // "accounts" is a standing-count limit, not a monthly counter.
    const existingCount = await db
      .select()
      .from(schema.financialAccounts)
      .where(eq(schema.financialAccounts.workspaceId, tenant.workspaceId));
    await checkStandingLimit(tenant.workspaceId, 'max_accounts', existingCount.length);

    const openingBalanceMinor = toMinor(body.openingBalanceMajor, body.currency);
    const [account] = await db
      .insert(schema.financialAccounts)
      .values({
        workspaceId: tenant.workspaceId,
        name: body.name,
        bankName: body.bankName,
        type: body.type,
        last4: body.last4,
        currency: body.currency,
        openingBalanceMinor,
        currentBalanceMinor: openingBalanceMinor,
      })
      .returning();

    return NextResponse.json({ account }, { status: 201 });
  } catch (err) {
    return toErrorResponse(err);
  }
}
