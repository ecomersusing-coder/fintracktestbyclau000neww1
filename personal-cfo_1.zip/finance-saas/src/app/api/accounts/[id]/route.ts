import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { eq, and } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse, NotFoundError } from '@/lib/api-error';

export const dynamic = 'force-dynamic';

const updateSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  bankName: z.string().max(100).optional(),
  last4: z.string().max(4).optional(),
  isActive: z.boolean().optional(),
});

async function ownedAccount(workspaceId: string, id: string) {
  const row = await db.query.financialAccounts.findFirst({
    where: and(eq(schema.financialAccounts.id, id), eq(schema.financialAccounts.workspaceId, workspaceId)),
  });
  if (!row) throw new NotFoundError('Account');
  return row;
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tenant = await requireTenant();
    await ownedAccount(tenant.workspaceId, params.id);
    const body = updateSchema.parse(await req.json());

    const [account] = await db
      .update(schema.financialAccounts)
      .set(body)
      .where(eq(schema.financialAccounts.id, params.id))
      .returning();

    return NextResponse.json({ account });
  } catch (err) {
    return toErrorResponse(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tenant = await requireTenant();
    await ownedAccount(tenant.workspaceId, params.id);
    // Soft-deactivate rather than hard delete — financial history must stay intact.
    await db.update(schema.financialAccounts).set({ isActive: false }).where(eq(schema.financialAccounts.id, params.id));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return toErrorResponse(err);
  }
}
