import { NextResponse } from 'next/server';
import { z } from 'zod';
import { NextRequest } from 'next/server';
import { eq, or, isNull, and } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { categoryKindSchema } from '@/lib/enums';

export const dynamic = 'force-dynamic';

const createSchema = z.object({
  name: z.string().min(1).max(100),
  kind: categoryKindSchema.default('EXPENSE'),
  icon: z.string().max(10).optional(),
  color: z.string().max(20).optional(),
  parentId: z.string().optional(),
});

export async function GET() {
  try {
    const tenant = await requireTenant();
    const categories = await db
      .select()
      .from(schema.categories)
      .where(
        and(
          eq(schema.categories.isArchived, false),
          or(isNull(schema.categories.workspaceId), eq(schema.categories.workspaceId, tenant.workspaceId))
        )
      );
    return NextResponse.json({ categories });
  } catch (err) {
    return toErrorResponse(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const body = createSchema.parse(await req.json());
    const [category] = await db
      .insert(schema.categories)
      .values({ workspaceId: tenant.workspaceId, name: body.name, kind: body.kind, icon: body.icon, color: body.color, parentId: body.parentId })
      .returning();
    return NextResponse.json({ category }, { status: 201 });
  } catch (err) {
    return toErrorResponse(err);
  }
}
