import { NextRequest, NextResponse } from 'next/server';
import { eq, and } from 'drizzle-orm';
import { db, schema } from '@/db/client';

export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get('token');
  const appUrl = process.env.NEXTAUTH_URL ?? 'http://localhost:3000';
  if (!token) return NextResponse.redirect(`${appUrl}/login?error=invalid_token`);

  const row = await db.query.verificationTokens.findFirst({
    where: and(eq(schema.verificationTokens.token, token), eq(schema.verificationTokens.purpose, 'EMAIL_VERIFY')),
  });

  if (!row || row.usedAt || row.expiresAt < new Date()) {
    return NextResponse.redirect(`${appUrl}/login?error=expired_token`);
  }

  await db.transaction((tx) => {
    tx.update(schema.verificationTokens).set({ usedAt: new Date() }).where(eq(schema.verificationTokens.id, row.id)).run();
    tx.update(schema.users).set({ emailVerifiedAt: new Date() }).where(eq(schema.users.id, row.userId)).run();
  });

  return NextResponse.redirect(`${appUrl}/login?verified=1`);
}
