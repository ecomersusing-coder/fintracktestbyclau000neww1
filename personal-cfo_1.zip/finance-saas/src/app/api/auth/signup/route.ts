import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { provisionNewAccount } from '@/lib/provisioning';
import { isPasswordStrongEnough } from '@/lib/password';
import { sendEmail, verificationEmailHtml } from '@/lib/email';
import { toErrorResponse } from '@/lib/api-error';

const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(10).refine(isPasswordStrongEnough, {
    message: 'Password must be at least 10 characters and include upper, lower case letters and a number.',
  }),
  name: z.string().min(1).max(100).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = signupSchema.parse(await req.json());
    const { user, verifyToken } = await provisionNewAccount(body);

    const appUrl = process.env.NEXTAUTH_URL ?? 'http://localhost:3000';
    const verifyLink = `${appUrl}/api/auth/verify-email?token=${verifyToken.token}`;
    await sendEmail({ to: user.email, subject: 'Verify your Personal CFO account', html: verificationEmailHtml(verifyLink) });

    return NextResponse.json({ ok: true, userId: user.id });
  } catch (err) {
    return toErrorResponse(err);
  }
}
