import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { createId } from '@/lib/id';
import { sendEmail, passwordResetEmailHtml } from '@/lib/email';
import { toErrorResponse } from '@/lib/api-error';

const schemaBody = z.object({ email: z.string().email() });

export async function POST(req: NextRequest) {
  try {
    const { email } = schemaBody.parse(await req.json());
    const user = await db.query.users.findFirst({ where: eq(schema.users.email, email.toLowerCase().trim()) });

    // Always return ok, whether or not the account exists — never leak
    // which emails are registered.
    if (user) {
      const token = await db
        .insert(schema.verificationTokens)
        .values({
          userId: user.id,
          purpose: 'PASSWORD_RESET',
          token: createId('rt'),
          expiresAt: new Date(Date.now() + 3600 * 1000),
        })
        .returning()
        .then((r) => r[0]);

      const appUrl = process.env.NEXTAUTH_URL ?? 'http://localhost:3000';
      const link = `${appUrl}/reset-password?token=${token.token}`;
      await sendEmail({ to: user.email, subject: 'Reset your Personal CFO password', html: passwordResetEmailHtml(link) });
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    return toErrorResponse(err);
  }
}
