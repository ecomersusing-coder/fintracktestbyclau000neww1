import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { eq, and } from 'drizzle-orm';
import { db, schema } from '@/db/client';
import { hashPassword, isPasswordStrongEnough } from '@/lib/password';
import { toErrorResponse, AppError } from '@/lib/api-error';

const schemaBody = z.object({
  token: z.string(),
  password: z.string().min(10).refine(isPasswordStrongEnough, {
    message: 'Password must be at least 10 characters and include upper, lower case letters and a number.',
  }),
});

export async function POST(req: NextRequest) {
  try {
    const { token, password } = schemaBody.parse(await req.json());

    const row = await db.query.verificationTokens.findFirst({
      where: and(eq(schema.verificationTokens.token, token), eq(schema.verificationTokens.purpose, 'PASSWORD_RESET')),
    });
    if (!row || row.usedAt || row.expiresAt < new Date()) {
      throw new AppError('This reset link is invalid or has expired.', 400, 'INVALID_TOKEN');
    }

    const passwordHash = await hashPassword(password);
    await db.transaction((tx) => {
      tx.update(schema.verificationTokens).set({ usedAt: new Date() }).where(eq(schema.verificationTokens.id, row.id)).run();
      tx.update(schema.users).set({ passwordHash }).where(eq(schema.users.id, row.userId)).run();
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    return toErrorResponse(err);
  }
}
