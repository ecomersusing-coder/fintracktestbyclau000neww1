import { NextRequest, NextResponse } from 'next/server';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { bulkUpdateFilterSchema } from '@/lib/accounting/types';
import { previewBulkUpdate } from '@/lib/accounting/bulk';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const filter = bulkUpdateFilterSchema.parse(await req.json());
    const preview = await previewBulkUpdate(tenant, filter);
    return NextResponse.json(preview);
  } catch (err) {
    return toErrorResponse(err);
  }
}
