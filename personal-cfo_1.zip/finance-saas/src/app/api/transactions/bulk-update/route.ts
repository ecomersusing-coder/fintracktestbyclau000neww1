import { NextRequest, NextResponse } from 'next/server';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { bulkUpdateTransactionsSchema } from '@/lib/accounting/types';
import { executeBulkUpdate } from '@/lib/accounting/bulk';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const input = bulkUpdateTransactionsSchema.parse(await req.json());
    const result = await executeBulkUpdate(tenant, input);
    return NextResponse.json(result);
  } catch (err) {
    return toErrorResponse(err);
  }
}
