import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse, AppError } from '@/lib/api-error';
import { searchTransactions } from '@/lib/accounting/search';
import {
  createExpenseSchema,
  createIncomeSchema,
  createTransferSchema,
  createCreditCardPaymentSchema,
  createInvestmentPurchaseSchema,
  createInvestmentSaleSchema,
  createLoanPaymentSchema,
  createRefundSchema,
  createAdjustmentSchema,
} from '@/lib/accounting/types';
import {
  createExpense,
  createIncome,
  createTransfer,
  createCreditCardPayment,
  createInvestmentPurchase,
  createInvestmentSale,
  createLoanPayment,
  createRefund,
  createAdjustment,
} from '@/lib/accounting/create';
import { transactionTypeSchema } from '@/lib/enums';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const sp = req.nextUrl.searchParams;

    const filter = {
      merchant: sp.get('merchant') ?? undefined,
      categoryId: sp.get('categoryId') ?? undefined,
      accountId: sp.get('accountId') ?? undefined,
      creditCardId: sp.get('creditCardId') ?? undefined,
      type: (sp.get('type') as any) ?? undefined,
      amountMinMajor: sp.get('amountMin') ? Number(sp.get('amountMin')) : undefined,
      amountMaxMajor: sp.get('amountMax') ? Number(sp.get('amountMax')) : undefined,
      dateFrom: sp.get('dateFrom') ? new Date(sp.get('dateFrom')!) : undefined,
      dateTo: sp.get('dateTo') ? new Date(sp.get('dateTo')!) : undefined,
      freeText: sp.get('q') ?? undefined,
    };

    const result = await searchTransactions(tenant, filter, {
      page: sp.get('page') ? Number(sp.get('page')) : 1,
      pageSize: sp.get('pageSize') ? Number(sp.get('pageSize')) : 50,
      sortBy: (sp.get('sortBy') as 'occurredAt' | 'amountMinor') ?? 'occurredAt',
      sortDir: (sp.get('sortDir') as 'asc' | 'desc') ?? 'desc',
    });

    return NextResponse.json(result);
  } catch (err) {
    return toErrorResponse(err);
  }
}

const createRequestSchema = z.object({ type: transactionTypeSchema }).passthrough();

/**
 * A single write endpoint that dispatches to the correct accounting-engine
 * function by `type`. Keeping one entry point (rather than one route per
 * type) means the UI form, the CSV importer, and the AI copilot's
 * create_* tools can all share this exact same validation + dispatch path.
 */
export async function POST(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const body = createRequestSchema.parse(await req.json());

    switch (body.type) {
      case 'EXPENSE':
        return NextResponse.json(await createExpense(tenant, createExpenseSchema.parse(body)), { status: 201 });
      case 'CC_PURCHASE':
        return NextResponse.json(await createExpense(tenant, createExpenseSchema.parse(body)), { status: 201 });
      case 'INCOME':
        return NextResponse.json(await createIncome(tenant, createIncomeSchema.parse(body)), { status: 201 });
      case 'TRANSFER':
        return NextResponse.json(await createTransfer(tenant, createTransferSchema.parse(body)), { status: 201 });
      case 'CC_PAYMENT':
        return NextResponse.json(await createCreditCardPayment(tenant, createCreditCardPaymentSchema.parse(body)), { status: 201 });
      case 'INVESTMENT_PURCHASE':
        return NextResponse.json(await createInvestmentPurchase(tenant, createInvestmentPurchaseSchema.parse(body)), { status: 201 });
      case 'INVESTMENT_SALE':
        return NextResponse.json(await createInvestmentSale(tenant, createInvestmentSaleSchema.parse(body)), { status: 201 });
      case 'LOAN_PAYMENT':
        return NextResponse.json(await createLoanPayment(tenant, createLoanPaymentSchema.parse(body)), { status: 201 });
      case 'REFUND':
        return NextResponse.json(await createRefund(tenant, createRefundSchema.parse(body)), { status: 201 });
      case 'ADJUSTMENT':
        return NextResponse.json(await createAdjustment(tenant, createAdjustmentSchema.parse(body)), { status: 201 });
      default:
        throw new AppError('Unsupported transaction type', 422);
    }
  } catch (err) {
    return toErrorResponse(err);
  }
}
