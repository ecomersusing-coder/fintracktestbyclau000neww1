import { NextRequest, NextResponse } from 'next/server';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { undoLastChange } from '@/lib/accounting/delete';

export const dynamic = 'force-dynamic';

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tenant = await requireTenant();
    const transaction = await undoLastChange(tenant, params.id);
    return NextResponse.json({ transaction });
  } catch (err) {
    return toErrorResponse(err);
  }
}
