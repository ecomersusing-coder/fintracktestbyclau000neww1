import { NextRequest, NextResponse } from 'next/server';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { updateTransactionSchema } from '@/lib/accounting/types';
import { updateTransaction } from '@/lib/accounting/update';
import { deleteTransaction } from '@/lib/accounting/delete';

export const dynamic = 'force-dynamic';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tenant = await requireTenant();
    const body = updateTransactionSchema.parse({ ...(await req.json()), transactionId: params.id });
    const result = await updateTransaction(tenant, body);
    return NextResponse.json(result);
  } catch (err) {
    return toErrorResponse(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tenant = await requireTenant();
    const result = await deleteTransaction(tenant, params.id);
    return NextResponse.json(result);
  } catch (err) {
    return toErrorResponse(err);
  }
}
