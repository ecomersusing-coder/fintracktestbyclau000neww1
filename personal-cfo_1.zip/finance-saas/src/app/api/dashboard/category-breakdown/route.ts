import { NextRequest, NextResponse } from 'next/server';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { getCategoryBreakdown } from '@/lib/accounting/search';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const sp = req.nextUrl.searchParams;
    const now = new Date();
    const dateFrom = sp.get('dateFrom') ? new Date(sp.get('dateFrom')!) : new Date(now.getFullYear(), now.getMonth(), 1);
    const dateTo = sp.get('dateTo') ? new Date(sp.get('dateTo')!) : now;

    const breakdown = await getCategoryBreakdown(tenant, {
      dateFrom,
      dateTo,
      types: ['EXPENSE', 'CC_PURCHASE'],
    });

    return NextResponse.json(breakdown);
  } catch (err) {
    return toErrorResponse(err);
  }
}
