import { NextRequest, NextResponse } from 'next/server';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { getCashFlowSeries } from '@/lib/analytics/summary';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const tenant = await requireTenant();
    const months = Number(req.nextUrl.searchParams.get('months') ?? 6);
    const series = await getCashFlowSeries(tenant, Math.min(Math.max(months, 1), 24));
    return NextResponse.json({ series });
  } catch (err) {
    return toErrorResponse(err);
  }
}
