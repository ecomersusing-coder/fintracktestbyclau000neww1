import { NextResponse } from 'next/server';
import { requireTenant } from '@/lib/tenant';
import { toErrorResponse } from '@/lib/api-error';
import { getDashboardSummary } from '@/lib/analytics/summary';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const tenant = await requireTenant();
    const summary = await getDashboardSummary(tenant);
    return NextResponse.json(summary);
  } catch (err) {
    return toErrorResponse(err);
  }
}
