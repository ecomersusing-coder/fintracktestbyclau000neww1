'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { signIn } from 'next-auth/react';
import Link from 'next/link';
import { AuthShell } from '@/components/auth-shell';

export default function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState('demo@personalcfo.local');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const verified = params.get('verified') === '1';

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const result = await signIn('credentials', { email, password, redirect: false });
    setLoading(false);
    if (result?.error) {
      setError('Incorrect email or password.');
      return;
    }
    router.push(params.get('from') ?? '/dashboard');
    router.refresh();
  }

  return (
    <AuthShell title="Welcome back" subtitle="Sign in to your Personal CFO">
      {verified && (
        <div className="mb-4 rounded-lg bg-moss-50 px-3 py-2 text-sm text-moss-700 dark:bg-moss-950 dark:text-moss-300">
          Email verified — you can sign in now.
        </div>
      )}
      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="label-text mb-1 block">Email</label>
          <input
            type="email"
            required
            className="input-field"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div>
          <label className="label-text mb-1 block">Password</label>
          <input
            type="password"
            required
            className="input-field"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {error && <p className="text-sm text-rose-600">{error}</p>}
        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
      <div className="mt-4 flex items-center justify-between text-sm">
        <Link href="/forgot-password" className="text-ink-500 hover:text-ink-800 dark:text-ink-300">
          Forgot password?
        </Link>
        <Link href="/signup" className="font-medium text-moss-600 hover:text-moss-700">
          Create account
        </Link>
      </div>
      <p className="mt-4 text-center text-xs text-ink-400">
        Demo login: demo@personalcfo.local / Demo1234!
      </p>
    </AuthShell>
  );
}
