import type { Metadata } from 'next';
import './globals.css';
import { Providers } from '@/components/providers';

// NOTE: this sandbox's network also blocks fonts.googleapis.com, so
// next/font/google can't fetch anything here either. Using a system-font
// stack for now (defined in globals.css) — swap in next/font/google or
// self-hosted font files once this is deployed somewhere with normal
// internet access; nothing else needs to change.

export const metadata: Metadata = {
  title: 'Personal CFO — AI Finance Copilot',
  description: 'Manage your entire financial life by talking to it.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
