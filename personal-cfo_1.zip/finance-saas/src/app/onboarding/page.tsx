'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { clsx } from 'clsx';

const GOALS = ['Save more', 'Control spending', 'Build emergency fund', 'Pay debt', 'Track investments', 'Understand finances'];
const INCOME_RANGES = ['< ₹25,000', '₹25,000–₹50,000', '₹50,000–₹1,00,000', '₹1,00,000–₹2,50,000', '₹2,50,000+'];
const ACCOUNT_TYPES = [
  { type: 'SAVINGS', label: 'Bank account' },
  { type: 'CASH', label: 'Cash wallet' },
];
const CATEGORY_OPTIONS = ['Food', 'Groceries', 'Shopping', 'Transport', 'Rent', 'Utilities', 'Subscriptions', 'Entertainment', 'Travel', 'Healthcare'];

const STEPS = ['Name', 'Country', 'Currency', 'Income', 'Goals', 'Accounts', 'Categories'];

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  const [name, setName] = useState('');
  const [country, setCountry] = useState('India');
  const [currency, setCurrency] = useState('INR');
  const [incomeRange, setIncomeRange] = useState('');
  const [goals, setGoals] = useState<string[]>([]);
  const [accounts, setAccounts] = useState<{ name: string; type: string; openingBalanceMajor: number }[]>([]);
  const [newAccountName, setNewAccountName] = useState('');
  const [newAccountType, setNewAccountType] = useState('SAVINGS');
  const [categories, setCategories] = useState<string[]>(['Food', 'Shopping', 'Transport']);

  async function finish(skip = false) {
    setSubmitting(true);
    try {
      if (skip) {
        await fetch('/api/onboarding', { method: 'PATCH' });
      } else {
        await fetch('/api/onboarding', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: name || undefined,
            country,
            currency,
            monthlyIncomeRange: incomeRange || undefined,
            goals,
            initialAccounts: accounts,
            preferredCategoryNames: categories,
          }),
        });
      }
      router.push('/dashboard');
      router.refresh();
    } finally {
      setSubmitting(false);
    }
  }

  function toggleGoal(g: string) {
    setGoals((prev) => (prev.includes(g) ? prev.filter((x) => x !== g) : [...prev, g]));
  }
  function toggleCategory(c: string) {
    setCategories((prev) => (prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]));
  }
  function addAccount() {
    if (!newAccountName.trim()) return;
    setAccounts((prev) => [...prev, { name: newAccountName, type: newAccountType, openingBalanceMajor: 0 }]);
    setNewAccountName('');
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-paper-50 px-4 dark:bg-ink-950">
      <div className="w-full max-w-lg">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex gap-1.5">
            {STEPS.map((_, i) => (
              <div key={i} className={clsx('h-1.5 w-8 rounded-full', i <= step ? 'bg-moss-500' : 'bg-ink-100 dark:bg-ink-800')} />
            ))}
          </div>
          <button onClick={() => finish(true)} disabled={submitting} className="text-xs text-ink-400 hover:text-ink-700">
            Skip for now
          </button>
        </div>

        <div className="card p-6">
          {step === 0 && (
            <StepShell title="What should we call you?">
              <input className="input-field" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
            </StepShell>
          )}

          {step === 1 && (
            <StepShell title="Where are you based?">
              <input className="input-field" value={country} onChange={(e) => setCountry(e.target.value)} />
            </StepShell>
          )}

          {step === 2 && (
            <StepShell title="Preferred currency">
              <select className="input-field" value={currency} onChange={(e) => setCurrency(e.target.value)}>
                <option value="INR">₹ INR — Indian Rupee</option>
                <option value="USD">$ USD — US Dollar</option>
                <option value="EUR">€ EUR — Euro</option>
                <option value="GBP">£ GBP — British Pound</option>
              </select>
            </StepShell>
          )}

          {step === 3 && (
            <StepShell title="Monthly income range" subtitle="Helps us tailor budgets and insights">
              <div className="space-y-1.5">
                {INCOME_RANGES.map((r) => (
                  <ChoiceRow key={r} label={r} selected={incomeRange === r} onClick={() => setIncomeRange(r)} />
                ))}
              </div>
            </StepShell>
          )}

          {step === 4 && (
            <StepShell title="What are your financial goals?" subtitle="Pick as many as apply">
              <div className="space-y-1.5">
                {GOALS.map((g) => (
                  <ChoiceRow key={g} label={g} selected={goals.includes(g)} onClick={() => toggleGoal(g)} multi />
                ))}
              </div>
            </StepShell>
          )}

          {step === 5 && (
            <StepShell title="Add your accounts" subtitle="Optional — you can always add more later">
              <div className="mb-3 flex gap-2">
                <input
                  className="input-field flex-1"
                  placeholder="e.g. HDFC Savings"
                  value={newAccountName}
                  onChange={(e) => setNewAccountName(e.target.value)}
                />
                <select className="input-field w-32" value={newAccountType} onChange={(e) => setNewAccountType(e.target.value)}>
                  {ACCOUNT_TYPES.map((a) => (
                    <option key={a.type} value={a.type}>
                      {a.label}
                    </option>
                  ))}
                </select>
                <button onClick={addAccount} className="btn-secondary shrink-0">
                  Add
                </button>
              </div>
              <div className="space-y-1">
                {accounts.map((a, i) => (
                  <div key={i} className="flex items-center justify-between rounded-lg bg-ink-50 px-3 py-2 text-sm dark:bg-ink-800">
                    <span>{a.name}</span>
                    <span className="text-ink-400">{a.type}</span>
                  </div>
                ))}
                {accounts.length === 0 && <p className="text-sm text-ink-400">No accounts added yet.</p>}
              </div>
            </StepShell>
          )}

          {step === 6 && (
            <StepShell title="Choose preferred categories" subtitle="You can customize these anytime in Settings">
              <div className="flex flex-wrap gap-2">
                {CATEGORY_OPTIONS.map((c) => (
                  <button
                    key={c}
                    onClick={() => toggleCategory(c)}
                    className={clsx(
                      'rounded-full border px-3 py-1.5 text-sm transition',
                      categories.includes(c)
                        ? 'border-moss-500 bg-moss-50 text-moss-800 dark:bg-moss-950 dark:text-moss-300'
                        : 'border-ink-200 text-ink-600 dark:border-ink-700 dark:text-ink-300'
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </StepShell>
          )}

          <div className="mt-6 flex justify-between">
            <button onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0} className="btn-secondary disabled:opacity-0">
              Back
            </button>
            {step < STEPS.length - 1 ? (
              <button onClick={() => setStep((s) => s + 1)} className="btn-primary">
                Continue
              </button>
            ) : (
              <button onClick={() => finish(false)} disabled={submitting} className="btn-primary">
                {submitting ? 'Setting up…' : 'Go to dashboard'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StepShell({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="font-display text-xl text-ink-900 dark:text-paper-100">{title}</h2>
      {subtitle && <p className="mt-1 text-sm text-ink-500 dark:text-ink-300">{subtitle}</p>}
      <div className="mt-4">{children}</div>
    </div>
  );
}

function ChoiceRow({ label, selected, onClick, multi }: { label: string; selected: boolean; onClick: () => void; multi?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={clsx(
        'flex w-full items-center justify-between rounded-lg border px-3 py-2 text-left text-sm transition',
        selected ? 'border-moss-500 bg-moss-50 text-moss-800 dark:bg-moss-950 dark:text-moss-300' : 'border-ink-200 dark:border-ink-700'
      )}
    >
      {label}
      {selected && <span>{multi ? '✓' : '●'}</span>}
    </button>
  );
}
