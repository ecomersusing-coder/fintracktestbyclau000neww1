import { clsx } from 'clsx';

export function StatCard({
  label,
  value,
  tone = 'default',
  sub,
}: {
  label: string;
  value: string;
  tone?: 'default' | 'positive' | 'negative';
  sub?: string;
}) {
  return (
    <div className="card p-4">
      <p className="label-text">{label}</p>
      <p
        className={clsx(
          'stat-number mt-1.5 text-2xl',
          tone === 'positive' && 'text-moss-600',
          tone === 'negative' && 'text-rose-600',
          tone === 'default' && 'text-ink-900 dark:text-paper-100'
        )}
      >
        {value}
      </p>
      {sub && <p className="mt-1 text-xs text-ink-400">{sub}</p>}
    </div>
  );
}
