'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { signOut } from 'next-auth/react';
import { clsx } from 'clsx';

const NAV_GROUPS: { label: string | null; items: { href: string; label: string }[] }[] = [
  { label: null, items: [{ href: '/dashboard', label: 'Dashboard' }] },
  {
    label: 'Finance',
    items: [
      { href: '/transactions', label: 'Transactions' },
      { href: '/accounts', label: 'Accounts' },
      { href: '/credit-cards', label: 'Credit Cards' },
    ],
  },
  {
    label: 'Planning',
    items: [
      { href: '/budgets', label: 'Budgets' },
      { href: '/bills', label: 'Bills' },
      { href: '/subscriptions', label: 'Subscriptions' },
      { href: '/goals', label: 'Goals' },
    ],
  },
  {
    label: 'Wealth',
    items: [
      { href: '/net-worth', label: 'Net Worth' },
      { href: '/investments', label: 'Investments' },
      { href: '/loans', label: 'Loans & Debt' },
    ],
  },
  { label: 'Analytics', items: [{ href: '/reports', label: 'Reports' }] },
  { label: 'AI', items: [{ href: '/copilot', label: 'Finance Copilot' }] },
];

export function Sidebar({ userEmail, workspaceName }: { userEmail: string; workspaceName: string }) {
  const pathname = usePathname();

  return (
    <aside className="flex h-screen w-60 flex-col border-r border-ink-100 bg-white dark:border-ink-800 dark:bg-ink-900">
      <div className="flex items-center gap-2 border-b border-ink-100 px-5 py-4 dark:border-ink-800">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-ink-900 text-xs font-semibold text-white dark:bg-moss-500">
          ₹
        </div>
        <span className="truncate font-display text-sm text-ink-900 dark:text-paper-100">{workspaceName}</span>
      </div>

      <nav className="flex-1 space-y-5 overflow-y-auto px-3 py-4">
        {NAV_GROUPS.map((group, i) => (
          <div key={i}>
            {group.label && <p className="label-text mb-1.5 px-2">{group.label}</p>}
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = pathname === item.href || pathname.startsWith(item.href + '/');
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={clsx(
                      'block rounded-lg px-2.5 py-1.5 text-sm transition',
                      active
                        ? 'bg-moss-50 font-medium text-moss-800 dark:bg-moss-950 dark:text-moss-300'
                        : 'text-ink-600 hover:bg-ink-50 dark:text-ink-300 dark:hover:bg-ink-800'
                    )}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="border-t border-ink-100 px-3 py-3 dark:border-ink-800">
        <Link href="/settings" className="block truncate rounded-lg px-2.5 py-1.5 text-sm text-ink-600 hover:bg-ink-50 dark:text-ink-300 dark:hover:bg-ink-800">
          {userEmail}
        </Link>
        <button
          onClick={() => signOut({ callbackUrl: '/login' })}
          className="mt-1 w-full rounded-lg px-2.5 py-1.5 text-left text-sm text-ink-500 hover:bg-ink-50 dark:text-ink-400 dark:hover:bg-ink-800"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
