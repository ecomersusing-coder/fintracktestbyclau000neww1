export function ComingSoon({ title, phase, description }: { title: string; phase: string; description: string }) {
  return (
    <div className="mx-auto max-w-3xl px-6 py-8">
      <h1 className="font-display text-2xl text-ink-900 dark:text-paper-100">{title}</h1>
      <p className="mt-1 text-sm text-ink-500 dark:text-ink-300">{description}</p>
      <div className="card mt-6 p-6">
        <p className="label-text mb-1">Build status</p>
        <p className="text-sm text-ink-600 dark:text-ink-300">
          The database schema, tenant-scoped API pattern, and accounting-engine hooks for this section already
          exist. The dedicated UI is scheduled for <strong>{phase}</strong> of the build plan — see the README for
          the full phase breakdown.
        </p>
      </div>
    </div>
  );
}
