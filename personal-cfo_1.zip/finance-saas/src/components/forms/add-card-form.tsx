'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export function AddCardForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [bankName, setBankName] = useState('');
  const [limit, setLimit] = useState('100000');
  const [outstanding, setOutstanding] = useState('0');
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    const res = await fetch('/api/credit-cards', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        bankName: bankName || undefined,
        creditLimitMajor: Number(limit) || 0,
        outstandingMajor: Number(outstanding) || 0,
      }),
    });
    setSubmitting(false);
    if (res.ok) {
      setOpen(false);
      setName('');
      setBankName('');
      router.refresh();
    }
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="btn-primary">
        Add credit card
      </button>
    );
  }

  return (
    <form onSubmit={onSubmit} className="card flex flex-wrap items-end gap-3 p-4">
      <div>
        <label className="label-text mb-1 block">Name</label>
        <input required className="input-field w-40" value={name} onChange={(e) => setName(e.target.value)} placeholder="HDFC Credit Card" />
      </div>
      <div>
        <label className="label-text mb-1 block">Bank</label>
        <input className="input-field w-40" value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="HDFC Bank" />
      </div>
      <div>
        <label className="label-text mb-1 block">Credit limit</label>
        <input type="number" className="input-field w-32" value={limit} onChange={(e) => setLimit(e.target.value)} />
      </div>
      <div>
        <label className="label-text mb-1 block">Current outstanding</label>
        <input type="number" className="input-field w-32" value={outstanding} onChange={(e) => setOutstanding(e.target.value)} />
      </div>
      <button type="submit" disabled={submitting} className="btn-primary">
        {submitting ? 'Saving…' : 'Save'}
      </button>
      <button type="button" onClick={() => setOpen(false)} className="btn-secondary">
        Cancel
      </button>
    </form>
  );
}
