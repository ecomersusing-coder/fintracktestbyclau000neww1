'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

const TYPES = ['SAVINGS', 'CURRENT', 'SALARY', 'BUSINESS', 'CASH', 'WALLET', 'OTHER'];

export function AddAccountForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [bankName, setBankName] = useState('');
  const [type, setType] = useState('SAVINGS');
  const [opening, setOpening] = useState('0');
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    const res = await fetch('/api/accounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, bankName: bankName || undefined, type, openingBalanceMajor: Number(opening) || 0 }),
    });
    setSubmitting(false);
    if (res.ok) {
      setOpen(false);
      setName('');
      setBankName('');
      setOpening('0');
      router.refresh();
    }
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="btn-primary">
        Add account
      </button>
    );
  }

  return (
    <form onSubmit={onSubmit} className="card flex flex-wrap items-end gap-3 p-4">
      <div>
        <label className="label-text mb-1 block">Name</label>
        <input required className="input-field w-40" value={name} onChange={(e) => setName(e.target.value)} placeholder="HDFC Savings" />
      </div>
      <div>
        <label className="label-text mb-1 block">Bank</label>
        <input className="input-field w-40" value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="HDFC Bank" />
      </div>
      <div>
        <label className="label-text mb-1 block">Type</label>
        <select className="input-field w-32" value={type} onChange={(e) => setType(e.target.value)}>
          {TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label-text mb-1 block">Opening balance</label>
        <input type="number" className="input-field w-32" value={opening} onChange={(e) => setOpening(e.target.value)} />
      </div>
      <button type="submit" disabled={submitting} className="btn-primary">
        {submitting ? 'Saving…' : 'Save'}
      </button>
      <button type="button" onClick={() => setOpen(false)} className="btn-secondary">
        Cancel
      </button>
    </form>
  );
}
