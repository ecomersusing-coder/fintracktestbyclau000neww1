'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

interface Account {
  id: string;
  name: string;
}
interface Card {
  id: string;
  name: string;
}
interface Category {
  id: string;
  name: string;
  kind: string;
}

const TYPE_OPTIONS = [
  { value: 'EXPENSE', label: 'Expense' },
  { value: 'INCOME', label: 'Income' },
  { value: 'TRANSFER', label: 'Transfer' },
  { value: 'CC_PAYMENT', label: 'Credit card payment' },
];

export function AddTransactionForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [cards, setCards] = useState<Card[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [type, setType] = useState('EXPENSE');
  const [amount, setAmount] = useState('');
  const [payFrom, setPayFrom] = useState<'account' | 'card'>('account');
  const [accountId, setAccountId] = useState('');
  const [creditCardId, setCreditCardId] = useState('');
  const [toAccountId, setToAccountId] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [merchant, setMerchant] = useState('');
  const [occurredAt, setOccurredAt] = useState(() => new Date().toISOString().slice(0, 10));

  useEffect(() => {
    if (!open) return;
    fetch('/api/accounts').then((r) => r.json()).then((d) => setAccounts(d.accounts ?? []));
    fetch('/api/credit-cards').then((r) => r.json()).then((d) => setCards(d.cards ?? []));
    fetch('/api/categories').then((r) => r.json()).then((d) => setCategories(d.categories ?? []));
  }, [open]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    const base = { amountMajor: Number(amount), currency: 'INR', occurredAt, merchant: merchant || undefined, categoryId: categoryId || undefined };
    let payload: Record<string, unknown>;

    if (type === 'EXPENSE') {
      payload = payFrom === 'account' ? { type, ...base, accountId } : { type, ...base, creditCardId };
    } else if (type === 'INCOME') {
      payload = { type, ...base, accountId };
    } else if (type === 'TRANSFER') {
      payload = { type, ...base, fromAccountId: accountId, toAccountId };
    } else {
      payload = { type, ...base, accountId, creditCardId };
    }

    const res = await fetch('/api/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    setSubmitting(false);

    if (!res.ok) {
      setError(data.message ?? 'Could not save this transaction.');
      return;
    }

    setOpen(false);
    setAmount('');
    setMerchant('');
    router.refresh();
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="btn-primary">
        Add transaction
      </button>
    );
  }

  const relevantCategories = categories.filter((c) => (type === 'INCOME' ? c.kind !== 'EXPENSE' : c.kind !== 'INCOME'));

  return (
    <form onSubmit={onSubmit} className="card mb-6 space-y-3 p-4">
      <div className="flex flex-wrap gap-3">
        <div>
          <label className="label-text mb-1 block">Type</label>
          <select className="input-field w-44" value={type} onChange={(e) => setType(e.target.value)}>
            {TYPE_OPTIONS.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label-text mb-1 block">Amount (₹)</label>
          <input type="number" required min="0.01" step="0.01" className="input-field w-32" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <div>
          <label className="label-text mb-1 block">Date</label>
          <input type="date" className="input-field w-40" value={occurredAt} onChange={(e) => setOccurredAt(e.target.value)} />
        </div>
      </div>

      {type === 'EXPENSE' && (
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="label-text mb-1 block">Pay from</label>
            <div className="flex gap-2">
              <button type="button" onClick={() => setPayFrom('account')} className={`btn-secondary ${payFrom === 'account' ? 'ring-1 ring-moss-500' : ''}`}>
                Bank/Cash
              </button>
              <button type="button" onClick={() => setPayFrom('card')} className={`btn-secondary ${payFrom === 'card' ? 'ring-1 ring-moss-500' : ''}`}>
                Credit card
              </button>
            </div>
          </div>
          {payFrom === 'account' ? (
            <SelectField label="Account" value={accountId} onChange={setAccountId} options={accounts} />
          ) : (
            <SelectField label="Card" value={creditCardId} onChange={setCreditCardId} options={cards} />
          )}
        </div>
      )}

      {type === 'INCOME' && <SelectField label="Into account" value={accountId} onChange={setAccountId} options={accounts} />}

      {type === 'TRANSFER' && (
        <div className="flex flex-wrap gap-3">
          <SelectField label="From account" value={accountId} onChange={setAccountId} options={accounts} />
          <SelectField label="To account" value={toAccountId} onChange={setToAccountId} options={accounts} />
        </div>
      )}

      {type === 'CC_PAYMENT' && (
        <div className="flex flex-wrap gap-3">
          <SelectField label="From account" value={accountId} onChange={setAccountId} options={accounts} />
          <SelectField label="To card" value={creditCardId} onChange={setCreditCardId} options={cards} />
        </div>
      )}

      {(type === 'EXPENSE' || type === 'INCOME') && (
        <div className="flex flex-wrap gap-3">
          <div>
            <label className="label-text mb-1 block">Merchant</label>
            <input className="input-field w-48" value={merchant} onChange={(e) => setMerchant(e.target.value)} placeholder="e.g. Lulu, Amazon" />
          </div>
          <SelectField label="Category" value={categoryId} onChange={setCategoryId} options={relevantCategories} optional />
        </div>
      )}

      {error && <p className="text-sm text-rose-600">{error}</p>}

      <div className="flex gap-2 pt-1">
        <button type="submit" disabled={submitting} className="btn-primary">
          {submitting ? 'Saving…' : 'Save transaction'}
        </button>
        <button type="button" onClick={() => setOpen(false)} className="btn-secondary">
          Cancel
        </button>
      </div>
    </form>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
  optional,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { id: string; name: string }[];
  optional?: boolean;
}) {
  return (
    <div>
      <label className="label-text mb-1 block">{label}</label>
      <select required={!optional} className="input-field w-44" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">{optional ? 'None' : 'Select…'}</option>
        {options.map((o) => (
          <option key={o.id} value={o.id}>
            {o.name}
          </option>
        ))}
      </select>
    </div>
  );
}
