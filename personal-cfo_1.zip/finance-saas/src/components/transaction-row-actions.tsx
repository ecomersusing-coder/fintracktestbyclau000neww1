'use client';

import { useRouter } from 'next/navigation';

export function TransactionRowActions({ id }: { id: string }) {
  const router = useRouter();

  async function onDelete() {
    if (!confirm('Delete this transaction? This reverses its effect on your balances.')) return;
    const res = await fetch(`/api/transactions/${id}`, { method: 'DELETE' });
    if (res.ok) router.refresh();
  }

  return (
    <button onClick={onDelete} className="text-xs text-ink-400 hover:text-rose-600">
      Delete
    </button>
  );
}
