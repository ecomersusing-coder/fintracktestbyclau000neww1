'use client';

import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { formatMoney } from '@/lib/money';

const COLORS = ['#398a63', '#cc8a4a', '#71858a', '#cc5c5c', '#87c4a2', '#e0a86f', '#2d3a3e', '#58a67e'];

export function CategoryPieChart({
  data,
  currency,
}: {
  data: { categoryName: string | null; totalMinor: number }[];
  currency: string;
}) {
  const chartData = data
    .filter((d) => d.totalMinor > 0)
    .slice(0, 8)
    .map((d) => ({ name: d.categoryName ?? 'Uncategorized', value: d.totalMinor }));

  if (chartData.length === 0) {
    return <div className="flex h-60 items-center justify-center text-sm text-ink-400">No spending yet this period.</div>;
  }

  return (
    <ResponsiveContainer width="100%" height={240}>
      <PieChart>
        <Pie data={chartData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={2}>
          {chartData.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip formatter={(value: number) => formatMoney(value, currency)} contentStyle={{ borderRadius: 8, border: '1px solid #e8ecec', fontSize: 12 }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}
