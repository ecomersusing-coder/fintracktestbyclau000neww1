'use client';

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { formatMoney } from '@/lib/money';

export function CashFlowChart({
  data,
  currency,
}: {
  data: { month: string; incomeMinor: number; expenseMinor: number }[];
  currency: string;
}) {
  const chartData = data.map((d) => ({ month: d.month, Income: d.incomeMinor / 100, Expenses: d.expenseMinor / 100 }));

  return (
    <ResponsiveContainer width="100%" height={240}>
      <BarChart data={chartData} barGap={4}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e8ecec" />
        <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} stroke="#71858a" />
        <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="#71858a" width={40} />
        <Tooltip
          formatter={(value: number) => formatMoney(Math.round(value * 100), currency)}
          contentStyle={{ borderRadius: 8, border: '1px solid #e8ecec', fontSize: 12 }}
        />
        <Bar dataKey="Income" fill="#398a63" radius={[4, 4, 0, 0]} />
        <Bar dataKey="Expenses" fill="#cc5c5c" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
