import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, updatedAt, boolColumn, moneyMinor, tsColumn } from './_helpers';

// billingCycle: MONTHLY | YEARLY | WEEKLY | CUSTOM
// NOTE: tracks the user's *personal* subscriptions (Netflix etc.) — distinct
// from this app's own `subscriptions` (SaaS billing) table.
export const subscriptionsTracked = sqliteTable(
  'subscriptions_tracked',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    serviceName: text('service_name').notNull(),
    amountMinor: moneyMinor('amount_minor'),
    billingCycle: text('billing_cycle').notNull().default('MONTHLY'),
    nextRenewalAt: tsColumn('next_renewal_at').notNull(),
    accountId: text('account_id'),
    categoryId: text('category_id'),
    isActive: boolColumn('is_active', true),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('subtrack_workspace_idx').on(t.workspaceId),
  })
);

// frequency: MONTHLY | QUARTERLY | YEARLY
export const fixedExpenses = sqliteTable(
  'fixed_expenses',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    amountMinor: moneyMinor('amount_minor'),
    dueDay: integer('due_day').notNull(),
    frequency: text('frequency').notNull().default('MONTHLY'),
    accountId: text('account_id'),
    categoryId: text('category_id'),
    reminderDaysBefore: integer('reminder_days_before'),
    isActive: boolColumn('is_active', true),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('fixed_workspace_idx').on(t.workspaceId),
  })
);

// frequency: DAILY | WEEKLY | MONTHLY | QUARTERLY | YEARLY | CUSTOM
export const recurringTransactions = sqliteTable(
  'recurring_transactions',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    templateJson: text('template_json').notNull(),
    frequency: text('frequency').notNull(),
    intervalCount: integer('interval_count').notNull().default(1),
    nextRunAt: tsColumn('next_run_at').notNull(),
    endDate: tsColumn('end_date'),
    lastGeneratedAt: tsColumn('last_generated_at'),
    isActive: boolColumn('is_active', true),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('recur_workspace_idx').on(t.workspaceId),
  })
);

// category: BILL | CC_DUE | EMI | SUBSCRIPTION | INSURANCE | FIXED_EXPENSE | INCOME_EXPECTED
// status: UPCOMING | DUE | PAID | OVERDUE
export const bills = sqliteTable(
  'bills',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    amountMinor: moneyMinor('amount_minor'),
    dueDate: tsColumn('due_date').notNull(),
    category: text('category').notNull(),
    status: text('status').notNull().default('UPCOMING'),
    relatedType: text('related_type'),
    relatedId: text('related_id'),
    paidTransactionId: text('paid_transaction_id'),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspaceDue: index('bill_workspace_due_idx').on(t.workspaceId, t.dueDate),
  })
);
