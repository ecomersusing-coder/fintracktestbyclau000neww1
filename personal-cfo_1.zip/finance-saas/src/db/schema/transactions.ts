import { sqliteTable, text, integer, index, primaryKey } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, updatedAt, boolColumn, moneyMinor, tsColumn } from './_helpers';

// The single unified ledger (spec §10 — "do not create disconnected
// transaction systems that cause double counting"). Every financial event
// is one row here. ONLY src/lib/accounting/* may write to this table —
// that module is what enforces the double-entry rules in spec §15.
//
// type: EXPENSE | INCOME | TRANSFER | CC_PURCHASE | CC_PAYMENT |
//       INVESTMENT_PURCHASE | INVESTMENT_SALE | LOAN_PAYMENT | REFUND | ADJUSTMENT
// source: MANUAL | AI_CHAT | RECEIPT_AI | IMPORT | RECURRING
export const transactions = sqliteTable(
  'transactions',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    type: text('type').notNull(),
    amountMinor: moneyMinor('amount_minor'), // always >= 0; direction implied by `type`
    direction: integer('direction').notNull().default(1), // ADJUSTMENT only: 1 credit / -1 debit
    currency: text('currency').notNull().default('INR'),
    occurredAt: tsColumn('occurred_at').notNull(),

    // Ledger endpoints — which are set depends on `type` (see accounting engine)
    accountId: text('account_id'),
    creditCardId: text('credit_card_id'),
    transferToAccountId: text('transfer_to_account_id'),
    investmentId: text('investment_id'),
    loanId: text('loan_id'),
    relatedTransactionId: text('related_transaction_id'),

    categoryId: text('category_id'),
    merchant: text('merchant'),
    description: text('description'),
    notes: text('notes'),
    paymentMethod: text('payment_method'),
    isEssential: integer('is_essential', { mode: 'boolean' }),
    isBusiness: integer('is_business', { mode: 'boolean' }),
    isTaxRelated: integer('is_tax_related', { mode: 'boolean' }),
    isRecurring: boolColumn('is_recurring', false),
    recurringTransactionId: text('recurring_transaction_id'),

    source: text('source').notNull().default('MANUAL'),
    aiConversationId: text('ai_conversation_id'),
    isDemo: boolColumn('is_demo', false),

    deletedAt: tsColumn('deleted_at'),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspaceDate: index('txn_workspace_date_idx').on(t.workspaceId, t.occurredAt),
    byWorkspaceType: index('txn_workspace_type_idx').on(t.workspaceId, t.type),
    byWorkspaceCategory: index('txn_workspace_category_idx').on(t.workspaceId, t.categoryId),
    byWorkspaceMerchant: index('txn_workspace_merchant_idx').on(t.workspaceId, t.merchant),
    byWorkspaceDeleted: index('txn_workspace_deleted_idx').on(t.workspaceId, t.deletedAt),
  })
);

export const tags = sqliteTable(
  'tags',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    color: text('color'),
  },
  (t) => ({
    byWorkspace: index('tag_workspace_idx').on(t.workspaceId),
  })
);

export const transactionTags = sqliteTable(
  'transaction_tags',
  {
    transactionId: text('transaction_id').notNull(),
    tagId: text('tag_id').notNull(),
  },
  (t) => ({
    pk: primaryKey({ columns: [t.transactionId, t.tagId] }),
  })
);

export const attachments = sqliteTable(
  'attachments',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    transactionId: text('transaction_id'),
    url: text('url').notNull(),
    fileName: text('file_name').notNull(),
    mimeType: text('mime_type').notNull(),
    sizeBytes: integer('size_bytes').notNull(),
    extractedData: text('extracted_data'), // JSON string — AI receipt-extraction result
    createdAt: createdAt(),
  },
  (t) => ({
    byWorkspace: index('att_workspace_idx').on(t.workspaceId),
  })
);
