import { sqliteTable, text, integer, index, unique } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, boolColumn, moneyMinor, tsColumn } from './_helpers';

export const financialSnapshots = sqliteTable(
  'financial_snapshots',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    snapshotDate: tsColumn('snapshot_date').notNull(),
    netWorthMinor: moneyMinor('net_worth_minor'),
    assetsMinor: moneyMinor('assets_minor'),
    liabilitiesMinor: moneyMinor('liabilities_minor'),
    cashMinor: moneyMinor('cash_minor'),
    investmentsMinor: moneyMinor('investments_minor'),
    debtMinor: moneyMinor('debt_minor'),
    createdAt: createdAt(),
  },
  (t) => ({
    uniqDate: unique('snap_workspace_date_uniq').on(t.workspaceId, t.snapshotDate),
  })
);

export const notifications = sqliteTable(
  'notifications',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    userId: text('user_id'),
    type: text('type').notNull(),
    title: text('title').notNull(),
    body: text('body').notNull(),
    isRead: boolColumn('is_read', false),
    metadata: text('metadata'), // JSON
    createdAt: createdAt(),
  },
  (t) => ({
    byWorkspaceRead: index('notif_workspace_read_idx').on(t.workspaceId, t.isRead),
  })
);

// channel: IN_APP | EMAIL
export const notificationSettings = sqliteTable(
  'notification_settings',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    userId: text('user_id').notNull(),
    type: text('type').notNull(),
    channel: text('channel').notNull().default('IN_APP'),
    enabled: boolColumn('enabled', true),
  },
  (t) => ({
    uniqSetting: unique('ns_uniq').on(t.workspaceId, t.userId, t.type, t.channel),
  })
);

// actorType: USER | AI | SYSTEM | ADMIN
export const auditLogs = sqliteTable(
  'audit_logs',
  {
    id: idColumn(),
    workspaceId: text('workspace_id'),
    userId: text('user_id'),
    actorType: text('actor_type').notNull().default('USER'),
    action: text('action').notNull(),
    entityType: text('entity_type').notNull(),
    entityId: text('entity_id'),
    before: text('before'), // JSON
    after: text('after'), // JSON
    requestText: text('request_text'),
    ipAddress: text('ip_address'),
    createdAt: createdAt(),
  },
  (t) => ({
    byWorkspaceDate: index('audit_workspace_date_idx').on(t.workspaceId, t.createdAt),
  })
);

// role: SUPERADMIN | SUPPORT | BILLING_ADMIN
// Deliberately a separate identity space from `users` — a bug or leaked
// session in the customer app can never grant admin access.
export const adminUsers = sqliteTable('admin_users', {
  id: idColumn(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  name: text('name'),
  role: text('role').notNull().default('SUPPORT'),
  isActive: boolColumn('is_active', true),
  createdAt: createdAt(),
});
