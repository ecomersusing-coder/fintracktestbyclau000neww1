import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, updatedAt, boolColumn, moneyMinor } from './_helpers';

// kind: EXPENSE | INCOME | BOTH
// workspaceId null = global system default category (shared, read-only)
export const categories = sqliteTable(
  'categories',
  {
    id: idColumn(),
    workspaceId: text('workspace_id'),
    parentId: text('parent_id'),
    name: text('name').notNull(),
    icon: text('icon'),
    color: text('color'),
    kind: text('kind').notNull().default('EXPENSE'),
    isSystem: boolColumn('is_system', false),
    isArchived: boolColumn('is_archived', false),
    createdAt: createdAt(),
  },
  (t) => ({
    byWorkspace: index('cat_workspace_idx').on(t.workspaceId),
  })
);

// type: SAVINGS | CURRENT | SALARY | BUSINESS | CASH | WALLET | OTHER
export const financialAccounts = sqliteTable(
  'financial_accounts',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    bankName: text('bank_name'),
    type: text('type').notNull().default('SAVINGS'),
    last4: text('last4'),
    currency: text('currency').notNull().default('INR'),
    openingBalanceMinor: moneyMinor('opening_balance_minor'),
    currentBalanceMinor: moneyMinor('current_balance_minor'),
    isActive: boolColumn('is_active', true),
    isDemo: boolColumn('is_demo', false),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('acct_workspace_idx').on(t.workspaceId),
  })
);

export const creditCards = sqliteTable(
  'credit_cards',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    bankName: text('bank_name'),
    last4: text('last4'),
    creditLimitMinor: moneyMinor('credit_limit_minor'),
    outstandingMinor: moneyMinor('outstanding_minor'),
    statementDay: integer('statement_day'),
    dueDay: integer('due_day'),
    minDuePercent: integer('min_due_percent'), // stored as basis points (e.g. 500 = 5.00%) to avoid float
    annualFeeMinor: integer('annual_fee_minor'),
    rewardsNote: text('rewards_note'),
    isActive: boolColumn('is_active', true),
    isDemo: boolColumn('is_demo', false),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('cc_workspace_idx').on(t.workspaceId),
  })
);
