import { text, integer } from 'drizzle-orm/sqlite-core';
import { createId } from '@/lib/id';

// ----------------------------------------------------------------------------
// Shared column helpers.
//
// PORTABILITY NOTE (SQLite -> Postgres): every helper here has a 1:1 Postgres
// equivalent:
//   idColumn()      -> text('id').primaryKey()                (unchanged)
//   moneyMinor()     -> integer(...)                            (unchanged — bigint if needed)
//   timestamps()     -> timestamp with time zone                (swap `integer(mode:'timestamp')`
//                                                                 for `timestamp()` from pg-core)
//   boolColumn()     -> boolean(...)                            (swap `integer(mode:'boolean')`
//                                                                 for native `boolean()`)
// "Enum-like" string columns keep their allowed-values list in a comment and
// are validated by the zod enums in src/lib/enums.ts — promote to a native
// pgEnum() when moving to Postgres if desired.
// ----------------------------------------------------------------------------

export function idColumn() {
  return text('id').primaryKey().$defaultFn(() => createId());
}

export function moneyMinor(name: string) {
  return integer(name).notNull().default(0);
}

export function boolColumn(name: string, defaultValue = false) {
  return integer(name, { mode: 'boolean' }).notNull().default(defaultValue);
}

export function tsColumn(name: string) {
  return integer(name, { mode: 'timestamp_ms' });
}

export const createdAt = () =>
  integer('created_at', { mode: 'timestamp_ms' })
    .notNull()
    .$defaultFn(() => new Date());

export const updatedAt = () =>
  integer('updated_at', { mode: 'timestamp_ms' })
    .notNull()
    .$defaultFn(() => new Date())
    .$onUpdateFn(() => new Date());
