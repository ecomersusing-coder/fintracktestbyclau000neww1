import { sqliteTable, text, integer, unique } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, updatedAt, boolColumn, tsColumn } from './_helpers';

export const plans = sqliteTable('plans', {
  id: idColumn(),
  key: text('key').notNull().unique(), // "free" | "pro" | "premium" | custom
  name: text('name').notNull(),
  description: text('description'),
  priceMonthlyMinor: integer('price_monthly_minor').notNull().default(0),
  priceYearlyMinor: integer('price_yearly_minor').notNull().default(0),
  trialDays: integer('trial_days').notNull().default(0),
  isActive: boolColumn('is_active', true),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

// key examples: max_accounts, max_transactions_per_month, max_ai_messages_per_month,
// max_storage_mb, feature_receipt_ai, feature_advanced_reports, feature_investment_tracking
// limitValue null = unlimited. boolValue used for feature_* flags.
export const planFeatures = sqliteTable(
  'plan_features',
  {
    id: idColumn(),
    planId: text('plan_id').notNull(),
    key: text('key').notNull(),
    limitValue: integer('limit_value'),
    boolValue: integer('bool_value', { mode: 'boolean' }),
  },
  (t) => ({
    uniqPlanKey: unique('pf_plan_key_uniq').on(t.planId, t.key),
  })
);

// status: TRIALING | ACTIVE | PAST_DUE | CANCELED | EXPIRED
// billingInterval: MONTHLY | YEARLY
export const subscriptions = sqliteTable('subscriptions', {
  id: idColumn(),
  workspaceId: text('workspace_id').notNull().unique(),
  planId: text('plan_id').notNull(),
  status: text('status').notNull().default('TRIALING'),
  billingInterval: text('billing_interval').notNull().default('MONTHLY'),
  currentPeriodStart: tsColumn('current_period_start').notNull(),
  currentPeriodEnd: tsColumn('current_period_end').notNull(),
  trialEndsAt: tsColumn('trial_ends_at'),
  cancelAtPeriodEnd: boolColumn('cancel_at_period_end', false),
  canceledAt: tsColumn('canceled_at'),
  // Deliberately generic — see src/lib/billing/provider.ts. No provider-specific
  // logic should leak outside that module.
  provider: text('provider'),
  providerCustomerId: text('provider_customer_id'),
  providerSubscriptionId: text('provider_subscription_id'),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

// metric: ai_messages | ai_tool_calls | transactions | accounts | attachments | storage_bytes | exports
export const usageRecords = sqliteTable(
  'usage_records',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    metric: text('metric').notNull(),
    periodStart: tsColumn('period_start').notNull(),
    periodEnd: tsColumn('period_end').notNull(),
    value: integer('value').notNull().default(0),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    uniqMetricPeriod: unique('ur_workspace_metric_period_uniq').on(
      t.workspaceId,
      t.metric,
      t.periodStart
    ),
  })
);
