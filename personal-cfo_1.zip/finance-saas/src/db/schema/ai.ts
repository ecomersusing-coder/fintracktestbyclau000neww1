import { sqliteTable, text, integer, index, unique } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, updatedAt, boolColumn, tsColumn } from './_helpers';

export const aiConversations = sqliteTable(
  'ai_conversations',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    userId: text('user_id').notNull(),
    title: text('title'),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspaceUser: index('aiconv_workspace_user_idx').on(t.workspaceId, t.userId),
  })
);

// role: USER | ASSISTANT | TOOL
export const aiMessages = sqliteTable(
  'ai_messages',
  {
    id: idColumn(),
    conversationId: text('conversation_id').notNull(),
    role: text('role').notNull(),
    content: text('content').notNull(),
    createdAt: createdAt(),
  },
  (t) => ({
    byConversation: index('aimsg_conversation_idx').on(t.conversationId),
  })
);

// status: PENDING_CONFIRMATION | CONFIRMED | EXECUTED | FAILED | CANCELLED
export const aiToolCalls = sqliteTable('ai_tool_calls', {
  id: idColumn(),
  messageId: text('message_id').notNull(),
  toolName: text('tool_name').notNull(),
  input: text('input').notNull(), // JSON
  output: text('output'), // JSON
  status: text('status').notNull().default('PENDING_CONFIRMATION'),
  requiresConfirmation: boolColumn('requires_confirmation', true),
  originalState: text('original_state'), // JSON — for audit/undo
  newState: text('new_state'), // JSON — for audit/undo
  executedAt: tsColumn('executed_at'),
  createdAt: createdAt(),
});

// matchType: MERCHANT_EXACT | MERCHANT_CONTAINS
export const aiCategoryRules = sqliteTable(
  'ai_category_rules',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    matchType: text('match_type').notNull().default('MERCHANT_CONTAINS'),
    matchValue: text('match_value').notNull(),
    categoryId: text('category_id').notNull(),
    confidenceBps: integer('confidence_bps').notNull().default(10000), // basis points, 10000 = 100%
    timesApplied: integer('times_applied').notNull().default(0),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    uniqMatch: unique('acr_workspace_match_uniq').on(t.workspaceId, t.matchValue),
  })
);
