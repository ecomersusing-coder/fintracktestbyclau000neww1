import { sqliteTable, text, integer, index, unique } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, updatedAt, moneyMinor, tsColumn } from './_helpers';

// period: MONTHLY | CUSTOM
export const budgets = sqliteTable(
  'budgets',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    period: text('period').notNull().default('MONTHLY'),
    startDate: tsColumn('start_date').notNull(),
    endDate: tsColumn('end_date'),
    totalLimitMinor: integer('total_limit_minor'),
    alertThresholdPercent: integer('alert_threshold_percent').notNull().default(80),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('budget_workspace_idx').on(t.workspaceId),
  })
);

export const budgetCategories = sqliteTable(
  'budget_categories',
  {
    id: idColumn(),
    budgetId: text('budget_id').notNull(),
    categoryId: text('category_id').notNull(),
    limitMinor: moneyMinor('limit_minor'),
  },
  (t) => ({
    uniqBudgetCategory: unique('bc_budget_category_uniq').on(t.budgetId, t.categoryId),
  })
);

export const savingsGoals = sqliteTable(
  'savings_goals',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    icon: text('icon'),
    targetMinor: moneyMinor('target_minor'),
    currentMinor: moneyMinor('current_minor'),
    targetDate: tsColumn('target_date'),
    monthlyContributionMinor: integer('monthly_contribution_minor'),
    isArchived: integer('is_archived', { mode: 'boolean' }).notNull().default(false),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('goal_workspace_idx').on(t.workspaceId),
  })
);
