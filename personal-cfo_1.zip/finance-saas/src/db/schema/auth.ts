import { sqliteTable, text, integer, index, unique } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, updatedAt, boolColumn, tsColumn } from './_helpers';

export const users = sqliteTable('users', {
  id: idColumn(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  name: text('name'),
  emailVerifiedAt: tsColumn('email_verified_at'),
  image: text('image'),
  isActive: boolColumn('is_active', true),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

// purpose: EMAIL_VERIFY | PASSWORD_RESET
export const verificationTokens = sqliteTable(
  'verification_tokens',
  {
    id: idColumn(),
    userId: text('user_id').notNull(),
    purpose: text('purpose').notNull(),
    token: text('token').notNull().unique(),
    expiresAt: tsColumn('expires_at').notNull(),
    usedAt: tsColumn('used_at'),
    createdAt: createdAt(),
  },
  (t) => ({
    byUserPurpose: index('vt_user_purpose_idx').on(t.userId, t.purpose),
  })
);

// The tenant boundary. Every financial row hangs off workspaceId.
export const workspaces = sqliteTable('workspaces', {
  id: idColumn(),
  name: text('name').notNull(),
  ownerId: text('owner_id').notNull(),
  currency: text('currency').notNull().default('INR'),
  country: text('country'),
  monthlyIncomeRange: text('monthly_income_range'),
  isDemo: boolColumn('is_demo', false),
  onboardingCompletedAt: tsColumn('onboarding_completed_at'),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

// role: OWNER | ADMIN | MEMBER   status: ACTIVE | INVITED | REMOVED
export const workspaceMembers = sqliteTable(
  'workspace_members',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    userId: text('user_id').notNull(),
    role: text('role').notNull().default('OWNER'),
    status: text('status').notNull().default('ACTIVE'),
    invitedEmail: text('invited_email'),
    createdAt: createdAt(),
  },
  (t) => ({
    uniqMember: unique('wm_workspace_user_uniq').on(t.workspaceId, t.userId),
  })
);
