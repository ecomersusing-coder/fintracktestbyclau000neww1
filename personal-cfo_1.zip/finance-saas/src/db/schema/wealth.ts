import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
import { idColumn, createdAt, updatedAt, boolColumn, moneyMinor, tsColumn } from './_helpers';

// type: PERSONAL | VEHICLE | HOME | CREDIT_CARD_DEBT | OTHER
export const loans = sqliteTable(
  'loans',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    type: text('type').notNull().default('PERSONAL'),
    principalMinor: moneyMinor('principal_minor'),
    outstandingMinor: moneyMinor('outstanding_minor'),
    interestRateBps: integer('interest_rate_bps').notNull().default(0), // basis points/yr, avoids float
    emiMinor: integer('emi_minor'),
    startDate: tsColumn('start_date').notNull(),
    endDate: tsColumn('end_date'),
    dueDay: integer('due_day'),
    accountId: text('account_id'),
    isActive: boolColumn('is_active', true),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('loan_workspace_idx').on(t.workspaceId),
  })
);

export const loanPayments = sqliteTable('loan_payments', {
  id: idColumn(),
  loanId: text('loan_id').notNull(),
  transactionId: text('transaction_id'),
  amountMinor: moneyMinor('amount_minor'),
  principalMinor: moneyMinor('principal_minor'),
  interestMinor: moneyMinor('interest_minor'),
  paidAt: tsColumn('paid_at').notNull(),
  createdAt: createdAt(),
});

// type: STOCK | MUTUAL_FUND | ETF | FD | GOLD | CRYPTO | OTHER
export const investments = sqliteTable(
  'investments',
  {
    id: idColumn(),
    workspaceId: text('workspace_id').notNull(),
    name: text('name').notNull(),
    type: text('type').notNull(),
    quantity: integer('quantity_milli'), // quantity * 1000, integer-safe
    currentValueMinor: moneyMinor('current_value_minor'),
    investedAmountMinor: moneyMinor('invested_amount_minor'),
    currency: text('currency').notNull().default('INR'),
    accountId: text('account_id'),
    notes: text('notes'),
    isArchived: boolColumn('is_archived', false),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => ({
    byWorkspace: index('inv_workspace_idx').on(t.workspaceId),
  })
);

// type: BUY | SELL | DIVIDEND | VALUATION_UPDATE
export const investmentTransactions = sqliteTable('investment_transactions', {
  id: idColumn(),
  investmentId: text('investment_id').notNull(),
  transactionId: text('transaction_id'),
  type: text('type').notNull(),
  quantityMilli: integer('quantity_milli'),
  priceMinor: integer('price_minor'),
  amountMinor: moneyMinor('amount_minor'),
  occurredAt: tsColumn('occurred_at').notNull(),
  createdAt: createdAt(),
});
