import Database from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import * as schema from './schema';

// Singleton across Next.js dev hot-reloads.
declare global {
  // eslint-disable-next-line no-var
  var __sqlite: Database.Database | undefined;
}

const DB_PATH = process.env.DATABASE_URL?.replace(/^file:/, '') ?? './dev.db';

const sqlite = global.__sqlite ?? new Database(DB_PATH);
sqlite.pragma('journal_mode = WAL');
sqlite.pragma('foreign_keys = ON');

if (process.env.NODE_ENV !== 'production') {
  global.__sqlite = sqlite;
}

export const db = drizzle(sqlite, { schema });
export { schema };
