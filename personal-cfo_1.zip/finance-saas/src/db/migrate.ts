import Database from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import { migrate } from 'drizzle-orm/better-sqlite3/migrator';

const DB_PATH = (process.env.DATABASE_URL ?? 'file:./dev.db').replace(/^file:/, '');

const sqlite = new Database(DB_PATH);
sqlite.pragma('journal_mode = WAL');
const db = drizzle(sqlite);

migrate(db, { migrationsFolder: './drizzle' });
console.log(`Migrations applied to ${DB_PATH}`);
sqlite.close();
