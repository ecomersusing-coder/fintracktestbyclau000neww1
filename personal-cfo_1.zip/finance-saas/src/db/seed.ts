import { eq, and } from 'drizzle-orm';
import { db, schema } from './client';
import { hashPassword } from '@/lib/password';
import { createId } from '@/lib/id';

// ----------------------------------------------------------------------------
// 1. PLANS — database-driven, per spec §6/§65. The app code never hardcodes
//    a limit; it always reads plan_features at request time.
// ----------------------------------------------------------------------------
async function seedPlans() {
  const planDefs = [
    {
      key: 'free',
      name: 'Free',
      description: 'Get started with the essentials.',
      priceMonthlyMinor: 0,
      priceYearlyMinor: 0,
      trialDays: 0,
      sortOrder: 0,
      features: {
        max_accounts: 2,
        max_transactions_per_month: 100,
        max_ai_messages_per_month: 20,
        max_ai_tool_calls_per_month: 40,
        max_storage_bytes: 50 * 1024 * 1024,
        max_attachments_per_month: 10,
        max_exports_per_month: 2,
        feature_receipt_ai: false,
        feature_advanced_reports: false,
        feature_investment_tracking: false,
      },
    },
    {
      key: 'pro',
      name: 'Pro',
      description: 'Unlimited transactions, full AI copilot, advanced reports.',
      priceMonthlyMinor: 49900,
      priceYearlyMinor: 499900,
      trialDays: 14,
      sortOrder: 1,
      features: {
        max_accounts: null,
        max_transactions_per_month: null,
        max_ai_messages_per_month: 300,
        max_ai_tool_calls_per_month: 600,
        max_storage_bytes: 2 * 1024 * 1024 * 1024,
        max_attachments_per_month: 200,
        max_exports_per_month: 50,
        feature_receipt_ai: true,
        feature_advanced_reports: true,
        feature_investment_tracking: true,
      },
    },
    {
      key: 'premium',
      name: 'Premium',
      description: 'Higher AI limits, advanced insights, priority features.',
      priceMonthlyMinor: 99900,
      priceYearlyMinor: 999900,
      trialDays: 14,
      sortOrder: 2,
      features: {
        max_accounts: null,
        max_transactions_per_month: null,
        max_ai_messages_per_month: null,
        max_ai_tool_calls_per_month: null,
        max_storage_bytes: 10 * 1024 * 1024 * 1024,
        max_attachments_per_month: null,
        max_exports_per_month: null,
        feature_receipt_ai: true,
        feature_advanced_reports: true,
        feature_investment_tracking: true,
      },
    },
  ] as const;

  const planIds: Record<string, string> = {};

  for (const def of planDefs) {
    let plan = await db.query.plans.findFirst({ where: eq(schema.plans.key, def.key) });
    if (!plan) {
      [plan] = await db
        .insert(schema.plans)
        .values({
          key: def.key,
          name: def.name,
          description: def.description,
          priceMonthlyMinor: def.priceMonthlyMinor,
          priceYearlyMinor: def.priceYearlyMinor,
          trialDays: def.trialDays,
          sortOrder: def.sortOrder,
        })
        .returning();
    }
    planIds[def.key] = plan.id;

    for (const [key, value] of Object.entries(def.features)) {
      const existing = await db.query.planFeatures.findFirst({
        where: and(eq(schema.planFeatures.planId, plan.id), eq(schema.planFeatures.key, key)),
      });
      const isBool = typeof value === 'boolean';
      if (existing) {
        await db
          .update(schema.planFeatures)
          .set(isBool ? { boolValue: value } : { limitValue: value as number | null })
          .where(eq(schema.planFeatures.id, existing.id));
      } else {
        await db.insert(schema.planFeatures).values({
          planId: plan.id,
          key,
          limitValue: isBool ? null : (value as number | null),
          boolValue: isBool ? value : null,
        });
      }
    }
  }

  console.log('Seeded plans:', Object.keys(planIds).join(', '));
  return planIds;
}

// ----------------------------------------------------------------------------
// 2. SYSTEM CATEGORIES (spec §11) — global (workspaceId null), shared, read-only
// ----------------------------------------------------------------------------
const EXPENSE_CATEGORIES = [
  'Food', 'Groceries', 'Restaurants', 'Shopping', 'Fuel', 'Transport', 'Rent',
  'Utilities', 'Internet', 'Phone', 'Healthcare', 'Education', 'Insurance',
  'Entertainment', 'Travel', 'Family', 'Subscriptions', 'EMI', 'Business',
  'Personal', 'Other',
];
const INCOME_CATEGORIES = ['Salary', 'Business Income', 'Freelance', 'Commission', 'Interest', 'Dividends', 'Refunds', 'Other Income'];

async function seedCategories() {
  const existing = await db.query.categories.findMany({ where: eq(schema.categories.isSystem, true) });
  const existingNames = new Set(existing.map((c) => c.name));

  const rows = [
    ...EXPENSE_CATEGORIES.filter((n) => !existingNames.has(n)).map((name) => ({ name, kind: 'EXPENSE' as const })),
    ...INCOME_CATEGORIES.filter((n) => !existingNames.has(n)).map((name) => ({ name, kind: 'INCOME' as const })),
  ];

  if (rows.length > 0) {
    await db.insert(schema.categories).values(rows.map((r) => ({ ...r, isSystem: true, workspaceId: null })));
  }
  console.log(`Seeded ${rows.length} new system categories (${existingNames.size} already existed)`);
}

// ----------------------------------------------------------------------------
// 3. ADMIN USER — separate identity space, see prisma/schema notes
// ----------------------------------------------------------------------------
async function seedAdmin() {
  const email = process.env.ADMIN_SEED_EMAIL ?? 'admin@personalcfo.local';
  const existing = await db.query.adminUsers.findFirst({ where: eq(schema.adminUsers.email, email) });
  if (existing) {
    console.log('Admin user already exists:', email);
    return;
  }
  const password = process.env.ADMIN_SEED_PASSWORD ?? 'ChangeMe123!';
  await db.insert(schema.adminUsers).values({
    email,
    passwordHash: await hashPassword(password),
    name: 'Super Admin',
    role: 'SUPERADMIN',
  });
  console.log('Seeded admin user:', email, '(check ADMIN_SEED_PASSWORD in .env)');
}

// ----------------------------------------------------------------------------
// 4. DEMO WORKSPACE — clearly marked isDemo: true throughout, per spec §80.
//    Login: demo@personalcfo.local / Demo1234!
// ----------------------------------------------------------------------------
async function seedDemoWorkspace(planIds: Record<string, string>) {
  const demoEmail = 'demo@personalcfo.local';
  const existingUser = await db.query.users.findFirst({ where: eq(schema.users.email, demoEmail) });
  if (existingUser) {
    console.log('Demo workspace already exists');
    return;
  }

  const user = await db
    .insert(schema.users)
    .values({ email: demoEmail, passwordHash: await hashPassword('Demo1234!'), name: 'Demo User', emailVerifiedAt: new Date() })
    .returning()
    .then((r) => r[0]);

  const workspace = await db
    .insert(schema.workspaces)
    .values({
      name: "Demo User's Workspace",
      ownerId: user.id,
      currency: 'INR',
      country: 'IN',
      isDemo: true,
      onboardingCompletedAt: new Date(),
    })
    .returning()
    .then((r) => r[0]);

  await db.insert(schema.workspaceMembers).values({ workspaceId: workspace.id, userId: user.id, role: 'OWNER' });

  const now = new Date();
  const periodEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  await db.insert(schema.subscriptions).values({
    workspaceId: workspace.id,
    planId: planIds.pro,
    status: 'ACTIVE',
    billingInterval: 'MONTHLY',
    currentPeriodStart: now,
    currentPeriodEnd: periodEnd,
  });

  const categories = await db.query.categories.findMany({ where: eq(schema.categories.isSystem, true) });
  const catByName = new Map(categories.map((c) => [c.name, c.id]));

  const hdfc = await db
    .insert(schema.financialAccounts)
    .values({
      workspaceId: workspace.id,
      name: 'HDFC Savings',
      bankName: 'HDFC Bank',
      type: 'SAVINGS',
      last4: '4821',
      openingBalanceMinor: 15_000_00,
      currentBalanceMinor: 18_450_00,
      isDemo: true,
    })
    .returning()
    .then((r) => r[0]);

  const icici = await db
    .insert(schema.financialAccounts)
    .values({
      workspaceId: workspace.id,
      name: 'ICICI Savings',
      bankName: 'ICICI Bank',
      type: 'SAVINGS',
      last4: '7734',
      openingBalanceMinor: 5_000_00,
      currentBalanceMinor: 6_200_00,
      isDemo: true,
    })
    .returning()
    .then((r) => r[0]);

  const cash = await db
    .insert(schema.financialAccounts)
    .values({ workspaceId: workspace.id, name: 'Cash Wallet', type: 'CASH', currentBalanceMinor: 2_000_00, isDemo: true })
    .returning()
    .then((r) => r[0]);

  const hdfcCard = await db
    .insert(schema.creditCards)
    .values({
      workspaceId: workspace.id,
      name: 'HDFC Credit Card',
      bankName: 'HDFC Bank',
      last4: '9021',
      creditLimitMinor: 200_000_00,
      outstandingMinor: 12_400_00,
      statementDay: 22,
      dueDay: 10,
      isDemo: true,
    })
    .returning()
    .then((r) => r[0]);

  // A realistic month of demo transactions
  const demoTxns: (typeof schema.transactions.$inferInsert)[] = [];
  const d = (daysAgo: number) => new Date(Date.now() - daysAgo * 86400000);

  demoTxns.push({
    workspaceId: workspace.id, type: 'INCOME', amountMinor: 150_000_00, occurredAt: d(8),
    accountId: hdfc.id, categoryId: catByName.get('Salary'), merchant: 'Employer Pvt Ltd',
    description: 'Monthly salary', source: 'MANUAL', isDemo: true,
  });

  const expenseSeed: [string, string, number, number][] = [
    ['Lulu Hypermarket', 'Groceries', 850, 1],
    ['Swiggy', 'Restaurants', 420, 2],
    ['HP Petrol Pump', 'Fuel', 2000, 3],
    ['Amazon', 'Shopping', 3200, 4],
    ['Netflix', 'Subscriptions', 649, 5],
    ['Spotify', 'Subscriptions', 119, 5],
    ['Adobe', 'Subscriptions', 1675, 6],
    ['Zomato', 'Restaurants', 560, 7],
    ['Reliance Fresh', 'Groceries', 1200, 9],
    ['Airtel', 'Phone', 599, 10],
    ['BESCOM', 'Utilities', 2100, 11],
    ['Uber', 'Transport', 340, 12],
    ['Myntra', 'Shopping', 2450, 14],
  ];
  for (const [merchant, cat, amountRupees, daysAgo] of expenseSeed) {
    demoTxns.push({
      workspaceId: workspace.id,
      type: 'CC_PURCHASE',
      amountMinor: amountRupees * 100,
      occurredAt: d(daysAgo),
      creditCardId: hdfcCard.id,
      categoryId: catByName.get(cat),
      merchant,
      source: 'MANUAL',
      isDemo: true,
    });
  }

  demoTxns.push({
    workspaceId: workspace.id, type: 'EXPENSE', amountMinor: 25_000_00, occurredAt: d(15),
    accountId: hdfc.id, categoryId: catByName.get('Rent'), merchant: 'Landlord', description: 'Monthly rent', isDemo: true,
  });

  await db.insert(schema.transactions).values(demoTxns);

  // Reflect CC purchases + rent + salary in the running balances (seed data
  // is inserted directly, bypassing the accounting engine, so we mirror its
  // effect manually here — see spec §80: never mix seed data write paths
  // with the real engine used at runtime).
  const ccTotal = expenseSeed.reduce((s, [, , amt]) => s + amt * 100, 0);
  await db.update(schema.creditCards).set({ outstandingMinor: 12_400_00 }).where(eq(schema.creditCards.id, hdfcCard.id));

  await db.insert(schema.savingsGoals).values([
    { workspaceId: workspace.id, name: 'Emergency Fund', targetMinor: 300_000_00, currentMinor: 85_000_00, icon: '🛟' },
    { workspaceId: workspace.id, name: 'Goa Trip', targetMinor: 60_000_00, currentMinor: 22_000_00, icon: '✈️' },
  ]);

  await db.insert(schema.loans).values([
    {
      workspaceId: workspace.id, name: 'Car Loan', type: 'VEHICLE', principalMinor: 800_000_00,
      outstandingMinor: 520_000_00, interestRateBps: 950, emiMinor: 16_500_00, startDate: d(400), dueDay: 5,
    },
  ]);

  await db.insert(schema.investments).values([
    { workspaceId: workspace.id, name: 'Nifty 50 Index Fund', type: 'MUTUAL_FUND', investedAmountMinor: 120_000_00, currentValueMinor: 138_500_00, quantity: 450_000 },
    { workspaceId: workspace.id, name: 'Gold ETF', type: 'GOLD', investedAmountMinor: 50_000_00, currentValueMinor: 54_200_00 },
  ]);

  await db.insert(schema.budgets).values({
    workspaceId: workspace.id, name: 'Monthly Budget', period: 'MONTHLY',
    startDate: new Date(now.getFullYear(), now.getMonth(), 1), totalLimitMinor: 60_000_00,
  }).returning().then(async (r) => {
    const budget = r[0];
    await db.insert(schema.budgetCategories).values([
      { budgetId: budget.id, categoryId: catByName.get('Groceries')!, limitMinor: 15_000_00 },
      { budgetId: budget.id, categoryId: catByName.get('Shopping')!, limitMinor: 10_000_00 },
      { budgetId: budget.id, categoryId: catByName.get('Fuel')!, limitMinor: 8_000_00 },
    ]);
  });

  await db.insert(schema.bills).values([
    { workspaceId: workspace.id, name: 'HDFC Credit Card Due', amountMinor: 12_400_00, dueDate: d(-8), category: 'CC_DUE', status: 'UPCOMING' },
    { workspaceId: workspace.id, name: 'Car Loan EMI', amountMinor: 16_500_00, dueDate: d(-3), category: 'EMI', status: 'UPCOMING' },
    { workspaceId: workspace.id, name: 'Netflix renewal', amountMinor: 649_00, dueDate: d(-20), category: 'SUBSCRIPTION', status: 'UPCOMING' },
  ]);

  console.log('Seeded demo workspace. Login: demo@personalcfo.local / Demo1234!');
}

async function main() {
  const planIds = await seedPlans();
  await seedCategories();
  await seedAdmin();
  await seedDemoWorkspace(planIds);
  console.log('Seed complete.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => process.exit(0));
